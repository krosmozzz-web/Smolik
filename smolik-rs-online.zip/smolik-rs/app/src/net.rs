//! Сетевой слой онлайн-кооператива: TCP-соединение, лобби хоста, подключение клиента.
//! Только стандартная библиотека. Окно не зависает: чтение и запись идут в отдельных потоках,
//! подключение (в том числе поиск адреса по имени) тоже.
use smolik_core::game::{Game, Input, RemoteCtl};
use smolik_core::wire::{self, Ctl};
use std::io::{Read, Write};
use std::net::{Shutdown, TcpListener, TcpStream, ToSocketAddrs, UdpSocket};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::Arc;
use std::time::Duration;

/// Порт, на котором хост ждёт друга.
pub const PORT: u16 = 7777;
/// Больше этого одно сообщение быть не может: защита от мусора.
const MAX_FRAME: usize = 1 << 20;

pub enum Event {
    Msg(u8, Vec<u8>),
    Closed,
}

/// Соединение: поток читает кадры в очередь, поток пишет кадры из очереди.
pub struct Conn {
    rx: Receiver<Event>,
    tx: Sender<Vec<u8>>,
    pending: Arc<AtomicUsize>,
    alive: Arc<AtomicBool>,
    ctl: TcpStream,
}

impl Conn {
    pub fn new(stream: TcpStream) -> std::io::Result<Conn> {
        stream.set_nodelay(true)?;
        // принятое соединение на некоторых системах наследует неблокирующий режим от слушателя
        stream.set_nonblocking(false)?;
        let mut rd = stream.try_clone()?;
        let mut wr = stream.try_clone()?;
        let (ev_tx, rx) = channel::<Event>();
        let (tx, wr_rx) = channel::<Vec<u8>>();
        let pending = Arc::new(AtomicUsize::new(0));
        let alive = Arc::new(AtomicBool::new(true));
        {
            let alive = alive.clone();
            std::thread::spawn(move || {
                let mut head = [0u8; 4];
                loop {
                    if rd.read_exact(&mut head).is_err() {
                        break;
                    }
                    let n = u32::from_le_bytes(head) as usize;
                    if n == 0 || n > MAX_FRAME {
                        break;
                    }
                    let mut body = vec![0u8; n];
                    if rd.read_exact(&mut body).is_err() {
                        break;
                    }
                    let ty = body[0];
                    let payload = body[1..].to_vec();
                    if ev_tx.send(Event::Msg(ty, payload)).is_err() {
                        return;
                    }
                }
                alive.store(false, Ordering::SeqCst);
                let _ = ev_tx.send(Event::Closed);
            });
        }
        {
            let alive = alive.clone();
            let pending = pending.clone();
            std::thread::spawn(move || {
                while let Ok(frame) = wr_rx.recv() {
                    let ok = wr.write_all(&frame).is_ok();
                    pending.fetch_sub(1, Ordering::SeqCst);
                    if !ok {
                        alive.store(false, Ordering::SeqCst);
                        break;
                    }
                }
                let _ = wr.shutdown(Shutdown::Both);
            });
        }
        Ok(Conn { rx, tx, pending, alive, ctl: stream })
    }

    pub fn send(&self, ty: u8, payload: &[u8]) {
        if !self.alive.load(Ordering::SeqCst) {
            return;
        }
        let n = payload.len() + 1;
        let mut frame: Vec<u8> = Vec::with_capacity(n + 4);
        frame.extend_from_slice(&(n as u32).to_le_bytes());
        frame.push(ty);
        frame.extend_from_slice(payload);
        self.pending.fetch_add(1, Ordering::SeqCst);
        if self.tx.send(frame).is_err() {
            self.pending.fetch_sub(1, Ordering::SeqCst);
            self.alive.store(false, Ordering::SeqCst);
        }
    }

    /// Всё, что пришло с прошлого раза.
    pub fn poll(&self) -> Vec<Event> {
        let mut v: Vec<Event> = Vec::new();
        while let Ok(e) = self.rx.try_recv() {
            v.push(e);
        }
        v
    }

    /// Сколько сообщений ещё не ушло в сеть.
    pub fn backlog(&self) -> usize {
        self.pending.load(Ordering::SeqCst)
    }

    pub fn alive(&self) -> bool {
        self.alive.load(Ordering::SeqCst)
    }
}

impl Drop for Conn {
    fn drop(&mut self) {
        // закрываем только чтение: поток записи дошлёт всё, что накопилось (например, итог забега), и закроет сокет сам
        let _ = self.ctl.shutdown(Shutdown::Read);
    }
}

fn has_port(a: &str) -> bool {
    if let Some(rest) = a.strip_prefix('[') {
        return rest.contains("]:");
    }
    match a.rfind(':') {
        Some(i) => a.matches(':').count() == 1 && i + 1 < a.len() && a[i + 1..].chars().all(|c| c.is_ascii_digit()),
        None => false,
    }
}

fn connect_blocking(addr: &str) -> Result<TcpStream, String> {
    let a = addr.trim();
    if a.is_empty() {
        return Err("Введи адрес друга".to_string());
    }
    let full = if has_port(a) { a.to_string() } else { format!("{}:{}", a, PORT) };
    let addrs = match full.to_socket_addrs() {
        Ok(v) => v,
        Err(e) => return Err(format!("Неверный адрес: {}", e)),
    };
    let mut last = String::from("адрес не найден");
    for sa in addrs {
        match TcpStream::connect_timeout(&sa, Duration::from_secs(6)) {
            Ok(s) => return Ok(s),
            Err(e) => last = format!("{}", e),
        }
    }
    Err(format!("Не удалось подключиться: {}", last))
}

/// Подключение в отдельном потоке, чтобы окно не зависало.
pub fn connect_async(addr: String) -> Receiver<Result<TcpStream, String>> {
    let (tx, rx) = channel::<Result<TcpStream, String>>();
    std::thread::spawn(move || {
        let _ = tx.send(connect_blocking(&addr));
    });
    rx
}

/// Адрес этого компьютера в локальной сети (пакетов не отправляется).
pub fn local_ip() -> Option<String> {
    let s = UdpSocket::bind("0.0.0.0:0").ok()?;
    s.connect("8.8.8.8:80").ok()?;
    let a = s.local_addr().ok()?;
    Some(a.ip().to_string())
}

// ---------------------------------------------------------------- лобби хоста

pub struct Guest {
    pub conn: Conn,
    pub hero: usize,
    pub up: [i32; 3],
}

/// Хост ждёт друга: принимает подключения и ждёт «привет» с выбранным героем.
pub struct Lobby {
    listener: TcpListener,
    waiting: Vec<(Conn, f32)>,
    pub guest: Option<Guest>,
    pub ip: Option<String>,
    pub msg: String,
    welcome: Vec<u8>,
}

impl Lobby {
    /// `welcome` — готовый ответ хоста (сложность и его герой), он уходит другу сразу после «привет».
    pub fn new(welcome: Vec<u8>) -> Result<Lobby, String> {
        let listener = match TcpListener::bind(("0.0.0.0", PORT)) {
            Ok(l) => l,
            Err(e) => return Err(format!("Порт {} недоступен: {}", PORT, e)),
        };
        if let Err(e) = listener.set_nonblocking(true) {
            return Err(format!("Не удалось открыть порт: {}", e));
        }
        Ok(Lobby { listener, waiting: Vec::new(), guest: None, ip: local_ip(), msg: String::new(), welcome })
    }

    pub fn update(&mut self, dt: f32) {
        while let Ok((s, _)) = self.listener.accept() {
            if let Ok(c) = Conn::new(s) {
                self.waiting.push((c, 0.0));
            }
        }
        let mut i = 0;
        while i < self.waiting.len() {
            let mut hello: Option<(usize, [i32; 3])> = None;
            let mut dead = false;
            for e in self.waiting[i].0.poll() {
                match e {
                    Event::Msg(wire::MSG_HELLO, body) => match wire::decode_hello(&body) {
                        Some(h) => hello = Some(h),
                        None => dead = true,
                    },
                    Event::Closed => dead = true,
                    Event::Msg(_, _) => {}
                }
            }
            self.waiting[i].1 += dt;
            if let Some((hero, up)) = hello {
                if self.guest.is_none() {
                    let (conn, _) = self.waiting.remove(i);
                    conn.send(wire::MSG_WELCOME, &self.welcome);
                    self.guest = Some(Guest { conn, hero, up });
                    self.msg.clear();
                    continue;
                }
                dead = true;
            }
            if dead || self.waiting[i].1 > 8.0 {
                self.waiting.remove(i);
                continue;
            }
            i += 1;
        }
        let gone = match self.guest.as_ref() {
            Some(g) => !g.conn.alive(),
            None => false,
        };
        if gone {
            self.guest = None;
            self.msg = "Друг отключился".to_string();
        }
    }
}

// ---------------------------------------------------------------- хост в игре

pub struct HostLink {
    conn: Conn,
    ctl: Ctl,
    have_ctl: bool,
    act_seen: u8,
    bomb_seen: u8,
    age: f32,
    snap_t: f32,
    seq: u32,
    floor_sent: i32,
    pub closed: bool,
}

impl HostLink {
    pub fn new(conn: Conn) -> HostLink {
        HostLink { conn, ctl: Ctl::default(), have_ctl: false, act_seen: 0, bomb_seen: 0, age: 0.0, snap_t: 0.0, seq: 0, floor_sent: -1, closed: false }
    }

    /// Читает сеть и собирает ввод второго игрока на этот кадр. `None`, если друг отключился.
    pub fn pump(&mut self, dt: f32) -> Option<RemoteCtl> {
        let mut got = false;
        for e in self.conn.poll() {
            match e {
                Event::Msg(wire::MSG_CTL, body) => {
                    if let Some(c) = Ctl::decode(&body) {
                        self.ctl = c;
                        self.have_ctl = true;
                        self.age = 0.0;
                        got = true;
                    }
                }
                Event::Msg(wire::MSG_BYE, _) | Event::Closed => self.closed = true,
                Event::Msg(_, _) => {}
            }
        }
        if !self.conn.alive() {
            self.closed = true;
        }
        if self.closed {
            return None;
        }
        self.age += dt;
        let c = self.ctl;
        let fresh = self.have_ctl && self.age < 0.6;
        let act = self.have_ctl && c.act_n != self.act_seen;
        let bomb = self.have_ctl && c.bomb_n != self.bomb_seen;
        if self.have_ctl {
            self.act_seen = c.act_n;
            self.bomb_seen = c.bomb_n;
        }
        let inp = if fresh { Input { ix: c.ix, iy: c.iy, ax: c.ax, ay: c.ay } } else { Input::default() };
        Some(RemoteCtl { inp, has_pos: got, x: c.x, y: c.y, vx: c.vx, vy: c.vy, epoch: c.epoch, act, bomb })
    }

    /// Шлёт этаж при смене этажа и снимки состояния примерно 30 раз в секунду.
    pub fn send(&mut self, g: &mut Game, dt: f32) {
        self.snap_t += dt;
        if self.closed {
            return;
        }
        if g.floor != self.floor_sent {
            self.conn.send(wire::MSG_FLOOR, &g.net_floor());
            self.floor_sent = g.floor;
        }
        if !g.over {
            if self.snap_t < wire::SNAP_DT {
                return;
            }
            if self.conn.backlog() > 4 {
                // линия не успевает: пропускаем снимок, чтобы не копить задержку
                return;
            }
        }
        self.snap_t = 0.0;
        self.seq = self.seq.wrapping_add(1);
        let s = g.net_state(self.seq);
        self.conn.send(wire::MSG_STATE, &s);
    }
}

// ---------------------------------------------------------------- клиент

pub struct ClientLink {
    conn: Conn,
    ctl_t: f32,
    act_n: u8,
    bomb_n: u8,
    pub closed: bool,
}

impl ClientLink {
    pub fn new(conn: Conn) -> ClientLink {
        ClientLink { conn, ctl_t: 0.0, act_n: 0, bomb_n: 0, closed: false }
    }

    pub fn handle(&mut self, g: &mut Game, e: Event) {
        match e {
            Event::Msg(wire::MSG_FLOOR, body) => {
                let _ = g.net_apply_floor(&body);
            }
            Event::Msg(wire::MSG_STATE, body) => {
                let _ = g.net_apply_state(&body);
            }
            Event::Msg(wire::MSG_BYE, _) | Event::Closed => self.closed = true,
            Event::Msg(_, _) => {}
        }
    }

    pub fn pump(&mut self, g: &mut Game) {
        for e in self.conn.poll() {
            self.handle(g, e);
        }
        if !self.conn.alive() {
            self.closed = true;
        }
    }

    /// Шлёт хосту ввод, положение и нажатия.
    pub fn send(&mut self, g: &Game, inp: &Input, act: bool, bomb: bool, dt: f32) {
        if act {
            self.act_n = self.act_n.wrapping_add(1);
        }
        if bomb {
            self.bomb_n = self.bomb_n.wrapping_add(1);
        }
        self.ctl_t += dt;
        if self.ctl_t < wire::SNAP_DT && !act && !bomb {
            return;
        }
        self.ctl_t = 0.0;
        let c = Ctl { ix: inp.ix, iy: inp.iy, ax: inp.ax, ay: inp.ay, x: g.p.x, y: g.p.y, vx: g.p.vx, vy: g.p.vy, epoch: g.epoch, act_n: self.act_n, bomb_n: self.bomb_n };
        self.conn.send(wire::MSG_CTL, &c.encode());
    }
}

/// Клиент подключился и ждёт, пока хост начнёт забег.
pub struct ClientWait {
    conn: Option<Conn>,
    hero: usize,
    up: [i32; 3],
    welcome: Option<(usize, usize)>,
    pub msg: String,
}

pub enum WaitResult {
    Waiting,
    Failed(String),
    Start(Game, ClientLink),
}

impl ClientWait {
    pub fn new(conn: Conn, hero: usize, up: [i32; 3]) -> ClientWait {
        conn.send(wire::MSG_HELLO, &wire::encode_hello(hero, up));
        ClientWait { conn: Some(conn), hero, up, welcome: None, msg: "Соединились, здороваемся с хостом…".to_string() }
    }

    pub fn update(&mut self) -> WaitResult {
        let events = match self.conn.as_ref() {
            Some(c) => c.poll(),
            None => return WaitResult::Failed("Нет соединения".to_string()),
        };
        let mut game: Option<Game> = None;
        let mut rest: Vec<Event> = Vec::new();
        for e in events {
            match e {
                Event::Msg(wire::MSG_WELCOME, body) => match wire::decode_welcome(&body) {
                    Some(w) => {
                        self.welcome = Some(w);
                        self.msg = "Подключено. Ждём, пока хост начнёт забег…".to_string();
                    }
                    None => return WaitResult::Failed("У хоста другая версия игры".to_string()),
                },
                Event::Msg(wire::MSG_FLOOR, body) => {
                    if game.is_none() {
                        let (diff, host_hero) = match self.welcome {
                            Some(w) => w,
                            None => return WaitResult::Failed("Хост не ответил на приветствие".to_string()),
                        };
                        let mut g = wire::client_game(self.hero, self.up, diff, host_hero);
                        if g.net_apply_floor(&body).is_none() {
                            return WaitResult::Failed("Не удалось принять этаж от хоста".to_string());
                        }
                        game = Some(g);
                    }
                }
                Event::Closed => return WaitResult::Failed("Хост закрыл соединение".to_string()),
                other => {
                    if game.is_some() {
                        rest.push(other);
                    }
                }
            }
        }
        if let Some(mut g) = game {
            let conn = match self.conn.take() {
                Some(c) => c,
                None => return WaitResult::Failed("Нет соединения".to_string()),
            };
            let mut link = ClientLink::new(conn);
            for e in rest {
                link.handle(&mut g, e);
            }
            return WaitResult::Start(g, link);
        }
        WaitResult::Waiting
    }
}
