//! Smolik на Rust: меню, опросы, забег, итоги. Правила игры живут в крейте `smolik-core`.
mod draw;
mod net;
mod ui;

use macroquad::prelude::*;
use smolik_core::data::CHARACTERS;
use smolik_core::defs::{Path, DIFFS};
use smolik_core::game::{Game, Input};
use smolik_core::profile::{quiz_for, Profile, RunResult, UPGRADE_MAX, UPGRADE_NAMES};
use ui::*;

const FONT: &[u8] = include_bytes!("../assets/DejaVuSans.ttf");
const SAVE_FILE: &str = "smolik_save.txt";

fn window_conf() -> Conf {
    Conf { window_title: "Smolik".to_owned(), window_width: 1100, window_height: 700, high_dpi: false, ..Default::default() }
}

fn load_profile() -> Profile {
    match std::fs::read_to_string(SAVE_FILE) {
        Ok(t) => Profile::from_text(&t),
        Err(_) => Profile::default(),
    }
}

fn save_profile(p: &Profile) {
    let _ = std::fs::write(SAVE_FILE, p.to_text());
}

enum Screen {
    Menu,
    Quiz { hero: usize, k: usize },
    Play,
    Summary,
    Online,
}

/// Состояние онлайн-игры: от лобби до самой игры.
enum Online {
    Host(net::Lobby),
    Connecting(std::sync::mpsc::Receiver<Result<std::net::TcpStream, String>>),
    Wait(net::ClientWait),
    HostGame(net::HostLink),
    ClientGame(net::ClientLink),
}

#[derive(Default)]
struct Sticks {
    m_id: Option<u64>,
    m_o: Vec2,
    m_v: Vec2,
    a_id: Option<u64>,
    a_o: Vec2,
    a_v: Vec2,
}

struct State {
    screen: Screen,
    profile: Profile,
    game: Option<Game>,
    scroll: f32,
    msg: Option<(String, f32)>,
    paused: bool,
    over_t: f32,
    summary: Vec<String>,
    sticks: Sticks,
    aim_block: bool,
    online: Option<Online>,
    addr: String,
    net_msg: String,
}

impl State {
    fn new() -> State {
        State {
            screen: Screen::Menu,
            profile: load_profile(),
            game: None,
            scroll: 0.0,
            msg: None,
            paused: false,
            over_t: 0.0,
            summary: Vec::new(),
            sticks: Sticks::default(),
            aim_block: false,
            online: None,
            addr: String::new(),
            net_msg: String::new(),
        }
    }

    fn say(&mut self, s: &str) {
        self.msg = Some((s.to_string(), 3.5));
    }
}

#[macroquad::main(window_conf)]
async fn main() {
    let font = load_ttf_font_from_bytes(FONT).expect("не удалось загрузить шрифт");
    let mut ui = Ui::new(font);
    let mut st = State::new();
    st.profile.fix_selection();
    loop {
        let scroll = ui.begin_frame();
        if let Some(m) = st.msg.as_mut() {
            m.1 -= get_frame_time();
        }
        if st.msg.as_ref().map_or(false, |m| m.1 <= 0.0) {
            st.msg = None;
        }
        match st.screen {
            Screen::Menu => menu(&ui, &mut st, scroll),
            Screen::Quiz { hero, k } => quiz(&ui, &mut st, hero, k),
            Screen::Play => play(&ui, &mut st),
            Screen::Summary => summary(&ui, &mut st),
            Screen::Online => online_screen(&ui, &mut st, scroll),
        }
        next_frame().await;
    }
}

// ---------------------------------------------------------------- меню

fn card(x: f32, y: f32, w: f32, h: f32) {
    draw_rectangle(x, y, w, h, Color::from_rgba(32, 27, 48, 255));
    draw_rectangle_lines(x, y, w, h, 2.0, Color::from_rgba(58, 50, 84, 255));
}

fn menu(ui: &Ui, st: &mut State, scroll: f32) {
    clear_background(col("#14111f"));
    let u = ui.u;
    let sw = screen_width();
    let sh = screen_height();
    let cw = (sw - 24.0 * u).min(640.0 * u);
    let x = (sw - cw) / 2.0;
    st.scroll += scroll;
    let mut y = 24.0 * u - st.scroll;

    ui.text_oc("SMOLIK", sw / 2.0, y + 38.0 * u, 46.0, col("#f0c030"));
    y += 58.0 * u;
    let p = &st.profile;
    let line = format!("Монеты: {} · лучший этаж: {} · побед: {} · забегов: {}", p.coins, p.best, p.wins, p.runs);
    ui.text_c(&line, sw / 2.0, y + 14.0 * u, 14.0, col("#c8bfd8"));
    y += 34.0 * u;

    // сложность
    let gap = 8.0 * u;
    let bw = (cw - gap * 2.0) / 3.0;
    let mut new_diff: Option<usize> = None;
    for i in 0..3 {
        let r = Rect::new(x + i as f32 * (bw + gap), y, bw, 38.0 * u);
        if ui.button(r, DIFFS[i].name, true, st.profile.diff == i, 15.0) {
            new_diff = Some(i);
        }
    }
    if let Some(d) = new_diff {
        st.profile.diff = d;
        save_profile(&st.profile);
    }
    y += 48.0 * u;
    for l in ui.wrap(DIFFS[st.profile.diff].desc, cw, 13.0) {
        ui.text(&l, x, y + 12.0 * u, 13.0, col("#a89fc0"));
        y += 18.0 * u;
    }
    y += 10.0 * u;

    if ui.button(Rect::new(x, y, cw, 58.0 * u), "Начать спуск", true, false, 22.0) {
        start_run(st);
        return;
    }
    y += 70.0 * u;
    if ui.button(Rect::new(x, y, cw, 46.0 * u), "Играть по сети (2 игрока)", true, false, 18.0) {
        st.profile.fix_selection();
        st.online = None;
        st.net_msg.clear();
        st.addr = st.profile.addr.clone();
        st.screen = Screen::Online;
        st.scroll = 0.0;
        return;
    }
    y += 62.0 * u;

    // герои
    ui.text("Герои и задания", x, y + 16.0 * u, 18.0, WHITE);
    y += 28.0 * u;
    let mut pick_hero: Option<usize> = None;
    let mut quiz_hero: Option<usize> = None;
    for i in 0..CHARACTERS.len() {
        let c = &CHARACTERS[i];
        let ok = st.profile.unlocked(i);
        let hide = c.secret && !ok;
        let title = if hide { "???".to_string() } else { format!("{} · ♥{}", c.name, c.hp) };
        let sub = if ok {
            c.description.to_string()
        } else if c.secret {
            "???".to_string()
        } else {
            let pr = st.profile.progress(i);
            if pr.is_empty() {
                format!("Задание: {}", c.quest)
            } else {
                format!("Задание: {} ({})", c.quest, pr)
            }
        };
        let btn_w = 118.0 * u;
        let lines = ui.wrap(&sub, cw - btn_w - 36.0 * u, 12.0);
        let h = (30.0 + lines.len() as f32 * 16.0 + 10.0) * u;
        card(x, y, cw, h);
        let (sr, sg, sb) = smolik_core::defs::rgb(c.color);
        draw_circle(x + 18.0 * u, y + h / 2.0, 9.0 * u, Color::from_rgba(sr, sg, sb, 255));
        ui.text(&title, x + 36.0 * u, y + 20.0 * u, 15.0, WHITE);
        for (k, l) in lines.iter().enumerate() {
            ui.text(l, x + 36.0 * u, y + (36.0 + k as f32 * 16.0) * u, 12.0, col("#a89fc0"));
        }
        let selected = st.profile.sel == i && ok;
        let label = if selected {
            "выбран"
        } else if ok {
            "взять"
        } else if st.profile.needs_quiz(i) {
            "Опрос"
        } else {
            "закрыт"
        };
        let enabled = ok || st.profile.needs_quiz(i);
        let r = Rect::new(x + cw - btn_w - 8.0 * u, y + h / 2.0 - 17.0 * u, btn_w, 34.0 * u);
        if ui.button(r, label, enabled, selected, 14.0) {
            if ok {
                pick_hero = Some(i);
            } else {
                quiz_hero = Some(i);
            }
        }
        y += h + 6.0 * u;
    }
    if let Some(i) = pick_hero {
        st.profile.sel = i;
        save_profile(&st.profile);
    }
    if let Some(i) = quiz_hero {
        st.screen = Screen::Quiz { hero: i, k: 0 };
        return;
    }
    y += 10.0 * u;

    // кузница
    ui.text("Кузница", x, y + 16.0 * u, 18.0, WHITE);
    y += 28.0 * u;
    let mut buy: Option<usize> = None;
    for k in 0..3 {
        card(x, y, cw, 46.0 * u);
        let lvl = st.profile.up[k].min(UPGRADE_MAX);
        ui.text(&format!("{} ({}/{})", UPGRADE_NAMES[k], lvl, UPGRADE_MAX), x + 12.0 * u, y + 28.0 * u, 14.0, WHITE);
        let maxed = st.profile.up[k] >= UPGRADE_MAX;
        let label = if maxed { "макс".to_string() } else { format!("{} монет", st.profile.upgrade_cost(k)) };
        let r = Rect::new(x + cw - 130.0 * u, y + 6.0 * u, 122.0 * u, 34.0 * u);
        if ui.button(r, &label, !maxed && st.profile.can_upgrade(k), false, 14.0) {
            buy = Some(k);
        }
        y += 52.0 * u;
    }
    if let Some(k) = buy {
        if st.profile.buy_upgrade(k) {
            save_profile(&st.profile);
        }
    }
    y += 10.0 * u;

    // управление
    ui.text("Управление", x, y + 16.0 * u, 18.0, WHITE);
    y += 28.0 * u;
    let help = [
        "WASD — движение. Стрелки или зажатая левая кнопка мыши — стрельба.",
        "Пробел — активный предмет. B или E — бросить бомбу. Tab — характеристики. Esc — пауза.",
        "На телефоне: левая половина экрана — стик движения, правая — стик стрельбы.",
        "Зачисти все комнаты этажа, победи босса, спустись по лестнице. На 6 этаже выбери Ад или Рай.",
    ];
    for h in help.iter() {
        for l in ui.wrap(h, cw, 13.0) {
            ui.text(&l, x, y + 12.0 * u, 13.0, col("#a89fc0"));
            y += 18.0 * u;
        }
        y += 4.0 * u;
    }
    y += 10.0 * u;
    ui.text("Разработчики: @Krosmoz, @Puwuzo", x, y + 12.0 * u, 13.0, col("#7a7090"));
    y += 30.0 * u;
    if ui.button(Rect::new(x, y, cw, 40.0 * u), "Выйти из игры", true, false, 15.0) {
        std::process::exit(0);
    }
    y += 60.0 * u;

    let total = y + st.scroll;
    let max_scroll = (total - sh).max(0.0);
    st.scroll = st.scroll.max(0.0).min(max_scroll);

    if let Some((m, _)) = st.msg.as_ref() {
        let w = (ui.width(m, 15.0) + 30.0 * u).min(sw - 20.0);
        draw_rectangle(sw / 2.0 - w / 2.0, 6.0 * u, w, 32.0 * u, Color::new(0.0, 0.0, 0.0, 0.8));
        ui.text_c(m, sw / 2.0, 28.0 * u, 15.0, col("#f0c030"));
    }
}

fn start_run(st: &mut State) {
    st.profile.fix_selection();
    st.profile.start_run();
    save_profile(&st.profile);
    let seed = (macroquad::miniquad::date::now() * 1000.0) as u64 as u32;
    let g = Game::new(st.profile.sel, st.profile.up, st.profile.diff, seed);
    st.online = None;
    st.game = Some(g);
    st.screen = Screen::Play;
    st.paused = false;
    st.over_t = 0.0;
    st.aim_block = false;
    st.sticks = Sticks::default();
}

// ---------------------------------------------------------------- опрос

fn quiz(ui: &Ui, st: &mut State, hero: usize, k: usize) {
    clear_background(col("#14111f"));
    let u = ui.u;
    let sw = screen_width();
    let sh = screen_height();
    let (title, qs) = match quiz_for(hero) {
        Some(q) => q,
        None => {
            st.screen = Screen::Menu;
            return;
        }
    };
    let w = (sw - 24.0 * u).min(460.0 * u);
    let x = (sw - w) / 2.0;
    let y = sh * 0.16;
    card(x, y, w, 360.0 * u);
    let c = &CHARACTERS[hero];
    let (r, g, b) = smolik_core::defs::rgb(c.color);
    draw_circle(sw / 2.0, y + 56.0 * u, 34.0 * u, Color::from_rgba(r, g, b, 255));
    draw_circle_lines(sw / 2.0, y + 56.0 * u, 34.0 * u, 3.0, col("#1a1410"));
    ui.text_c(title, sw / 2.0, y + 112.0 * u, 14.0, col("#a89fc0"));
    ui.text_c(&format!("{} · {}/5", c.name, k + 1), sw / 2.0, y + 136.0 * u, 16.0, WHITE);
    let mut ty = y + 176.0 * u;
    for l in ui.wrap(qs[k.min(4)], w - 30.0 * u, 20.0) {
        ui.text_c(&l, sw / 2.0, ty, 20.0, WHITE);
        ty += 26.0 * u;
    }
    let by = y + 240.0 * u;
    let yes = ui.button(Rect::new(x + 16.0 * u, by, w - 32.0 * u, 40.0 * u), "Да", true, false, 17.0);
    let no = ui.button(Rect::new(x + 16.0 * u, by + 48.0 * u, (w - 40.0 * u) / 2.0, 36.0 * u), "Нет", true, false, 15.0);
    let close = ui.button(Rect::new(x + 24.0 * u + (w - 40.0 * u) / 2.0, by + 48.0 * u, (w - 40.0 * u) / 2.0, 36.0 * u), "Закрыть", true, false, 15.0);
    if yes {
        if k + 1 >= 5 {
            st.profile.quiz[hero] = true;
            save_profile(&st.profile);
            let msg = format!("Новый герой открыт: {}!", c.name);
            st.say(&msg);
            st.screen = Screen::Menu;
        } else {
            st.screen = Screen::Quiz { hero, k: k + 1 };
        }
    } else if no {
        st.say("Неправильный ответ. Попробуй ещё раз!");
        st.screen = Screen::Menu;
    } else if close {
        st.screen = Screen::Menu;
    }
}

// ---------------------------------------------------------------- забег

#[cfg(any(target_os = "android", target_os = "ios"))]
fn touch_input(ui: &Ui, s: &mut Sticks) -> (bool, bool) {
    let jr = 55.0 * ui.u;
    let (ax_, ay_, ar) = draw::act_btn(ui);
    let (bx, by, br) = draw::bomb_btn(ui);
    let half = screen_width() / 2.0;
    let mut act = false;
    let mut bomb = false;
    let ts = touches();
    let mut seen_m = false;
    let mut seen_a = false;
    for t in ts.iter() {
        let pos = t.position;
        let started = matches!(t.phase, TouchPhase::Started);
        if started {
            if (pos - vec2(ax_, ay_)).length() < ar * 1.2 {
                act = true;
                continue;
            }
            if (pos - vec2(bx, by)).length() < br * 1.2 {
                bomb = true;
                continue;
            }
            if pos.x < half && s.m_id.is_none() {
                s.m_id = Some(t.id);
                s.m_o = pos;
            } else if pos.x >= half && s.a_id.is_none() {
                s.a_id = Some(t.id);
                s.a_o = pos;
            }
        }
        if s.m_id == Some(t.id) {
            seen_m = true;
            let d = (pos - s.m_o) / jr;
            s.m_v = if d.length() > 1.0 { d.normalize() } else { d };
        }
        if s.a_id == Some(t.id) {
            seen_a = true;
            let d = (pos - s.a_o) / jr;
            s.a_v = if d.length() > 1.0 { d.normalize() } else { d };
        }
    }
    if !seen_m {
        s.m_id = None;
        s.m_v = vec2(0.0, 0.0);
    }
    if !seen_a {
        s.a_id = None;
        s.a_v = vec2(0.0, 0.0);
    }
    (act, bomb)
}

#[cfg(not(any(target_os = "android", target_os = "ios")))]
fn touch_input(_ui: &Ui, _s: &mut Sticks) -> (bool, bool) {
    (false, false)
}

fn in_circle(p: Vec2, c: (f32, f32, f32)) -> bool {
    (p - vec2(c.0, c.1)).length() <= c.2
}

fn play(ui: &Ui, st: &mut State) {
    let dt = get_frame_time().min(0.033);
    let u = ui.u;
    let sw = screen_width();
    let sh = screen_height();
    let mut done: Option<RunResult> = None;
    let mut client_left = false;
    {
        let g = match st.game.as_mut() {
            Some(g) => g,
            None => {
                st.screen = Screen::Menu;
                return;
            }
        };
        let is_client = matches!(st.online, Some(Online::ClientGame(_)));
        let cam = draw::make_cam(g);

        // --- ввод
        let mut inp = Input::default();
        if is_key_down(KeyCode::W) {
            inp.iy -= 1.0;
        }
        if is_key_down(KeyCode::S) {
            inp.iy += 1.0;
        }
        if is_key_down(KeyCode::A) {
            inp.ix -= 1.0;
        }
        if is_key_down(KeyCode::D) {
            inp.ix += 1.0;
        }
        if is_key_down(KeyCode::Up) {
            inp.ay -= 1.0;
        }
        if is_key_down(KeyCode::Down) {
            inp.ay += 1.0;
        }
        if is_key_down(KeyCode::Left) {
            inp.ax -= 1.0;
        }
        if is_key_down(KeyCode::Right) {
            inp.ax += 1.0;
        }
        let (mut act, mut bomb) = touch_input(ui, &mut st.sticks);
        inp.ix += st.sticks.m_v.x;
        inp.iy += st.sticks.m_v.y;
        inp.ax += st.sticks.a_v.x;
        inp.ay += st.sticks.a_v.y;

        let act_c = draw::act_btn(ui);
        let bomb_c = draw::bomb_btn(ui);
        let pause_r = draw::pause_btn(ui);
        let (mx, my) = mouse_position();
        let mp = vec2(mx, my);
        if is_mouse_button_pressed(MouseButton::Left) {
            st.aim_block = in_circle(mp, act_c) || in_circle(mp, bomb_c) || pause_r.contains(mp) || g.choose || st.paused;
        }
        if !is_mouse_button_down(MouseButton::Left) {
            st.aim_block = false;
        }
        if is_mouse_button_down(MouseButton::Left) && touches().is_empty() && !st.aim_block && !st.paused {
            let v = vec2(mx - cam.sx(g.p.x), my - cam.sy(g.p.y));
            if v.length() > 4.0 {
                let n = v.normalize();
                inp.ax = n.x;
                inp.ay = n.y;
            }
        }
        if is_key_pressed(KeyCode::Space) {
            act = true;
        }
        if is_key_pressed(KeyCode::B) || is_key_pressed(KeyCode::E) {
            bomb = true;
        }
        if let Some(c) = ui.click {
            if !st.paused && !g.choose {
                if in_circle(c, act_c) {
                    act = true;
                }
                if in_circle(c, bomb_c) {
                    bomb = true;
                }
                if pause_r.contains(c) {
                    st.paused = true;
                }
            }
        }
        if is_key_pressed(KeyCode::Escape) && !g.choose && !g.over {
            st.paused = !st.paused;
        }

        // --- шаг
        match st.online.as_mut() {
            Some(Online::HostGame(link)) => {
                // по сети пауза не останавливает игру: друг продолжает играть
                let rem = link.pump(dt);
                if link.closed && g.p2.is_some() {
                    g.p2 = None;
                    g.say("Друг отключился. Дальше играешь один");
                }
                if !g.over && !g.choose {
                    let (i2, a2, b2) = if st.paused { (Input::default(), false, false) } else { (inp, act, bomb) };
                    g.update_with(dt, &i2, rem.as_ref());
                    if a2 {
                        g.use_act();
                    }
                    if b2 {
                        g.throw_bomb();
                    }
                }
                link.send(g, dt);
            }
            Some(Online::ClientGame(link)) => {
                link.pump(g);
                if link.closed && !g.over {
                    g.give_up();
                    client_left = true;
                }
                let live = !st.paused && !g.choose;
                let i2 = if live { inp } else { Input::default() };
                g.client_step(dt, &i2);
                link.send(g, &i2, act && live, bomb && live, dt);
            }
            _ => {
                if !st.paused && !g.over && !g.choose {
                    g.update(dt, &inp);
                    if act {
                        g.use_act();
                    }
                    if bomb {
                        g.throw_bomb();
                    }
                }
            }
        }

        // --- рисование
        draw::draw_game(ui, g);
        if !st.paused && touches().len() > 0 {
            for (id, o, v) in [(st.sticks.m_id, st.sticks.m_o, st.sticks.m_v), (st.sticks.a_id, st.sticks.a_o, st.sticks.a_v)].iter() {
                if id.is_some() {
                    draw_circle(o.x, o.y, 55.0 * u, Color::new(1.0, 1.0, 1.0, 0.18));
                    draw_circle(o.x + v.x * 55.0 * u, o.y + v.y * 55.0 * u, 22.0 * u, Color::new(1.0, 1.0, 1.0, 0.5));
                }
            }
        }

        if g.choose {
            draw_rectangle(0.0, 0.0, sw, sh, Color::new(0.0, 0.0, 0.0, 0.8));
            if is_client {
                ui.text_oc("Хост выбирает путь…", sw / 2.0, sh * 0.45, 28.0, col("#f0c030"));
            } else {
                ui.text_oc("Выбери путь", sw / 2.0, sh * 0.3, 30.0, col("#f0c030"));
                let w = (sw - 40.0 * u).min(560.0 * u);
                let bw = (w - 16.0 * u) / 2.0;
                let x = (sw - w) / 2.0;
                let hell = ui.button(Rect::new(x, sh * 0.4, bw, 90.0 * u), "Ад", true, false, 26.0);
                let heaven = ui.button(Rect::new(x + bw + 16.0 * u, sh * 0.4, bw, 90.0 * u), "Рай", true, false, 26.0);
                ui.text_c("Ад: огонь, демоны, Сатана. Рай: ангелы, свет, Архангел.", sw / 2.0, sh * 0.4 + 120.0 * u, 14.0, col("#bbbbbb"));
                ui.text_c("3 этажа, новые боссы и предметы.", sw / 2.0, sh * 0.4 + 142.0 * u, 14.0, col("#bbbbbb"));
                if hell {
                    g.choose_path(Path::Hell);
                } else if heaven {
                    g.choose_path(Path::Heaven);
                }
            }
        }

        if st.paused && !g.over {
            draw_rectangle(0.0, 0.0, sw, sh, Color::new(0.0, 0.0, 0.0, 0.7));
            ui.text_oc(if st.online.is_some() { "Меню (игра по сети идёт)" } else { "Пауза" }, sw / 2.0, sh * 0.3, 30.0, WHITE);
            let w = (sw - 40.0 * u).min(360.0 * u);
            let x = (sw - w) / 2.0;
            if ui.button(Rect::new(x, sh * 0.38, w, 52.0 * u), "Продолжить", true, false, 20.0) {
                st.paused = false;
            }
            if ui.button(Rect::new(x, sh * 0.38 + 64.0 * u, w, 52.0 * u), "Сдаться (монеты сохранятся)", true, false, 16.0) {
                st.paused = false;
                if is_client {
                    done = Some(g.result());
                } else {
                    g.give_up();
                }
            }
        }

        if g.over {
            st.over_t += dt;
            if st.over_t > 0.7 {
                done = Some(g.result());
            }
        }
    }

    if let Some(res) = done {
        let before: Vec<bool> = (0..CHARACTERS.len()).map(|i| st.profile.unlocked(i)).collect();
        st.profile.apply_run(&res);
        save_profile(&st.profile);
        let mut lines: Vec<String> = Vec::new();
        if res.win {
            if st.game.as_ref().map_or(false, |g| g.path.is_some()) {
                let hell = st.game.as_ref().map_or(false, |g| g.path == Some(Path::Hell));
                lines.push(if hell { "КОНЦОВКА: Ад склонился перед тобой!".to_string() } else { "КОНЦОВКА: Рай признал тебя героем!".to_string() });
            } else {
                lines.push("ПОБЕДА! Владыка повержен.".to_string());
            }
        } else {
            lines.push(format!("Вы погибли на этаже {}.", res.floor));
        }
        let earned = res.gold + if res.win { 60 } else { 0 };
        lines.push(format!("Монет получено: {}, убито: {}", earned, res.kills));
        if client_left {
            lines.push("Хост отключился, забег закончен.".to_string());
        }
        for i in 0..CHARACTERS.len() {
            if !before[i] && st.profile.unlocked(i) {
                lines.push(format!("Новый герой открыт: {}!", CHARACTERS[i].name));
            }
        }
        st.summary = lines;
        st.game = None;
        st.online = None;
        st.screen = Screen::Summary;
        st.scroll = 0.0;
    }
}

// ---------------------------------------------------------------- игра по сети

fn start_online_host(st: &mut State) {
    let mut lobby = match st.online.take() {
        Some(Online::Host(l)) => l,
        other => {
            st.online = other;
            return;
        }
    };
    let guest = match lobby.guest.take() {
        Some(g) => g,
        None => {
            st.online = Some(Online::Host(lobby));
            return;
        }
    };
    st.profile.fix_selection();
    st.profile.start_run();
    save_profile(&st.profile);
    let seed = (macroquad::miniquad::date::now() * 1000.0) as u64 as u32;
    let mut g = Game::new(st.profile.sel, st.profile.up, st.profile.diff, seed);
    g.add_player2(guest.hero, guest.up);
    g.rec_parts = true;
    st.game = Some(g);
    st.online = Some(Online::HostGame(net::HostLink::new(guest.conn)));
    st.screen = Screen::Play;
    st.paused = false;
    st.over_t = 0.0;
    st.aim_block = false;
    st.sticks = Sticks::default();
}

fn start_online_client(st: &mut State, g: Game, link: net::ClientLink) {
    st.profile.start_run();
    save_profile(&st.profile);
    st.game = Some(g);
    st.online = Some(Online::ClientGame(link));
    st.screen = Screen::Play;
    st.paused = false;
    st.over_t = 0.0;
    st.aim_block = false;
    st.sticks = Sticks::default();
}

/// Двигает сетевое состояние лобби: принимает друга, ждёт ответ хоста, запускает игру клиента.
fn online_tick(st: &mut State) {
    let dt = get_frame_time();
    match st.online.take() {
        None => {}
        Some(Online::Host(mut lobby)) => {
            lobby.update(dt);
            st.online = Some(Online::Host(lobby));
        }
        Some(Online::Connecting(rx)) => match rx.try_recv() {
            Ok(Ok(stream)) => match net::Conn::new(stream) {
                Ok(conn) => {
                    let w = net::ClientWait::new(conn, st.profile.sel, st.profile.up);
                    st.online = Some(Online::Wait(w));
                }
                Err(e) => st.net_msg = format!("Ошибка соединения: {}", e),
            },
            Ok(Err(m)) => st.net_msg = m,
            Err(std::sync::mpsc::TryRecvError::Empty) => st.online = Some(Online::Connecting(rx)),
            Err(_) => st.net_msg = "Подключение прервано".to_string(),
        },
        Some(Online::Wait(mut w)) => match w.update() {
            net::WaitResult::Waiting => st.online = Some(Online::Wait(w)),
            net::WaitResult::Failed(m) => st.net_msg = m,
            net::WaitResult::Start(g, link) => start_online_client(st, g, link),
        },
        other => st.online = other,
    }
}

fn online_screen(ui: &Ui, st: &mut State, scroll: f32) {
    online_tick(st);
    if matches!(st.screen, Screen::Play) {
        return;
    }
    clear_background(col("#14111f"));
    let u = ui.u;
    let sw = screen_width();
    let sh = screen_height();
    let cw = (sw - 24.0 * u).min(640.0 * u);
    let x = (sw - cw) / 2.0;
    st.scroll += scroll;

    // что сейчас происходит
    let mut mode = 0u8;
    let mut ip = String::new();
    let mut guest_name: Option<&'static str> = None;
    let mut lobby_msg = String::new();
    let mut wait_msg = String::new();
    match st.online.as_ref() {
        Some(Online::Host(l)) => {
            mode = 1;
            ip = l.ip.clone().unwrap_or_default();
            guest_name = l.guest.as_ref().map(|g| CHARACTERS[g.hero].name);
            lobby_msg = l.msg.clone();
        }
        Some(Online::Connecting(_)) => mode = 2,
        Some(Online::Wait(w)) => {
            mode = 3;
            wait_msg = w.msg.clone();
        }
        _ => {}
    }

    let mut want_host = false;
    let mut want_join = false;
    let mut want_start = false;
    let mut want_back = is_key_pressed(KeyCode::Escape);
    if mode == 0 {
        while let Some(c) = get_char_pressed() {
            if (c.is_ascii_alphanumeric() || c == '.' || c == ':' || c == '-' || c == '[' || c == ']') && st.addr.len() < 60 {
                st.addr.push(c);
            }
        }
        if is_key_pressed(KeyCode::Backspace) {
            st.addr.pop();
        }
        if is_key_pressed(KeyCode::Enter) && !st.addr.trim().is_empty() {
            want_join = true;
        }
    }

    let mut y = 24.0 * u - st.scroll;
    ui.text_oc("Игра по сети", sw / 2.0, y + 30.0 * u, 34.0, col("#f0c030"));
    y += 54.0 * u;
    for l in ui.wrap("Кооператив на двоих: один создаёт игру, второй подключается по адресу. У каждого свой герой и своя кузница, сложность выбирает хост.", cw, 13.0) {
        ui.text(&l, x, y + 12.0 * u, 13.0, col("#a89fc0"));
        y += 18.0 * u;
    }
    y += 10.0 * u;
    if !st.net_msg.is_empty() {
        for l in ui.wrap(&st.net_msg, cw, 15.0) {
            ui.text(&l, x, y + 12.0 * u, 15.0, col("#ff8a6a"));
            y += 20.0 * u;
        }
        y += 8.0 * u;
    }

    if mode == 0 {
        if ui.button(Rect::new(x, y, cw, 52.0 * u), "Создать игру (я хост)", true, false, 20.0) {
            want_host = true;
        }
        y += 68.0 * u;
        ui.text("Или подключись к другу:", x, y + 14.0 * u, 16.0, WHITE);
        y += 26.0 * u;
        draw_rectangle(x, y, cw, 40.0 * u, Color::from_rgba(24, 20, 36, 255));
        draw_rectangle_lines(x, y, cw, 40.0 * u, 2.0, Color::from_rgba(200, 150, 40, 255));
        let caret = if ((get_time() * 2.0) as i64) % 2 == 0 { "|" } else { "" };
        if st.addr.is_empty() {
            ui.text("адрес хоста, например 192.168.0.5", x + 10.0 * u, y + 26.0 * u, 16.0, col("#6f6688"));
        } else {
            let shown = format!("{}{}", st.addr, caret);
            ui.text(&shown, x + 10.0 * u, y + 26.0 * u, 18.0, WHITE);
        }
        y += 52.0 * u;
        let keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", ".", ":", "←"];
        let gap = 6.0 * u;
        let bw = (cw - gap * 6.0) / 7.0;
        let bh = 40.0 * u;
        for (i, k) in keys.iter().enumerate() {
            let r = Rect::new(x + (i % 7) as f32 * (bw + gap), y + (i / 7) as f32 * (bh + gap), bw, bh);
            if ui.button(r, k, true, false, 18.0) {
                if *k == "←" {
                    st.addr.pop();
                } else if st.addr.len() < 60 {
                    st.addr.push_str(k);
                }
            }
        }
        y += 2.0 * (bh + gap) + 6.0 * u;
        if ui.button(Rect::new(x, y, cw, 52.0 * u), "Подключиться", !st.addr.trim().is_empty(), false, 20.0) {
            want_join = true;
        }
        y += 68.0 * u;
        ui.text("Порт по умолчанию 7777. Можно ввести и так: 1.2.3.4:5555", x, y + 12.0 * u, 12.0, col("#8a82a0"));
        y += 28.0 * u;
    } else if mode == 1 {
        ui.text("Ждём друга…", x, y + 18.0 * u, 20.0, WHITE);
        y += 34.0 * u;
        let line = if ip.is_empty() { format!("Порт: {}", net::PORT) } else { format!("Твой адрес в локальной сети: {}:{}", ip, net::PORT) };
        ui.text(&line, x, y + 14.0 * u, 16.0, col("#9ad0ff"));
        y += 28.0 * u;
        for l in ui.wrap("Через интернет: пробрось TCP-порт 7777 на роутере, либо используй VPN (Radmin, ZeroTier, Tailscale) или туннель «ngrok tcp 7777». Другу отдай тот адрес, что покажет сервис.", cw, 13.0) {
            ui.text(&l, x, y + 12.0 * u, 13.0, col("#a89fc0"));
            y += 18.0 * u;
        }
        y += 10.0 * u;
        match guest_name {
            Some(n) => ui.text(&format!("Друг подключился: {}", n), x, y + 16.0 * u, 18.0, col("#7be07b")),
            None => ui.text("Пока никого нет", x, y + 16.0 * u, 18.0, col("#c8bfd8")),
        }
        y += 32.0 * u;
        if !lobby_msg.is_empty() {
            ui.text(&lobby_msg, x, y + 14.0 * u, 14.0, col("#ff8a6a"));
            y += 24.0 * u;
        }
        if ui.button(Rect::new(x, y, cw, 56.0 * u), "Начать забег", guest_name.is_some(), false, 22.0) {
            want_start = true;
        }
        y += 72.0 * u;
    } else if mode == 2 {
        let line = format!("Подключаемся к {}…", st.profile.addr);
        ui.text(&line, x, y + 18.0 * u, 18.0, WHITE);
        y += 40.0 * u;
    } else {
        ui.text(&wait_msg, x, y + 18.0 * u, 18.0, WHITE);
        y += 40.0 * u;
    }

    let back = if mode == 0 { "Назад в меню" } else { "Отмена" };
    if ui.button(Rect::new(x, y, cw, 46.0 * u), back, true, false, 17.0) {
        want_back = true;
    }
    y += 62.0 * u;
    let total = y + st.scroll;
    let max_scroll = (total - sh).max(0.0);
    st.scroll = st.scroll.max(0.0).min(max_scroll);

    if want_host {
        st.profile.fix_selection();
        let w = smolik_core::wire::encode_welcome(st.profile.diff, st.profile.sel);
        match net::Lobby::new(w) {
            Ok(l) => {
                st.online = Some(Online::Host(l));
                st.net_msg.clear();
            }
            Err(e) => st.net_msg = e,
        }
    } else if want_join {
        st.profile.addr = st.addr.trim().to_string();
        save_profile(&st.profile);
        st.net_msg.clear();
        st.online = Some(Online::Connecting(net::connect_async(st.profile.addr.clone())));
    } else if want_start {
        start_online_host(st);
    } else if want_back {
        let was_idle = st.online.is_none();
        st.online = None;
        st.net_msg.clear();
        if was_idle {
            st.screen = Screen::Menu;
            st.scroll = 0.0;
        }
    }
}

fn summary(ui: &Ui, st: &mut State) {
    clear_background(col("#14111f"));
    let u = ui.u;
    let sw = screen_width();
    let sh = screen_height();
    let w = (sw - 24.0 * u).min(520.0 * u);
    let x = (sw - w) / 2.0;
    let y = sh * 0.2;
    ui.text_oc("Забег окончен", sw / 2.0, y, 34.0, col("#f0c030"));
    let mut ty = y + 50.0 * u;
    for l in st.summary.iter() {
        for part in ui.wrap(l, w, 18.0) {
            ui.text_c(&part, sw / 2.0, ty, 18.0, WHITE);
            ty += 28.0 * u;
        }
    }
    if ui.button(Rect::new(x, ty + 24.0 * u, w, 56.0 * u), "В меню", true, false, 20.0) || is_key_pressed(KeyCode::Enter) {
        st.screen = Screen::Menu;
        st.scroll = 0.0;
    }
}
