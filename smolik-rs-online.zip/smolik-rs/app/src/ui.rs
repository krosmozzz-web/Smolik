//! Мелкий слой интерфейса поверх macroquad: текст с кириллицей, кнопки, перенос строк, прокрутка.
use macroquad::prelude::*;
use smolik_core::defs::rgb;

pub fn col(h: &str) -> Color {
    let (r, g, b) = rgb(h);
    Color::from_rgba(r, g, b, 255)
}

pub fn cola(h: &str, a: u8) -> Color {
    let (r, g, b) = rgb(h);
    Color::from_rgba(r, g, b, a)
}

pub fn rgba(c: (u8, u8, u8), a: u8) -> Color {
    Color::from_rgba(c.0, c.1, c.2, a)
}

pub fn shade(c: Color, k: f32) -> Color {
    Color::new((c.r * k).min(1.0), (c.g * k).min(1.0), (c.b * k).min(1.0), c.a)
}

pub struct Ui {
    pub font: Font,
    /// Масштаб интерфейса: 1.0 при высоте окна 720.
    pub u: f32,
    /// Клик (отпускание без перетаскивания) в этом кадре.
    pub click: Option<Vec2>,
    pub mouse: Vec2,
    press: Option<Vec2>,
    dragged: bool,
    last: Vec2,
}

impl Ui {
    pub fn new(font: Font) -> Ui {
        Ui { font, u: 1.0, click: None, mouse: vec2(0.0, 0.0), press: None, dragged: false, last: vec2(0.0, 0.0) }
    }

    /// Обновляет мышь/касание. Возвращает сдвиг прокрутки в пикселях (положительный — вниз по списку).
    pub fn begin_frame(&mut self) -> f32 {
        self.u = (screen_height() / 720.0).max(0.7).min(2.5);
        let (mx, my) = mouse_position();
        let m = vec2(mx, my);
        self.mouse = m;
        self.click = None;
        let mut scroll = 0.0;
        if is_mouse_button_pressed(MouseButton::Left) {
            self.press = Some(m);
            self.dragged = false;
            self.last = m;
        }
        if is_mouse_button_down(MouseButton::Left) {
            if let Some(p) = self.press {
                if (m - p).length() > 8.0 {
                    self.dragged = true;
                }
                if self.dragged {
                    scroll = self.last.y - m.y;
                }
            }
            self.last = m;
        }
        if is_mouse_button_released(MouseButton::Left) {
            if !self.dragged {
                self.click = Some(m);
            }
            self.press = None;
            self.dragged = false;
        }
        scroll -= mouse_wheel().1 * 40.0;
        scroll
    }

    pub fn size(&self, s: f32) -> u16 {
        (s * self.u).round().max(8.0) as u16
    }

    pub fn text(&self, s: &str, x: f32, y: f32, size: f32, color: Color) {
        draw_text_ex(s, x, y, TextParams { font: Some(&self.font), font_size: self.size(size), color, ..Default::default() });
    }

    pub fn width(&self, s: &str, size: f32) -> f32 {
        measure_text(s, Some(&self.font), self.size(size), 1.0).width
    }

    pub fn text_c(&self, s: &str, cx: f32, y: f32, size: f32, color: Color) {
        let w = self.width(s, size);
        self.text(s, cx - w / 2.0, y, size, color);
    }

    pub fn text_r(&self, s: &str, rx: f32, y: f32, size: f32, color: Color) {
        let w = self.width(s, size);
        self.text(s, rx - w, y, size, color);
    }

    /// Текст с тёмной обводкой, читается на любом фоне.
    pub fn text_o(&self, s: &str, x: f32, y: f32, size: f32, color: Color) {
        let d = (1.5 * self.u).max(1.0);
        let k = Color::new(0.0, 0.0, 0.0, 0.85);
        self.text(s, x - d, y, size, k);
        self.text(s, x + d, y, size, k);
        self.text(s, x, y - d, size, k);
        self.text(s, x, y + d, size, k);
        self.text(s, x, y, size, color);
    }

    pub fn text_oc(&self, s: &str, cx: f32, y: f32, size: f32, color: Color) {
        let w = self.width(s, size);
        self.text_o(s, cx - w / 2.0, y, size, color);
    }

    /// Перенос по словам под заданную ширину.
    pub fn wrap(&self, s: &str, max_w: f32, size: f32) -> Vec<String> {
        let mut lines: Vec<String> = Vec::new();
        let mut cur = String::new();
        for word in s.split_whitespace() {
            let cand = if cur.is_empty() { word.to_string() } else { format!("{} {}", cur, word) };
            if self.width(&cand, size) <= max_w || cur.is_empty() {
                cur = cand;
            } else {
                lines.push(cur);
                cur = word.to_string();
            }
        }
        if !cur.is_empty() {
            lines.push(cur);
        }
        lines
    }

    /// Кнопка. Возвращает true, если по ней кликнули в этом кадре.
    pub fn button(&self, r: Rect, label: &str, enabled: bool, active: bool, size: f32) -> bool {
        let hover = r.contains(self.mouse);
        let bg = if !enabled {
            Color::from_rgba(40, 36, 48, 255)
        } else if active {
            Color::from_rgba(200, 150, 40, 255)
        } else if hover {
            Color::from_rgba(96, 76, 140, 255)
        } else {
            Color::from_rgba(66, 54, 96, 255)
        };
        draw_rectangle(r.x, r.y, r.w, r.h, bg);
        draw_rectangle_lines(r.x, r.y, r.w, r.h, 2.0, Color::from_rgba(20, 16, 28, 255));
        let tc = if !enabled {
            Color::from_rgba(140, 136, 150, 255)
        } else if active {
            Color::from_rgba(30, 20, 10, 255)
        } else {
            WHITE
        };
        self.text_c(label, r.x + r.w / 2.0, r.y + r.h / 2.0 + size * self.u * 0.35, size, tc);
        enabled && self.click.map_or(false, |c| r.contains(c))
    }
}
