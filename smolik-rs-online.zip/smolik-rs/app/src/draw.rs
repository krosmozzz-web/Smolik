//! Отрисовка мира, существ и интерфейса боя. Всё рисуется примитивами и пиксельными спрайтами из `data.rs`.
use crate::ui::*;
use macroquad::prelude::*;
use smolik_core::data::{CHARACTERS, ITEMS};
use smolik_core::defs::*;
use smolik_core::dungeon::{CH, CW};
use smolik_core::game::{Bullet, Game, Monster, PickKind, Player, Skin};
use std::cell::RefCell;
use std::collections::HashMap;

static COIN: [&str; 8] = ["..kkkk..", ".kggggk.", "kgyyyygk", "kgygggyk", "kgygggyk", "kgyyyygk", ".kggggk.", "..kkkk.."];
static KEY: [&str; 8] = ["..kkk...", ".kgggk..", ".kg.gk..", ".kgggk..", "..kgk...", "..kgkk..", "..kgk...", "..kgkk.."];
static BOMB: [&str; 8] = ["....kyk.", ".....k..", "..kkkk..", ".kkwkkk.", "kkwkkkkk", "kkkkkkkk", ".kkkkkk.", "..kkkk.."];
static CHEST: [&str; 8] = ["kkkkkkkk", "knnnnnnk", "knnnnnnk", "kkkggkkk", "knnggnnk", "knnnnnnk", "knnnnnnk", "kkkkkkkk"];
static GCHEST: [&str; 8] = ["kkkkkkkk", "kggggggk", "kyyyyyyk", "kkkrrkkk", "kggrrggk", "kggggggk", "kggggggk", "kkkkkkkk"];
static BARREL: [&str; 8] = [".kkkkkk.", "knnnnnnk", "kkkkkkkk", "knnrrnnk", "knnrrnnk", "kkkkkkkk", "knnnnnnk", ".kkkkkk."];
static HEART: [&str; 8] = [".kk..kk.", "krrkkrrk", "krwrrrrk", "krrrrrrk", "krrrrrrk", ".krrrrk.", "..krrk..", "...kk..."];
static SHIELD: [&str; 8] = ["kkkkkkkk", "kbbbbbbk", "kbbwwbbk", "kbbwwbbk", ".kbbbbk.", "..kbbk..", "...kk...", "........"];
const SKULL_ITEM: usize = 32;

pub struct Cam {
    pub x0: f32,
    pub y0: f32,
    pub s: f32,
    pub ox: f32,
    pub oy: f32,
}

impl Cam {
    pub fn sx(&self, x: f32) -> f32 {
        (x - self.x0) * self.s + self.ox
    }
    pub fn sy(&self, y: f32) -> f32 {
        (y - self.y0) * self.s + self.oy
    }
}

pub fn make_cam(g: &Game) -> Cam {
    let sw = screen_width();
    let sh = screen_height();
    let s = (sw / 11.0).min(sh / 10.0).floor().max(12.0);
    let vw = sw / s;
    let vh = sh / s;
    let r = g.room();
    let cw = CW as f32;
    let ch = CH as f32;
    let gx0 = r.gx as f32 * cw;
    let gy0 = r.gy as f32 * ch;
    let (fx, fy) = match g.p2.as_ref() {
        Some(q) if g.p.dead && !q.dead => (q.x, q.y),
        _ => (g.p.x, g.p.y),
    };
    let cxc = if vw >= cw { gx0 + cw / 2.0 } else { fx.max(gx0 + vw / 2.0).min(gx0 + cw - vw / 2.0) };
    let cyc = if vh >= ch { gy0 + ch / 2.0 } else { fy.max(gy0 + vh / 2.0).min(gy0 + ch - vh / 2.0) };
    let mut ox = 0.0f32;
    let mut oy = 0.0f32;
    if g.shake > 0.0 {
        let k = if g.boss_on { 3.0 } else { 1.5 };
        ox = (g.t * 97.0).sin() * k;
        oy = (g.t * 131.0).cos() * k;
    }
    Cam { x0: cxc - vw / 2.0, y0: cyc - vh / 2.0 - 0.3, s, ox, oy }
}

thread_local! {
    static SPRITES: RefCell<HashMap<usize, &'static Texture2D>> = RefCell::new(HashMap::new());
    static HEARTS: RefCell<Vec<&'static Texture2D>> = RefCell::new(Vec::new());
}

fn make_tex(img: &Image) -> &'static Texture2D {
    let tex = Texture2D::from_image(img);
    tex.set_filter(FilterMode::Nearest);
    // текстуры живут до конца программы, поэтому просто «утекают»: так нет проблем с порядком удаления при выходе
    Box::leak(Box::new(tex))
}

/// Пиксельный спрайт рисуется одной текстурой. Раньше каждый кадр это были десятки прямоугольников
/// плюс разбор цвета из строки для каждой клетки.
fn sprite_tex(px: &'static [&'static str]) -> &'static Texture2D {
    let key = px.as_ptr() as usize;
    let cached = SPRITES.with(|c| c.borrow().get(&key).copied());
    if let Some(t) = cached {
        return t;
    }
    let w = px.iter().map(|r| r.chars().count()).max().unwrap_or(1).max(1);
    let h = px.len().max(1);
    let mut img = Image::gen_image_color(w as u16, h as u16, BLANK);
    for (j, row) in px.iter().enumerate() {
        for (i, ch) in row.chars().enumerate() {
            if let Some(c) = pal(ch) {
                img.set_pixel(i as u32, j as u32, Color::from_rgba(c.0, c.1, c.2, 255));
            }
        }
    }
    let t = make_tex(&img);
    SPRITES.with(|c| {
        c.borrow_mut().insert(key, t);
    });
    t
}

pub fn px_draw(px: &'static [&'static str], x: f32, y: f32, size: f32) {
    if px.is_empty() {
        return;
    }
    let tex = sprite_tex(px);
    let w = tex.width();
    let h = tex.height();
    let cell = size / w.max(h);
    draw_texture_ex(tex, x, y, WHITE, DrawTextureParams { dest_size: Some(vec2(w * cell, h * cell)), ..Default::default() });
}

/// Три готовые текстуры сердца: целое, половинка, пустое.
fn heart_tex(k: usize) -> &'static Texture2D {
    let have = HEARTS.with(|c| c.borrow().get(k).copied());
    if let Some(t) = have {
        return t;
    }
    let mut v: Vec<&'static Texture2D> = Vec::new();
    for kk in 0..3usize {
        let mut img = Image::gen_image_color(8, 8, BLANK);
        for (j, row) in HEART.iter().enumerate() {
            for (i, ch) in row.chars().enumerate() {
                if let Some(c) = pal(ch) {
                    let red = ch == 'r' || ch == 'w';
                    let lit = kk == 0 || (kk == 1 && i < 4);
                    let c2 = if red && !lit { (70, 62, 74) } else { c };
                    img.set_pixel(i as u32, j as u32, Color::from_rgba(c2.0, c2.1, c2.2, 255));
                }
            }
        }
        v.push(make_tex(&img));
    }
    HEARTS.with(|c| {
        *c.borrow_mut() = v.clone();
    });
    v[k.min(2)]
}

fn heart_draw(x: f32, y: f32, size: f32, fill: f32) {
    let k = if fill >= 1.0 {
        0
    } else if fill > 0.0 {
        1
    } else {
        2
    };
    draw_texture_ex(heart_tex(k), x, y, WHITE, DrawTextureParams { dest_size: Some(vec2(size, size)), ..Default::default() });
}

fn theme_for(g: &Game) -> &'static Theme {
    let r = g.room();
    let far = g.path.is_some() && g.floor > 6;
    if r.boss {
        if far && g.path == Some(Path::Heaven) {
            &THEME_BOSS_HEAVEN
        } else {
            &THEME_BOSS
        }
    } else if r.shop {
        &THEME_SHOP
    } else if r.gold {
        &THEME_GOLD
    } else if far {
        match g.path {
            Some(Path::Hell) => &THEME_HELL,
            _ => &THEME_HEAVEN,
        }
    } else {
        &THEMES[(((g.floor - 1) / 3) % 3) as usize]
    }
}

fn in_cell(g: &Game, x: f32, y: f32) -> bool {
    g.in_cur_cell(x, y)
}

pub fn draw_game(ui: &Ui, g: &Game) {
    let cam = make_cam(g);
    clear_background(col("#0d0b08"));
    draw_world(ui, g, &cam);
    draw_hud(ui, g);
    if g.freeze > 0.0 {
        draw_rectangle(0.0, 0.0, screen_width(), screen_height(), Color::new(0.43, 0.88, 1.0, 0.14));
    }
    if g.flash > 0.0 {
        draw_rectangle(0.0, 0.0, screen_width(), screen_height(), Color::new(1.0, 1.0, 1.0, g.flash.min(0.35)));
    }
    if g.intro > 0.0 {
        draw_intro(ui, g);
    }
    if let Some((s, _)) = g.toast.as_ref() {
        let w = (ui.width(s, 15.0) + 24.0 * ui.u).min(screen_width() - 20.0);
        let cx = screen_width() / 2.0;
        let y = screen_height() * 0.28;
        draw_rectangle(cx - w / 2.0, y - 20.0 * ui.u, w, 30.0 * ui.u, Color::new(0.0, 0.0, 0.0, 0.62));
        ui.text_c(s, cx, y, 15.0, WHITE);
    }
}

fn draw_intro(ui: &Ui, g: &Game) {
    let sw = screen_width();
    let sh = screen_height();
    let a = (g.intro / 0.5).min(1.0) * 0.9;
    draw_rectangle(0.0, 0.0, sw, sh, Color::new(0.04, 0.0, 0.0, a));
    if let Some(b) = g.mons.iter().find(|m| m.boss) {
        let c = col(b.color);
        let k = ((3.2 - g.intro) * 2.0).min(1.0);
        draw_rectangle(0.0, sh * 0.42, sw, sh * 0.16, Color::new(0.0, 0.0, 0.0, 0.7 * k));
        ui.text_oc(b.name, sw / 2.0, sh * 0.53, 44.0, Color::new(c.r, c.g, c.b, k));
        ui.text_oc("ИГРОК  VS  БОСС", sw / 2.0, sh * 0.42 - 12.0 * ui.u, 18.0, Color::new(1.0, 0.8, 0.4, k));
    }
}

// ---------------------------------------------------------------- мир

fn draw_world(ui: &Ui, g: &Game, cam: &Cam) {
    let th = theme_for(g);
    let (ca, cb, cw_, cf) = (col(th.a), col(th.b), col(th.w), col(th.f));
    let r = g.room();
    let gx0 = r.gx * CW;
    let gy0 = r.gy * CH;
    let s = cam.s;
    // тайлы
    for y in gy0..gy0 + CH {
        for x in gx0..gx0 + CW {
            let sx = cam.sx(x as f32);
            let sy = cam.sy(y as f32);
            if sx > screen_width() || sy > screen_height() || sx + s < 0.0 || sy + s < 0.0 {
                continue;
            }
            let t = g.tile(x, y);
            let size = s + 1.0;
            if t == 1 {
                draw_rectangle(sx, sy, size, size, cw_);
                if g.tile(x, y + 1) != 1 {
                    draw_rectangle(sx, sy + s * 0.65, size, s * 0.37, cf);
                    draw_rectangle(sx, sy + s * 0.65, size, s * 0.05, Color::new(0.0, 0.0, 0.0, 0.25));
                }
                continue;
            }
            draw_rectangle(sx, sy, size, size, if (x + y) % 2 == 1 { ca } else { cb });
            match t {
                2 => {
                    draw_rectangle(sx + s * 0.1, sy + s * 0.1, s * 0.8, s * 0.8, Color::from_rgba(18, 14, 12, 255));
                    for i in 0..4 {
                        let f = i as f32 * 0.2;
                        draw_rectangle(sx + s * (0.15 + f * 0.3), sy + s * (0.15 + f), s * (0.7 - f * 0.6), s * 0.12, Color::from_rgba(120 + i * 25, 110 + i * 22, 96 + i * 20, 255));
                    }
                }
                3 => {
                    draw_rectangle(sx, sy, size, size, Color::from_rgba(60, 52, 48, 255));
                    for i in 0..4 {
                        draw_rectangle(sx + s * (0.1 + i as f32 * 0.24), sy, s * 0.1, size, Color::from_rgba(140, 140, 150, 255));
                    }
                }
                5 => {
                    draw_rectangle(sx, sy, size, size, col("#b89a30"));
                    draw_rectangle_lines(sx + 2.0, sy + 2.0, s - 4.0, s - 4.0, 3.0, col("#6a5410"));
                    draw_circle(sx + s * 0.5, sy + s * 0.45, s * 0.12, col("#1a1410"));
                    draw_rectangle(sx + s * 0.47, sy + s * 0.45, s * 0.06, s * 0.25, col("#1a1410"));
                }
                8 => {
                    draw_rectangle(sx + s * 0.08, sy + s * 0.08, s * 0.84, s * 0.84, Color::from_rgba(14, 10, 8, 255));
                    draw_rectangle_lines(sx, sy, s, s, 3.0, Color::from_rgba(110, 80, 50, 255));
                }
                _ => {}
            }
        }
    }
    // камни, которые можно взорвать, подсвечиваем трещиной
    for &k in g.brk.iter() {
        let x = k % smolik_core::dungeon::MAP_COLS;
        let y = k / smolik_core::dungeon::MAP_COLS;
        if x / CW != r.gx || y / CH != r.gy || g.tile(x, y) != 1 {
            continue;
        }
        let sx = cam.sx(x as f32);
        let sy = cam.sy(y as f32);
        draw_rectangle(sx + 1.0, sy + 1.0, s - 2.0, s - 2.0, Color::from_rgba(120, 104, 86, 255));
        draw_line(sx + s * 0.25, sy + s * 0.2, sx + s * 0.5, sy + s * 0.55, 2.0, Color::from_rgba(40, 32, 26, 255));
        draw_line(sx + s * 0.5, sy + s * 0.55, sx + s * 0.8, sy + s * 0.5, 2.0, Color::from_rgba(40, 32, 26, 255));
    }
    // шипы и бочки
    for k in g.spk.iter() {
        if k.x / CW != r.gx || k.y / CH != r.gy {
            continue;
        }
        let st = g.spike_state(k);
        let sx = cam.sx(k.x as f32);
        let sy = cam.sy(k.y as f32);
        draw_rectangle(sx + s * 0.06, sy + s * 0.06, s * 0.88, s * 0.88, Color::new(0.0, 0.0, 0.0, 0.3));
        let holes: [(f32, f32); 4] = [(0.28, 0.28), (0.72, 0.28), (0.28, 0.72), (0.72, 0.72)];
        for &(a, b) in holes.iter() {
            draw_rectangle(sx + s * (a - 0.04), sy + s * (b - 0.04), s * 0.08, s * 0.08, Color::from_rgba(20, 16, 12, 255));
            if st > 0 {
                let h = if st == 1 { 0.2 } else { 0.55 };
                let cx = sx + s * a;
                let cy = sy + s * (b + 0.14);
                let c = if st == 1 { Color::from_rgba(212, 154, 138, 255) } else { Color::from_rgba(228, 235, 242, 255) };
                draw_triangle(vec2(cx - s * 0.12, cy), vec2(cx, cy - s * h), vec2(cx + s * 0.12, cy), c);
            }
        }
    }
    for o in g.bar.values() {
        if o.x / CW != r.gx || o.y / CH != r.gy {
            continue;
        }
        let sx = cam.sx(o.x as f32);
        let sy = cam.sy(o.y as f32);
        draw_rectangle(sx, sy, s + 1.0, s + 1.0, if (o.x + o.y) % 2 == 1 { ca } else { cb });
        px_draw(&BARREL, sx + s * 0.03, sy + s * 0.03, s * 0.95);
    }
    if r.boss {
        let corners: [(f32, f32); 4] = [(0.5, 0.5), (r.w as f32 - 0.5, 0.5), (0.5, r.h as f32 - 0.5), (r.w as f32 - 0.5, r.h as f32 - 0.5)];
        for &(a, b) in corners.iter() {
            let cx = cam.sx(r.x as f32 + a);
            let cy = cam.sy(r.y as f32 + b);
            px_draw(ITEMS[SKULL_ITEM].pixels, cx - s * 0.4, cy - s * 0.4, s * 0.8);
        }
    }
    // предметы на полу
    for o in g.pick.iter() {
        if o.gone || !in_cell(g, o.x, o.y) {
            continue;
        }
        let bob = (g.t * 4.0 + o.x).sin() * 0.05;
        let sx = cam.sx(o.x);
        let sy = cam.sy(o.y + bob);
        match o.kind {
            PickKind::Item => {
                draw_ellipse(sx, cam.sy(o.y + 0.3), s * 0.32, s * 0.12, 0.0, Color::new(0.0, 0.0, 0.0, 0.35));
                if o.it >= 0 {
                    let rc = col(RARITY_COLORS[(ITEMS[o.it as usize].rarity as usize).min(5)]);
                    let a = 0.3 + 0.15 * (g.t * 3.0).sin();
                    draw_ellipse(sx, cam.sy(o.y + 0.3), s * 0.5, s * 0.2, 0.0, Color::new(rc.r, rc.g, rc.b, a));
                    px_draw(ITEMS[o.it as usize].pixels, sx - s * 0.35, sy - s * 0.4, s * 0.7);
                } else {
                    heart_draw(sx - s * 0.35, sy - s * 0.4, s * 0.7, 1.0);
                }
            }
            PickKind::Coin => px_draw(&COIN, sx - s * 0.22, sy - s * 0.22, s * 0.45),
            PickKind::Key => px_draw(&KEY, sx - s * 0.27, sy - s * 0.27, s * 0.55),
            PickKind::Bomb => px_draw(&BOMB, sx - s * 0.27, sy - s * 0.27, s * 0.55),
            PickKind::Heart => heart_draw(sx - s * 0.27, sy - s * 0.27, s * 0.55, 1.0),
            PickKind::HalfHeart => heart_draw(sx - s * 0.27, sy - s * 0.27, s * 0.55, 0.5),
            PickKind::DoubleHeart => {
                heart_draw(sx - s * 0.5, sy - s * 0.27, s * 0.5, 1.0);
                heart_draw(sx, sy - s * 0.27, s * 0.5, 1.0);
            }
            PickKind::Chest => px_draw(if o.gold { &GCHEST } else { &CHEST }, sx - s * 0.4, sy - s * 0.4, s * 0.8),
        }
        // цена
        if o.pr > 0 || o.pk > 0 {
            let mut x = sx - s * 0.4;
            let y = cam.sy(o.y) + s * 0.62;
            if o.pr > 0 {
                px_draw(&COIN, x, y - s * 0.17, s * 0.22);
                let c = if g.p.gold() >= o.pr { col("#f0c030") } else { col("#d06060") };
                ui.text_o(&o.pr.to_string(), x + s * 0.26, y + 2.0, 13.0, c);
                x += s * 0.62;
            }
            if o.pk > 0 {
                px_draw(&KEY, x, y - s * 0.17, s * 0.22);
                let c = if g.p.keys() >= o.pk { col("#f0c030") } else { col("#d06060") };
                ui.text_o(&o.pk.to_string(), x + s * 0.26, y + 2.0, 13.0, c);
            }
        }
    }
    // монстры
    let mut idx: Vec<usize> = Vec::new();
    for (i, m) in g.mons.iter().enumerate() {
        if !m.dead && in_cell(g, m.x, m.y) {
            idx.push(i);
        }
    }
    idx.sort_by(|&a, &b| g.mons[a].y.partial_cmp(&g.mons[b].y).unwrap_or(std::cmp::Ordering::Equal));
    for &i in idx.iter() {
        draw_monster(g, cam, &g.mons[i]);
    }
    let own_p: u8 = if g.is_client { 1 } else { 0 };
    match g.p2.as_ref() {
        Some(q) => {
            if q.y < g.p.y {
                draw_player(ui, g, cam, q, 1 - own_p, true);
                draw_player(ui, g, cam, &g.p, own_p, false);
            } else {
                draw_player(ui, g, cam, &g.p, own_p, false);
                draw_player(ui, g, cam, q, 1 - own_p, true);
            }
        }
        None => draw_player(ui, g, cam, &g.p, own_p, false),
    }
    // бомбы и газ
    for q in g.gas.iter() {
        draw_circle(cam.sx(q.x), cam.sy(q.y), s * 1.3, Color::new(0.5, 0.88, 0.23, 0.22));
    }
    for b in g.bombs.iter() {
        let x = cam.sx(b.x);
        let y = cam.sy(b.y);
        draw_ellipse(x, y + s * 0.15, s * 0.22, s * 0.08, 0.0, Color::new(0.0, 0.0, 0.0, 0.3));
        if b.hostile {
            let blink = ((g.t * 14.0) as i32) % 2 == 0;
            draw_circle(x, y - s * 0.1, s * 0.2, if blink { col("#ff2a2a") } else { WHITE });
        } else {
            px_draw(&BOMB, x - s * 0.27, y - s * 0.37, s * 0.55);
            if b.l < 1.0 && ((g.t * 10.0) as i32) % 2 == 0 {
                draw_circle(x, y - s * 0.1, s * 0.2, Color::new(1.0, 0.29, 0.16, 0.55));
            }
        }
    }
    for b in g.bul.iter() {
        if in_cell(g, b.x, b.y) {
            draw_bullet(g, cam, b);
        }
    }
    draw_rings(g, cam);
    for q in g.parts.iter() {
        let a = (q.l * 3.0).min(1.0);
        draw_rectangle(cam.sx(q.x) - 2.0, cam.sy(q.y) - 2.0, 4.0, 4.0, rgba(q.col, (a * 255.0) as u8));
    }
    // подписи предметов рядом с игроком
    for o in g.pick.iter() {
        if o.kind != PickKind::Item || o.it < 0 || o.gone || !in_cell(g, o.x, o.y) {
            continue;
        }
        if ((g.p.x - o.x).powi(2) + (g.p.y - o.y).powi(2)).sqrt() >= 1.8 {
            continue;
        }
        let it = &ITEMS[o.it as usize];
        let rc = col(RARITY_COLORS[(it.rarity as usize).min(5)]);
        let w = (ui.width(it.description, 12.0).max(ui.width(it.name, 14.0)) + 20.0 * ui.u).min(screen_width() - 10.0);
        let cx = cam.sx(o.x).max(w / 2.0 + 4.0).min(screen_width() - w / 2.0 - 4.0);
        let y = cam.sy(o.y) - s * 1.25;
        draw_rectangle(cx - w / 2.0, y - 18.0 * ui.u, w, 52.0 * ui.u, Color::new(0.0, 0.0, 0.0, 0.78));
        let stars: String = "★".repeat(it.rarity as usize);
        ui.text_c(&stars, cx, y - 4.0 * ui.u, 10.0, rc);
        ui.text_c(it.name, cx, y + 11.0 * ui.u, 14.0, rc);
        ui.text_c(it.description, cx, y + 26.0 * ui.u, 11.0, WHITE);
    }
}

fn draw_eyes(cx: f32, cy: f32, r: f32, fx: f32, fy: f32) {
    let ex = r * 0.42;
    let ey = -r * 0.1;
    for sgn in [-1.0f32, 1.0f32].iter() {
        let x = cx + sgn * ex;
        let y = cy + ey;
        draw_circle(x, y, r * 0.24, WHITE);
        draw_circle(x + fx * r * 0.1, y + fy * r * 0.1, r * 0.12, col("#1a1410"));
    }
}

fn with_a(c: Color, a: f32) -> Color {
    Color::new(c.r, c.g, c.b, c.a * a)
}

/// Бумеранг: изогнутая дуга, толстая в середине и тонкая на концах, с обводкой, бликом и золотой накладкой на изгибе.
/// `size` — расстояние от центра вращения до кончика, `rot` — поворот, `alpha` — прозрачность (для шлейфа).
fn boomerang_shape(cx: f32, cy: f32, size: f32, rot: f32, alpha: f32, full: bool) {
    let (cr, sr) = (rot.cos(), rot.sin());
    let big_r = size * 1.12;
    let pivot = 0.841 * big_r;
    let pt = |th: f32, rho: f32| -> Vec2 {
        let lx = (big_r + rho) * th.cos() - pivot;
        let ly = (big_r + rho) * th.sin();
        vec2(cx + lx * cr - ly * sr, cy + lx * sr + ly * cr)
    };
    let wid = |th: f32| -> f32 { big_r * (0.30 - 0.15 * th.abs().powf(1.4)) };
    let strip = |r0: f32, r1: f32, pad: f32, color: Color| {
        let n = 10;
        let mut prev: Option<(Vec2, Vec2)> = None;
        for i in 0..=n {
            let th = -1.0 + 2.0 * i as f32 / n as f32;
            let w = wid(th);
            let a = pt(th, r0 * w - pad);
            let b = pt(th, r1 * w + pad);
            if let Some((pa, pb)) = prev {
                draw_triangle(pa, pb, b, color);
                draw_triangle(pa, b, a, color);
            }
            prev = Some((a, b));
        }
    };
    let caps = |pad: f32, k: f32, color: Color| {
        for th in [-1.0f32, 1.0f32].iter() {
            let c = pt(*th, 0.0);
            draw_circle(c.x, c.y, wid(*th) * k + pad, color);
        }
    };
    let o = (size * 0.09).max(1.5);
    if full {
        let dark = with_a(col("#1a1410"), alpha);
        strip(-0.5, 0.5, o, dark);
        caps(o, 0.5, dark);
    }
    let body = with_a(col("#8aa4c4"), alpha);
    strip(-0.5, 0.5, 0.0, body);
    caps(0.0, 0.5, body);
    // блик по внешнему краю и тень по внутреннему
    strip(0.08, 0.42, 0.0, with_a(col("#dbe8f7"), alpha));
    if full {
        strip(-0.46, -0.2, 0.0, with_a(col("#5d7898"), alpha));
        // золотая накладка на изгибе и заклёпка
        let gold = with_a(col("#f0c030"), alpha);
        let w0 = wid(0.0);
        let mut prev: Option<(Vec2, Vec2)> = None;
        for i in 0..=4 {
            let th = -0.13 + 0.26 * i as f32 / 4.0;
            let a = pt(th, -w0 * 0.58);
            let b = pt(th, w0 * 0.58);
            if let Some((pa, pb)) = prev {
                draw_triangle(pa, pb, b, gold);
                draw_triangle(pa, b, a, gold);
            }
            prev = Some((a, b));
        }
        let c = pt(0.0, 0.0);
        draw_circle(c.x, c.y, size * 0.07, with_a(col("#1a1410"), alpha));
        // искра пробегает по дуге
        let gl = (rot * 0.9).sin();
        let g = pt(gl, wid(gl) * 0.3);
        draw_circle(g.x, g.y, (size * 0.075).max(1.5), with_a(WHITE, 0.9 * alpha));
    }
}

/// Летящий бумеранг: тень на полу, свечение на возврате, размытый шлейф и сама модель.
fn draw_boomerang_bullet(cam: &Cam, b: &Bullet, x: f32, y: f32, r: f32) {
    let s = cam.s;
    let size = (r * 2.2).max(s * 0.34);
    draw_ellipse(x + size * 0.1, y + size * 0.9, size * 0.8, size * 0.26, 0.0, Color::new(0.0, 0.0, 0.0, 0.28));
    if b.ph {
        draw_circle(x, y, size * 1.3, Color::new(0.55, 0.8, 1.0, 0.14));
        draw_circle(x, y, size * 0.9, Color::new(0.75, 0.92, 1.0, 0.14));
    }
    for k in (1..=3).rev() {
        let kf = k as f32;
        boomerang_shape(x - b.vx * s * 0.010 * kf, y - b.vy * s * 0.010 * kf, size, b.rot - 0.5 * kf, 0.26 / kf, false);
    }
    boomerang_shape(x, y, size, b.rot, 1.0, true);
}

/// Снаряжение Стража: наплечники, шлем с гребнем и носовой планкой, щит и бумеранг в руке.
fn draw_guard_front(g: &Game, p: &Player, own: u8, x: f32, y: f32, r: f32) {
    let dark = col("#1a1410");
    let steel = col("#b8cbe0");
    let steel_d = col("#5d7898");
    let l = p.fx.hypot(p.fy).max(0.001);
    let (fx, fy) = (p.fx / l, p.fy / l);
    // «левая» и «правая» рука относительно взгляда (экран: y вниз)
    let (lx, ly) = (fy, -fx);
    let (rx, ry) = (-fy, fx);
    // шлем: верхняя половина круга
    let hc = vec2(x, y - r * 0.08);
    let n = 12;
    for i in 0..n {
        let a0 = std::f32::consts::PI + i as f32 * std::f32::consts::PI / n as f32;
        let a1 = std::f32::consts::PI + (i + 1) as f32 * std::f32::consts::PI / n as f32;
        draw_triangle(hc, vec2(hc.x + a0.cos() * r * 1.06, hc.y + a0.sin() * r * 1.06), vec2(hc.x + a1.cos() * r * 1.06, hc.y + a1.sin() * r * 1.06), dark);
    }
    for i in 0..n {
        let a0 = std::f32::consts::PI + i as f32 * std::f32::consts::PI / n as f32;
        let a1 = std::f32::consts::PI + (i + 1) as f32 * std::f32::consts::PI / n as f32;
        draw_triangle(hc, vec2(hc.x + a0.cos() * r * 0.96, hc.y + a0.sin() * r * 0.96), vec2(hc.x + a1.cos() * r * 0.96, hc.y + a1.sin() * r * 0.96), steel_d);
    }
    draw_circle(x - r * 0.35, y - r * 0.62, r * 0.2, Color::new(1.0, 1.0, 1.0, 0.28));
    // ободок шлема и тень над глазами
    draw_line(x - r * 1.0, hc.y, x + r * 1.0, hc.y, r * 0.17, steel);
    draw_rectangle(x - r * 0.85, hc.y + r * 0.08, r * 1.7, r * 0.28, Color::new(0.0, 0.0, 0.0, 0.5));
    // гребень
    let sway = (p.anim * 0.7).sin() * r * 0.12;
    let base_l = vec2(x - r * 0.14, y - r * 1.0);
    let base_r = vec2(x + r * 0.14, y - r * 1.0);
    let tip = vec2(x - fx * r * 0.35 + sway, y - r * 1.55 - fy * r * 0.15);
    let o = 1.6;
    draw_triangle(vec2(base_l.x - o, base_l.y + o), vec2(base_r.x + o, base_r.y + o), vec2(tip.x, tip.y - o), dark);
    draw_triangle(base_l, base_r, tip, col("#c8402e"));
    draw_line(x, y - r * 1.0, tip.x, tip.y + r * 0.08, 1.5, col("#ff8a6a"));
    // щит в левой руке
    let armored = p.st.shield > 0.0;
    let sc = vec2(x + lx * r * 1.05 + fx * r * 0.12, y + ly * r * 1.05 + fy * r * 0.12);
    let sr = r * 0.62;
    let (sh_a, sh_b) = if armored { (steel_d, steel) } else { (shade(steel_d, 0.7), shade(steel, 0.7)) };
    draw_circle(sc.x, sc.y, sr + 2.0, dark);
    draw_circle(sc.x, sc.y, sr, sh_a);
    draw_circle(sc.x, sc.y, sr * 0.72, sh_b);
    draw_circle_lines(sc.x, sc.y, sr * 0.72, 2.0, col("#c8402e"));
    draw_circle(sc.x, sc.y, sr * 0.22, col("#f0c030"));
    draw_circle(sc.x - sr * 0.08, sc.y - sr * 0.08, sr * 0.08, Color::new(1.0, 1.0, 1.0, 0.7));
    // бумеранг в правой руке, пока он не в полёте
    let busy = g.bul.iter().filter(|q| q.bm && q.own == own).count() as i32;
    if busy < (p.st.multi.round() as i32).max(1) {
        let hp = vec2(x + fx * r * 1.0 + rx * r * 0.5, y + fy * r * 1.0 + ry * r * 0.5);
        let ang = fy.atan2(fx) + 0.9 + (g.t * 3.0).sin() * 0.08;
        draw_circle(hp.x, hp.y, r * 0.2, dark);
        boomerang_shape(hp.x, hp.y, r * 0.8, ang, 1.0, true);
    }
}

fn draw_player(ui: &Ui, g: &Game, cam: &Cam, p: &Player, own: u8, tag: bool) {
    let s = cam.s;
    if p.dead {
        return;
    }
    if p.inv > 0.0 && ((g.t * 20.0) as i32) % 2 == 0 {
        return;
    }
    let x = cam.sx(p.x);
    let y = cam.sy(p.y) - (p.anim * 1.0).sin().abs() * s * 0.04;
    let r = s * 0.42;
    let guard = p.melee && p.ch == 10;
    draw_ellipse(x, cam.sy(p.y) + s * 0.3, s * 0.3, s * 0.1, 0.0, Color::new(0.0, 0.0, 0.0, 0.35));
    if p.st.dark > 0.5 {
        draw_circle(x, y, r * 1.4, Color::new(0.35, 0.15, 0.6, 0.25));
    }
    if p.st.shield > 0.0 {
        draw_circle_lines(x, y, r * 1.25, 2.0, Color::new(0.4, 0.7, 1.0, 0.8));
    }
    let body = col(p.color);
    if guard {
        // наплечники за спиной
        for sgn in [-1.0f32, 1.0f32].iter() {
            draw_circle(x + sgn * r * 0.98, y + r * 0.3, r * 0.44, col("#1a1410"));
            draw_circle(x + sgn * r * 0.98, y + r * 0.3, r * 0.38, col("#5d7898"));
            draw_circle(x + sgn * r * 1.0, y + r * 0.22, r * 0.14, Color::new(1.0, 1.0, 1.0, 0.3));
        }
    }
    draw_circle(x, y, r + 2.0, col("#1a1410"));
    draw_circle(x, y, r, body);
    draw_circle(x - r * 0.3, y - r * 0.35, r * 0.28, Color::new(1.0, 1.0, 1.0, 0.25));
    if guard {
        draw_guard_front(g, p, own, x, y, r);
        draw_eyes(x, y, r, p.fx, p.fy);
        // носовая планка поверх глаз
        draw_rectangle(x - r * 0.07, y - r * 0.12, r * 0.14, r * 0.5, col("#b8cbe0"));
    } else {
        draw_eyes(x, y, r, p.fx, p.fy);
        // оружие в направлении стрельбы
        let tip = vec2(x + p.fx * r * 1.25, y + p.fy * r * 1.25);
        draw_line(x + p.fx * r * 0.7, y + p.fy * r * 0.7, tip.x, tip.y, s * 0.12, col("#1a1410"));
        if p.melee {
            draw_circle(tip.x, tip.y, s * 0.1, col("#d6e4f5"));
        }
    }
    if tag {
        let name = CHARACTERS[p.ch].name;
        ui.text_oc(name, x, y - r * 1.9, 12.0, col("#ffe08a"));
    }
}

fn draw_monster(g: &Game, cam: &Cam, e: &Monster) {
    let s = cam.s;
    let x = cam.sx(e.x);
    let bob = (g.t * 6.0 + e.a).sin() * s * 0.03;
    let y = cam.sy(e.y) + bob;
    let r = e.r * s * 1.25;
    let mut body = col(e.color);
    if e.fl > 0.0 {
        body = WHITE;
    } else if e.bt > 0.0 {
        body = shade(body, 1.25);
        body.r = (body.r + 0.35).min(1.0);
    } else if e.pt > 0.0 {
        body.g = (body.g + 0.25).min(1.0);
    }
    let dark = col("#1a1410");
    draw_ellipse(x, cam.sy(e.y) + e.r * s * 0.9, r * 0.9, r * 0.3, 0.0, Color::new(0.0, 0.0, 0.0, 0.35));
    // особые формы
    match e.kind {
        MonKind::Bat | MonKind::Wisp | MonKind::Cherub => {
            let flap = (g.t * 18.0 + e.a).sin() * 0.5;
            let wing = if e.kind == MonKind::Wisp { col("#ffcf5a") } else { shade(body, 0.8) };
            for sgn in [-1.0f32, 1.0f32].iter() {
                draw_triangle(vec2(x + sgn * r * 0.5, y), vec2(x + sgn * r * 1.9, y - r * (0.9 + flap)), vec2(x + sgn * r * 1.5, y + r * 0.7), wing);
            }
            if e.kind == MonKind::Cherub {
                draw_circle_lines(x, y - r * 1.2, r * 0.55, 2.0, col("#ffd84a"));
            }
        }
        MonKind::Charge | MonKind::Hound | MonKind::Guardian => {
            for sgn in [-1.0f32, 1.0f32].iter() {
                draw_triangle(vec2(x + sgn * r * 0.4, y - r * 0.7), vec2(x + sgn * r * 1.0, y - r * 1.6), vec2(x + sgn * r * 0.9, y - r * 0.4), col("#e8e0c8"));
            }
            if e.st == 1 {
                draw_circle_lines(x, y, r * 1.5, 2.0, Color::new(1.0, 0.3, 0.2, 0.8));
            }
        }
        MonKind::Spider => {
            for i in 0..4 {
                let a = 0.5 + i as f32 * 0.35;
                for sgn in [-1.0f32, 1.0f32].iter() {
                    draw_line(x, y, x + sgn * a.cos() * r * 1.7, y + a.sin() * r * 1.2 - r * 0.3, 2.0, dark);
                }
            }
        }
        _ => {}
    }
    if e.kind == MonKind::Turret {
        draw_rectangle(x - r, y - r, r * 2.0, r * 2.0, dark);
        draw_rectangle(x - r + 2.0, y - r + 2.0, r * 2.0 - 4.0, r * 2.0 - 4.0, body);
    } else if matches!(e.kind, MonKind::Slime | MonKind::Bomber | MonKind::Boss) && e.kind != MonKind::Boss {
        let sq = 1.0 + (g.t * 4.0 + e.a).sin() * 0.12;
        draw_ellipse(x, y, r * 1.05 * sq + 2.0, r * 0.9 / sq + 2.0, 0.0, dark);
        draw_ellipse(x, y, r * 1.05 * sq, r * 0.9 / sq, 0.0, body);
    } else {
        draw_circle(x, y, r + 2.0, dark);
        draw_circle(x, y, r, body);
    }
    if e.kind == MonKind::Boss {
        // шипы короны цвета босса
        let n = 7;
        for i in 0..n {
            let a = -std::f32::consts::PI + (i as f32 + 0.5) * std::f32::consts::PI / n as f32;
            let c = a.cos();
            let sn = a.sin();
            draw_triangle(
                vec2(x + c * r * 0.85 - sn * r * 0.14, y + sn * r * 0.85 + c * r * 0.14),
                vec2(x + c * r * 1.35, y + sn * r * 1.35),
                vec2(x + c * r * 0.85 + sn * r * 0.14, y + sn * r * 0.85 - c * r * 0.14),
                dark,
            );
        }
        if e.wind {
            draw_circle_lines(x, y, r * 1.5, 3.0, Color::new(1.0, 0.3, 0.2, 0.8));
        }
    }
    if e.kind == MonKind::Shroom {
        draw_circle(x, y - r * 0.3, r * 0.9, col("#d05050"));
        draw_circle(x - r * 0.3, y - r * 0.5, r * 0.18, WHITE);
        draw_circle(x + r * 0.35, y - r * 0.2, r * 0.14, WHITE);
    }
    if e.kind == MonKind::Imp {
        for sgn in [-1.0f32, 1.0f32].iter() {
            draw_triangle(vec2(x + sgn * r * 0.3, y - r * 0.8), vec2(x + sgn * r * 0.9, y - r * 1.5), vec2(x + sgn * r * 0.8, y - r * 0.5), col("#6a0e06"));
        }
    }
    if e.kind == MonKind::Angel {
        draw_circle_lines(x, y - r * 1.25, r * 0.5, 2.0, col("#ffd84a"));
    }
    if e.kind == MonKind::Bomber {
        draw_line(x, y - r * 0.8, x + r * 0.3, y - r * 1.3, 2.0, col("#c0a060"));
        if ((g.t * 12.0) as i32) % 2 == 0 {
            draw_circle(x + r * 0.3, y - r * 1.3, r * 0.15, col("#ffb030"));
        }
    }
    draw_eyes(x, y, r, e.ux, e.uy);
    if matches!(e.beh, Beh::Gun) && e.kind != MonKind::Turret {
        draw_line(x + e.ux * r * 0.6, y + e.uy * r * 0.6, x + e.ux * r * 1.4, y + e.uy * r * 1.4, s * 0.1, dark);
    }
    if e.kind == MonKind::Turret {
        draw_line(x, y, x + e.ux * r * 1.5, y + e.uy * r * 1.5, s * 0.16, dark);
    }
    // полоска здоровья у обычных монстров
    if !e.boss && e.hp < e.mhp {
        let w = r * 2.0;
        draw_rectangle(x - w / 2.0, y - r - 8.0, w, 4.0, Color::new(0.0, 0.0, 0.0, 0.6));
        draw_rectangle(x - w / 2.0, y - r - 8.0, w * (e.hp / e.mhp).max(0.0), 4.0, col("#d03a2a"));
    }
}

fn draw_bullet(g: &Game, cam: &Cam, b: &Bullet) {
    let s = cam.s;
    let x = cam.sx(b.x);
    let y = cam.sy(b.y);
    let r = (b.r * s).max(2.0);
    let dark = col("#1a1410");
    if !b.pl {
        draw_circle(x, y, r + 2.0, dark);
        draw_circle(x, y, r, col("#e8502a"));
        draw_circle(x - r * 0.25, y - r * 0.25, r * 0.4, col("#ffd080"));
        return;
    }
    match b.skin {
        Skin::Boomerang => draw_boomerang_bullet(cam, b, x, y, r),
        Skin::Weak => {
            draw_circle(x, y, r * 1.9, Color::new(0.16, 0.54, 1.0, 0.3));
            draw_circle(x, y, r, col("#6fe0ff"));
            draw_circle(x, y, r * 0.5, WHITE);
        }
        Skin::LetterN => {
            ui_n(x, y, r * 2.4, col("#d2a8ff"));
        }
        Skin::Tape => {
            draw_rectangle(x - r * 1.5, y - r * 1.1, r * 3.0, r * 2.2, col("#6a2ab0"));
            draw_rectangle(x - r * 1.2, y - r * 0.8, r * 2.4, r * 0.9, WHITE);
            draw_rectangle(x - r * 0.8, y - r * 0.6, r * 0.5, r * 0.5, dark);
            draw_rectangle(x + r * 0.3, y - r * 0.6, r * 0.5, r * 0.5, dark);
        }
        Skin::Astral => {
            draw_poly(x, y, 4, r * 1.7, g.t * 90.0, col("#fff0a0"));
            draw_poly(x, y, 4, r * 1.0, g.t * 90.0 + 45.0, col("#d9981f"));
        }
        Skin::Bottle => {
            let a = g.t * 24.0;
            let (c, sn) = (a.cos(), a.sin());
            draw_line(x - c * r * 1.2, y - sn * r * 1.2, x + c * r * 1.2, y + sn * r * 1.2, r * 1.1, dark);
            draw_line(x - c * r * 1.0, y - sn * r * 1.0, x + c * r * 0.8, y + sn * r * 0.8, r * 0.8, col("#3fbf5f"));
            draw_circle(x + c * r * 1.2, y + sn * r * 1.2, r * 0.3, col("#d03a2a"));
        }
        Skin::Shard => {
            draw_triangle(vec2(x + r * 1.4, y), vec2(x - r * 0.7, y + r * 0.8), vec2(x - r * 0.6, y - r * 0.9), col("#8af0a8"));
        }
        Skin::Terra => {
            draw_poly(x, y, 4, r * 1.6, 45.0, col("#1a1410"));
            draw_poly(x, y, 4, r * 1.3, 45.0, col("#6dffb0"));
        }
        Skin::Rainbow => {
            let h = (b.rb as f32 * 60.0 + g.t * 200.0) % 360.0;
            let c = smolik_core::sim::hsl_to_rgb(h, 0.95, 0.6);
            draw_circle(x, y, r + 2.0, dark);
            draw_circle(x, y, r, rgba(c, 255));
        }
        Skin::Normal => {
            draw_circle(x, y, r + 2.0, dark);
            let c = if b.bu { col("#ff9a2a") } else if b.po { col("#8fe03a") } else { col("#fff6d0") };
            draw_circle(x, y, r, c);
        }
    }
}

/// Буква «N» из линий — снаряд героя NgrOK.
fn ui_n(x: f32, y: f32, size: f32, c: Color) {
    let h = size * 0.5;
    let w = size * 0.35;
    let t = size * 0.18;
    let k = col("#1a1410");
    for (col_, th) in [(k, t + 3.0), (c, t)].iter() {
        draw_line(x - w, y + h, x - w, y - h, *th, *col_);
        draw_line(x + w, y + h, x + w, y - h, *th, *col_);
        draw_line(x - w, y - h, x + w, y + h, *th, *col_);
    }
}

fn draw_rings(g: &Game, cam: &Cam) {
    let s = cam.s;
    for r in g.rings.iter() {
        let gw = r.gw;
        let cx = cam.sx(r.x);
        let cy = cam.sy(r.y);
        if r.t > 0.0 {
            // предупреждение: сектор, куда кольцо не пойдёт
            let n = 14;
            for i in 0..n {
                let a0 = r.g - gw + i as f32 * 2.0 * gw / n as f32;
                let a1 = r.g - gw + (i + 1) as f32 * 2.0 * gw / n as f32;
                draw_triangle(
                    vec2(cx, cy),
                    vec2(cx + a0.cos() * 10.0 * s, cy + a0.sin() * 10.0 * s),
                    vec2(cx + a1.cos() * 10.0 * s, cy + a1.sin() * 10.0 * s),
                    Color::new(0.43, 1.0, 0.69, 0.16),
                );
            }
            continue;
        }
        let n = std::cmp::max(12, (r.r * 7.0).round() as i32);
        let span = 2.0 * std::f32::consts::PI - 2.0 * gw;
        for i in 0..n {
            let a = r.g + gw + i as f32 * span / n as f32;
            let ca = a.cos();
            let sa = a.sin();
            let x = r.x + ca * r.r;
            let y = r.y + sa * r.r;
            let w = 0.13;
            draw_triangle(
                vec2(cam.sx(x - sa * w), cam.sy(y + ca * w)),
                vec2(cam.sx(x + ca * 0.36), cam.sy(y + sa * 0.36)),
                vec2(cam.sx(x + sa * w), cam.sy(y - ca * w)),
                col("#dfe6ee"),
            );
        }
    }
}

// ---------------------------------------------------------------- HUD

pub fn act_btn(ui: &Ui) -> (f32, f32, f32) {
    let r = 28.0 * ui.u;
    (screen_width() - r - 12.0 * ui.u, 120.0 * ui.u + r, r)
}

pub fn bomb_btn(ui: &Ui) -> (f32, f32, f32) {
    let (x, y, r) = act_btn(ui);
    (x, y + r * 2.0 + 18.0 * ui.u, r * 0.85)
}

pub fn pause_btn(ui: &Ui) -> Rect {
    let w = 44.0 * ui.u;
    Rect::new(screen_width() / 2.0 - w / 2.0, 6.0 * ui.u, w, 26.0 * ui.u)
}

fn ring_progress(cx: f32, cy: f32, r: f32, f: f32, c: Color) {
    let n = 40;
    let steps = ((n as f32) * f.min(1.0)).round() as i32;
    for i in 0..steps {
        let a0 = -std::f32::consts::FRAC_PI_2 + i as f32 * 2.0 * std::f32::consts::PI / n as f32;
        let a1 = a0 + 2.0 * std::f32::consts::PI / n as f32;
        draw_line(cx + a0.cos() * r, cy + a0.sin() * r, cx + a1.cos() * r, cy + a1.sin() * r, 3.0, c);
    }
}

/// Маленькая панель второго игрока: имя и сердца.
fn draw_partner(ui: &Ui, g: &Game) {
    let q = match g.p2.as_ref() {
        Some(q) => q,
        None => return,
    };
    let u = ui.u;
    let x0 = 8.0 * u;
    let hearts = (q.st.mhp.ceil() as i32).max(1).min(12);
    let h = 12.0 * u;
    let y0 = screen_height() - 40.0 * u;
    draw_rectangle(x0 - 4.0 * u, y0 - 4.0 * u, (hearts as f32 * (h + 1.0 * u)).max(120.0 * u) + 28.0 * u, 36.0 * u, Color::new(0.0, 0.0, 0.0, 0.4));
    draw_circle(x0 + 5.0 * u, y0 + 5.0 * u, 5.0 * u, col(q.color));
    let name = CHARACTERS[q.ch].name;
    let label = if q.dead { format!("{} (погиб)", name) } else { name.to_string() };
    ui.text_o(&label, x0 + 16.0 * u, y0 + 9.0 * u, 12.0, WHITE);
    for i in 0..hearts {
        let f = i as f32;
        let fill = if q.dead {
            0.0
        } else if f + 1.0 <= q.st.hp {
            1.0
        } else if f + 0.5 <= q.st.hp {
            0.5
        } else {
            0.0
        };
        heart_draw(x0 + i as f32 * (h + 1.0 * u), y0 + 14.0 * u, h, fill);
    }
}

pub fn draw_hud(ui: &Ui, g: &Game) {
    let u = ui.u;
    let p = &g.p;
    let top = 10.0 * u;
    draw_partner(ui, g);
    // сердца
    let hearts = p.st.mhp.ceil() as i32;
    for i in 0..hearts {
        let hx = 8.0 * u + (i % 8) as f32 * 22.0 * u;
        let hy = top + (i / 8) as f32 * 22.0 * u;
        let f = i as f32;
        let full = if f + 1.0 <= p.st.mhp {
            if f + 1.0 <= p.st.hp {
                1.0
            } else if f + 0.5 <= p.st.hp {
                0.5
            } else {
                0.0
            }
        } else if f + 0.5 <= p.st.hp {
            0.5
        } else {
            0.0
        };
        heart_draw(hx, hy, 19.0 * u, full);
    }
    let mut ty = top + ((hearts + 7) / 8) as f32 * 22.0 * u + 6.0 * u;
    if p.st.shield > 0.0 {
        px_draw(&SHIELD, 8.0 * u, ty, 16.0 * u);
        ui.text_o(&format!("×{}", p.st.shield as i32), 28.0 * u, ty + 13.0 * u, 14.0, WHITE);
        ty += 22.0 * u;
    }
    px_draw(&COIN, 8.0 * u, ty, 16.0 * u);
    ui.text_o(&p.gold().to_string(), 28.0 * u, ty + 13.0 * u, 14.0, WHITE);
    px_draw(&KEY, 62.0 * u, ty, 16.0 * u);
    ui.text_o(&p.keys().to_string(), 82.0 * u, ty + 13.0 * u, 14.0, WHITE);
    ui.text_o(&format!("Этаж {}", g.floor), 112.0 * u, ty + 13.0 * u, 14.0, WHITE);
    ui.text_o(&format!("Удача {}", p.st.luck as i32), 196.0 * u, ty + 13.0 * u, 14.0, col("#9fe08a"));
    ty += 24.0 * u;
    for (i, &it) in p.items.iter().enumerate() {
        let x = 8.0 * u + (i % 14) as f32 * 16.0 * u;
        let y = ty + (i / 14) as f32 * 16.0 * u;
        px_draw(ITEMS[it].pixels, x, y, 14.0 * u);
    }
    ty += ((p.items.len() as i32 + 13) / 14).max(1) as f32 * 16.0 * u + 6.0 * u;
    if is_key_down(KeyCode::Tab) {
        let st = &p.st;
        let mut rows: Vec<(&str, String)> = vec![
            ("Здоровье", format!("{:.1}/{:.1}", st.hp, st.mhp)),
            ("Урон", format!("{:.1}", st.dmg)),
            ("Скор. стрельбы", format!("{:.1}/с", st.rate)),
            ("Скорость", format!("{:.1}", st.spd)),
            ("Дальность", format!("{:.1}", st.range * 8.0)),
            ("Снарядов", format!("{}", st.multi.round() as i32)),
        ];
        if st.pierce > 0.0 {
            rows.push(("Пробой", format!("{}", st.pierce.round() as i32)));
        }
        if st.bounce > 0.0 {
            rows.push(("Рикошет", format!("{}", st.bounce.round() as i32)));
        }
        if st.home > 0.5 {
            rows.push(("Самонаведение", "да".to_string()));
        }
        if st.vamp > 0.0 {
            rows.push(("Вампиризм", format!("{}%", (st.vamp * 100.0).round() as i32)));
        }
        if st.burn > 0.5 {
            rows.push(("Огонь", "да".to_string()));
        }
        if st.poison > 0.5 {
            rows.push(("Яд", "да".to_string()));
        }
        let h = rows.len() as f32 * 16.0 * u + 10.0 * u;
        draw_rectangle(8.0 * u, ty, 170.0 * u, h, Color::new(0.0, 0.0, 0.0, 0.6));
        for (i, (k, v)) in rows.iter().enumerate() {
            let y = ty + 17.0 * u + i as f32 * 16.0 * u;
            ui.text(k, 14.0 * u, y, 12.0, col("#cccccc"));
            ui.text_r(v, 172.0 * u, y, 12.0, WHITE);
        }
    } else {
        ui.text("Tab — характеристики", 8.0 * u, ty + 12.0 * u, 11.0, Color::new(1.0, 1.0, 1.0, 0.35));
    }

    // босс
    if let Some(b) = g.mons.iter().find(|e| e.boss && e.aw > 0.0 && !e.dead) {
        let w = screen_width() * 0.7;
        let x = screen_width() / 2.0 - w / 2.0;
        let y = screen_height() - 46.0 * u;
        draw_rectangle(x, y, w, 10.0 * u, Color::new(0.0, 0.0, 0.0, 0.5));
        draw_rectangle(x, y, w * (b.hp / b.mhp).max(0.0), 10.0 * u, col("#9a4ad0"));
        ui.text_oc(b.name, screen_width() / 2.0, y - 8.0 * u, 18.0, col("#ff9a7a"));
    }

    // активка
    if let Some(a) = p.act.as_ref() {
        let (cx, cy, r) = act_btn(ui);
        draw_circle(cx, cy, r, Color::new(0.0, 0.0, 0.0, 0.55));
        let f = (a.c / a.m).min(1.0);
        let ready = f >= 1.0;
        draw_circle_lines(cx, cy, r - 2.0, 3.0, Color::new(0.5, 0.5, 0.5, 0.6));
        ring_progress(cx, cy, r - 2.0, f, if ready { col("#f0c030") } else { col("#888888") });
        match a.item {
            Some(it) => px_draw(ITEMS[it].pixels, cx - r * 0.55, cy - r * 0.55, r * 1.1),
            None => ui.text_c(act_def(a.id).label, cx, cy + 5.0 * u, 12.0, WHITE),
        }
        ui.text_oc("Пробел", cx, cy + r + 13.0 * u, 10.0, Color::new(1.0, 1.0, 1.0, 0.6));
    }
    let (bx, by, br) = bomb_btn(ui);
    draw_circle(bx, by, br, Color::new(0.0, 0.0, 0.0, 0.55));
    draw_circle_lines(bx, by, br - 2.0, 3.0, if p.bombs > 0 { col("#ff8a2a") } else { col("#666666") });
    px_draw(&BOMB, bx - br * 0.6, by - br * 0.6, br * 1.2);
    ui.text_oc(&format!("×{} (B)", p.bombs), bx, by + br + 13.0 * u, 11.0, WHITE);

    // пауза
    let pr = pause_btn(ui);
    draw_rectangle(pr.x, pr.y, pr.w, pr.h, Color::new(0.0, 0.0, 0.0, 0.45));
    ui.text_c("II", pr.x + pr.w / 2.0, pr.y + pr.h * 0.72, 14.0, WHITE);

    draw_minimap(ui, g);

    // баннер подобранного предмета
    if let Some(b) = g.ban.as_ref() {
        let w = (ui.width(&b.desc, 13.0).max(ui.width(&b.title, 16.0)) + 30.0 * u).min(screen_width() - 20.0);
        let cx = screen_width() / 2.0;
        let y = screen_height() * 0.62;
        draw_rectangle(cx - w / 2.0, y - 24.0 * u, w, 50.0 * u, Color::new(0.0, 0.0, 0.0, 0.78));
        ui.text_c(&b.title, cx, y - 4.0 * u, 16.0, col(RARITY_COLORS[(b.rarity as usize).min(5)]));
        ui.text_c(&b.desc, cx, y + 16.0 * u, 13.0, WHITE);
    }
}

fn draw_minimap(ui: &Ui, g: &Game) {
    let u = ui.u;
    let ms = 1.0;
    let mw = 16.0 * ms * u;
    let mh = 12.0 * ms * u;
    let n = smolik_core::dungeon::GN as f32;
    let mx = screen_width() - n * mw - 8.0 * u;
    let my = 40.0 * u;
    draw_rectangle(mx - 2.0, my - 2.0, n * mw + 4.0, n * mh + 4.0, Color::new(0.0, 0.0, 0.0, 0.45));
    for (ri, r) in g.rooms.iter().enumerate() {
        let seen = g.rs[ri].vis || g.rooms.iter().enumerate().any(|(k, o)| g.rs[k].vis && (o.gx - r.gx).abs() + (o.gy - r.gy).abs() == 1);
        if !seen {
            continue;
        }
        let vis = g.rs[ri].vis;
        let c = if ri == g.cur {
            WHITE
        } else if r.boss {
            if vis {
                col("#d03a2a")
            } else {
                col("#7a1a1a")
            }
        } else if !vis {
            col("#444444")
        } else if r.gold {
            col("#f0c030")
        } else if r.shop {
            col("#4caf50")
        } else if g.rs[ri].cl || r.start {
            col("#9a8a70")
        } else {
            col("#5a4a38")
        };
        let bx = mx + r.gx as f32 * mw;
        let by = my + r.gy as f32 * mh;
        if vis {
            let (rects, ring) = g.room_shape(ri);
            let kx = (mw - 2.0) / CW as f32;
            let ky = (mh - 2.0) / CH as f32;
            for &(a, b, w, h) in rects.iter() {
                draw_rectangle(bx + a as f32 * kx, by + b as f32 * ky, (w as f32 * kx).max(1.0), (h as f32 * ky).max(1.0), c);
            }
            if ring {
                let hx = (CW >> 1) - 4;
                let hy = (CH >> 1) - 2;
                draw_rectangle(bx + hx as f32 * kx, by + hy as f32 * ky, 8.0 * kx, 5.0 * ky, Color::new(0.0, 0.0, 0.0, 0.75));
            }
        } else {
            draw_rectangle(bx, by, mw - 2.0, mh - 2.0, c);
        }
        if r.boss {
            draw_circle(bx + mw / 2.0 - 1.0, by + mh / 2.0 - 1.0, 2.5 * u, col("#1a1410"));
        }
    }
    let r = g.room();
    let kind = &smolik_core::data::ROOMS[r.kind];
    ui.text_oc(&format!("{} {}×{}", kind.name, r.w, r.h), mx + n * mw / 2.0, my + n * mh + 14.0 * u, 12.0, WHITE);
}
