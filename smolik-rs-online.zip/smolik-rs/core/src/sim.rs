//! Шаг симуляции: игрок, ИИ монстров, пули, ловушки, комнаты. Порт `update()`, `ai()`, `updP()` из JS.
use crate::actions::BlastFx;
use crate::defs::*;
use crate::dungeon::MAP_COLS;
use crate::game::*;

impl Game {
    /// Один шаг игры. `dt` в секундах (в JS ограничен 0.033).
    pub fn update(&mut self, dt: f32, inp: &Input) {
        self.update_with(dt, inp, None);
    }

    /// Шаг игры с возможным вторым игроком (онлайн). `rem` — ввод и разовые нажатия второго игрока.
    pub fn update_with(&mut self, dt: f32, inp: &Input, rem: Option<&RemoteCtl>) {
        if self.over || self.choose {
            return;
        }
        if self.p.st.mhp >= 8.0 && !self.guard_unlock {
            self.guard_unlock = true;
            self.say("Страж открыт!");
        }
        if self.freeze > 0.0 {
            self.freeze -= dt;
        }
        self.t += dt;
        self.shake -= dt;
        self.flash -= dt;
        if self.intro > 0.0 {
            self.intro -= dt;
            self.shake = self.shake.max(0.1);
        }
        let mut drop_ban = false;
        if let Some(b) = self.ban.as_mut() {
            b.l -= dt;
            drop_ban = b.l <= 0.0;
        }
        if drop_ban {
            self.ban = None;
        }
        let mut drop_toast = false;
        if let Some(t) = self.toast.as_mut() {
            t.1 -= dt;
            drop_toast = t.1 <= 0.0;
        }
        if drop_toast {
            self.toast = None;
        }
        if self.fin_t > 0.0 {
            self.fin_t -= dt;
            if self.fin_t <= 0.0 {
                self.finish(true);
            }
        }

        let cur0 = self.cur;
        let mut stairs = self.upd_player(dt, inp);
        if self.cur != cur0 {
            self.pull_partner();
        }
        if self.p2.is_some() {
            let r = match rem {
                Some(r) => *r,
                None => RemoteCtl::default(),
            };
            // второй игрок: подставляем его на место `self.p` и гоним тем же кодом, что и первого
            self.swap_players();
            self.apply_remote_pos(&r);
            let cur1 = self.cur;
            if self.upd_player(dt, &r.inp) {
                stairs = true;
            }
            if self.cur != cur1 {
                self.pull_partner();
            }
            if r.act {
                let zap = match self.p.act {
                    Some(a) => a.id == ActId::Zap,
                    None => false,
                };
                self.use_act();
                if zap {
                    self.epoch = self.epoch.wrapping_add(1);
                }
            }
            if r.bomb {
                self.throw_bomb();
            }
            self.swap_players();
        }
        if stairs {
            self.floor += 1;
            self.gen_floor();
            let s = format!("Этаж {}", self.floor);
            self.say(&s);
            return;
        }
        self.upd_rooms();

        if !(self.intro > 0.0) && !(self.freeze > 0.0) {
            let n = self.mons.len();
            for i in 0..n {
                if i >= self.mons.len() {
                    break;
                }
                if self.mons[i].dead {
                    continue;
                }
                let (x, y) = (self.mons[i].x, self.mons[i].y);
                if !self.in_cur_cell(x, y) {
                    continue;
                }
                let to2 = self.p2_closer(x, y);
                if to2 {
                    self.swap_players();
                }
                self.ai(i, dt);
                if to2 {
                    self.swap_players();
                }
            }
        }

        let mut i = self.bul.len();
        while i > 0 {
            i -= 1;
            if i < self.bul.len() {
                self.step_bullet(i, dt);
            }
        }
        self.trap_upd(dt);

        for q in self.parts.iter_mut() {
            q.x += q.vx * dt;
            q.y += q.vy * dt;
            q.l -= dt;
        }
        self.parts.retain(|q| q.l > 0.0);
        self.upd_gas(dt);
        self.upd_bombs(dt);
        self.mons.retain(|m| !m.dead);
    }

    // ---------- игрок ----------

    /// Возвращает true, если игрок встал на лестницу.
    fn upd_player(&mut self, dt: f32, inp: &Input) -> bool {
        if let Some(a) = self.p.act.as_mut() {
            if a.kind == ActKind::Time {
                a.c = (a.c + dt).min(a.m);
            }
        }
        if self.p.rg && !self.rs[self.cur].lk {
            self.p.st.dmg /= 2.0;
            self.p.st.rate /= 2.0;
            self.p.rg = false;
        }
        let mut i = self.p.bf.len();
        while i > 0 {
            i -= 1;
            self.p.bf[i].t -= dt;
            if self.p.bf[i].t <= 0.0 {
                let b = self.p.bf.remove(i);
                self.end_buff(b.id);
            }
        }
        self.p.inv -= dt;
        self.p.bt -= dt;
        if self.p.dead {
            return false;
        }
        let fz = if self.intro > 0.0 { 0.0 } else { 1.0 };
        let mut ix = fz * inp.ix;
        let mut iy = fz * inp.iy;
        let im = hyp(ix, iy);
        if im > 1.0 {
            ix /= im;
            iy /= im;
        }
        let k = (dt * 12.0).min(1.0);
        let spd = self.p.st.spd;
        self.p.vx += (ix * spd - self.p.vx) * k;
        self.p.vy += (iy * spd - self.p.vy) * k;
        let (nx, ny, _) = self.try_move(self.p.x, self.p.y, self.p.r, self.p.vx * dt, self.p.vy * dt, true);
        self.p.x = nx;
        self.p.y = ny;
        let moving = hyp(self.p.vx, self.p.vy) > 0.3;
        self.p.anim += dt * if moving { 10.0 } else { 2.0 };
        let ax = fz * inp.ax;
        let ay = fz * inp.ay;
        let am = hyp(ax, ay);
        if am > 0.25 {
            self.p.fx = ax / am;
            self.p.fy = ay / am;
            self.p.cd -= dt;
            if self.p.cd <= 0.0 {
                self.shoot();
                self.p.cd = 1.0 / self.p.st.rate;
            }
        } else {
            self.p.cd = (self.p.cd - dt).max(0.0);
            if im > 0.2 {
                self.p.fx = ix / im;
                self.p.fy = iy / im;
            }
        }
        let px = self.p.x.floor() as i32;
        let py = self.p.y.floor() as i32;
        let here = self.tile(px, py);
        if here == 2 {
            if let Some(a) = self.p.act.as_mut() {
                if a.kind == ActKind::Floor {
                    a.c = a.m;
                }
            }
            return true;
        }
        if here == 8 {
            self.pass_door(px, py);
            return false;
        }
        // золотая дверь открывается ключом
        let around: [(f32, f32); 4] = [(0.7, 0.0), (-0.7, 0.0), (0.0, 0.7), (0.0, -0.7)];
        for &(dx, dy) in around.iter() {
            let tx = (self.p.x + dx).floor() as i32;
            let ty = (self.p.y + dy).floor() as i32;
            if self.tile(tx, ty) == 5 {
                if self.p.st.keys >= 1.0 {
                    self.p.st.keys -= 1.0;
                    self.map[ty as usize][tx as usize] = 8;
                    self.say("Сокровищница открыта!");
                } else if self.p.bt <= 0.0 {
                    self.say("Нужен ключ");
                    self.p.bt = 1.5;
                }
                break;
            }
        }
        self.pickups(dt);
        false
    }

    /// Игрок в `self.p` сменил комнату: напарник (`self.p2`) переходит следом и встаёт рядом.
    fn pull_partner(&mut self) {
        if self.p2.is_none() {
            return;
        }
        let (mx, my) = (self.p.x, self.p.y);
        let (ccx, ccy) = (self.rooms[self.cur].cx as f32 + 0.5, self.rooms[self.cur].cy as f32 + 0.5);
        let (dx, dy) = (ccx - mx, ccy - my);
        let d = hyp(dx, dy);
        let (ox, oy) = if d > 0.01 { (dx / d * 0.6, dy / d * 0.6) } else { (0.6, 0.0) };
        let (mut nx, mut ny) = (mx + ox, my + oy);
        if self.box_hit(nx, ny, 0.3, true) {
            nx = mx;
            ny = my;
        }
        if let Some(q) = self.p2.as_mut() {
            q.x = nx;
            q.y = ny;
            q.vx = 0.0;
            q.vy = 0.0;
            q.inv = q.inv.max(1.5);
        }
        self.epoch = self.epoch.wrapping_add(1);
    }

    /// Хост: берёт позицию, которую второй игрок посчитал у себя (он сейчас лежит в `self.p`).
    fn apply_remote_pos(&mut self, r: &RemoteCtl) {
        if !r.has_pos || r.epoch != self.epoch || self.p.dead {
            return;
        }
        if !(r.x.is_finite() && r.y.is_finite() && r.vx.is_finite() && r.vy.is_finite()) {
            return;
        }
        let (gx, gy) = (self.rooms[self.cur].gx, self.rooms[self.cur].gy);
        if cell_x(r.x) != gx || cell_y(r.y) != gy {
            return;
        }
        if hyp(r.x - self.p.x, r.y - self.p.y) > 4.0 || self.box_hit(r.x, r.y, self.p.r, true) {
            return;
        }
        self.p.x = r.x;
        self.p.y = r.y;
        self.p.vx = r.vx.max(-20.0).min(20.0);
        self.p.vy = r.vy.max(-20.0).min(20.0);
    }

    fn pass_door(&mut self, px: i32, py: i32) {
        let (dx, dy) = {
            let r = &self.rooms[self.cur];
            r.doors.iter().find(|d| d.x == px && d.y == py).map(|d| (d.dx, d.dy)).unwrap_or((0, 0))
        };
        if dx == 0 && dy == 0 {
            return;
        }
        let (cgx, cgy) = (self.rooms[self.cur].gx, self.rooms[self.cur].gy);
        let ti = match self.rooms.iter().position(|o| o.gx == cgx + dx && o.gy == cgy + dy) {
            Some(t) => t,
            None => return,
        };
        self.cur = ti;
        self.rs[ti].vis = true;
        self.bul.clear();
        self.gas.clear();
        self.bombs.clear();
        self.freeze = 0.0;
        self.p.inv = 1.5;
        let (tx, ty) = {
            let t = &self.rooms[ti];
            t.doors.iter().find(|o| o.dx == -dx && o.dy == -dy).map(|o| (o.x, o.y)).unwrap_or((t.cx, t.cy))
        };
        self.p.x = tx as f32 + 0.5 + dx as f32 * 0.85;
        self.p.y = ty as f32 + 0.5 + dy as f32 * 0.85;
        self.p.vx = 0.0;
        self.p.vy = 0.0;
        self.shake = 0.12;
        let (rx, ry, rw, rh, gx, gy) = {
            let t = &self.rooms[ti];
            (t.x, t.y, t.w, t.h, t.gx, t.gy)
        };
        for j in 0..self.mons.len() {
            if self.mons[j].dead {
                continue;
            }
            let (ex, ey) = (self.mons[j].x, self.mons[j].y);
            if cell_x(ex) == gx && cell_y(ey) == gy && hyp(ex - self.p.x, ey - self.p.y) < 3.5 {
                for _ in 0..40 {
                    let nx = rx as f32 + 1.0 + self.rng.below((rw - 2) as usize) as f32 + 0.5;
                    let ny = ry as f32 + 1.0 + self.rng.below((rh - 2) as usize) as f32 + 0.5;
                    if self.tile(nx.floor() as i32, ny.floor() as i32) == 0 && hyp(nx - self.p.x, ny - self.p.y) > 3.5 {
                        let m = &mut self.mons[j];
                        m.x = nx;
                        m.lx = nx;
                        m.y = ny;
                        m.ly = ny;
                        break;
                    }
                }
            }
        }
    }

    fn pickups(&mut self, dt: f32) {
        let dr = DIFFS[self.diff].dr;
        let mut i = self.pick.len();
        while i > 0 {
            i -= 1;
            if i >= self.pick.len() {
                continue;
            }
            let o = self.pick[i].clone();
            if o.gone {
                self.pick.remove(i);
                continue;
            }
            let (px, py) = (self.p.x, self.p.y);
            let d = hyp(px - o.x, py - o.y);
            match o.kind {
                PickKind::Coin => {
                    if d < 0.55 {
                        self.pick[i].x += (px - o.x) * dt * 6.0;
                        self.pick[i].y += (py - o.y) * dt * 6.0;
                    }
                    if d < 0.25 {
                        self.p.st.gold += o.v as f32;
                        self.pick.remove(i);
                    }
                }
                PickKind::Key => {
                    if d < 0.5 {
                        self.p.st.keys += 1.0;
                        self.say("Ключ");
                        self.pick.remove(i);
                    }
                }
                PickKind::Bomb => {
                    if d < 0.5 {
                        if o.pk > 0 {
                            if self.p.keys() < o.pk {
                                if self.p.bt <= 0.0 {
                                    self.say(&format!("Нужно ключей: {}", o.pk));
                                    self.p.bt = 1.5;
                                }
                                continue;
                            }
                            self.p.st.keys -= o.pk as f32;
                        }
                        self.p.bombs += 1;
                        self.say("Бомба");
                        self.pick.remove(i);
                    }
                }
                PickKind::Chest => {
                    if d < 0.7 {
                        if o.gold && self.p.keys() < 1 {
                            if self.p.bt <= 0.0 {
                                self.say("Золотой сундук: нужен ключ");
                                self.p.bt = 1.5;
                            }
                            continue;
                        }
                        if o.gold {
                            self.p.st.keys -= 1.0;
                        }
                        self.pick.remove(i);
                        self.puff(o.x, o.y, "#f0c030", 10);
                        let y = o.y + 0.6;
                        let base_chance: f32 = if o.gold { 0.1 } else { 0.035 };
                        let chance = base_chance * dr;
                        if self.rng.next_f32() < chance {
                            let it = self.take_item() as i32;
                            self.pick.push(Pick::item(o.x - 0.5, o.y, it));
                        }
                        if o.gold {
                            self.pick.push(Pick::new(PickKind::Heart, o.x, y));
                            self.pick.push(Pick::coin(o.x + 0.5, y, 4));
                        } else {
                            let q = self.rng.next_f32();
                            if q < 0.4 {
                                self.pick.push(Pick::coin(o.x, y, 2));
                            } else if q < 0.7 {
                                self.pick.push(Pick::new(PickKind::Key, o.x, y));
                            } else {
                                self.pick.push(Pick::new(PickKind::Heart, o.x, y));
                            }
                        }
                    }
                }
                PickKind::Heart | PickKind::HalfHeart | PickKind::DoubleHeart => {
                    if d < 0.5 && self.p.st.hp < self.p.st.mhp {
                        let amount = match o.kind {
                            PickKind::Heart => 1.0,
                            PickKind::HalfHeart => 0.5,
                            _ => 2.0,
                        };
                        let k = if self.p.st.dark > 0.5 { 0.5 } else { 1.0 };
                        self.p.st.hp = (self.p.st.hp + amount * k).min(self.p.st.mhp);
                        self.pick.remove(i);
                    }
                }
                PickKind::Item => {
                    if d < 0.55 {
                        if o.it < 0 && self.p.st.hp >= self.p.st.mhp {
                            if self.p.bt <= 0.0 {
                                self.say("Здоровье полное");
                                self.p.bt = 1.5;
                            }
                            continue;
                        }
                        if o.pr > 0 && self.p.gold() < o.pr {
                            if self.p.bt <= 0.0 {
                                self.say(&format!("Нужно монет: {}", o.pr));
                                self.p.bt = 1.5;
                            }
                            continue;
                        }
                        if o.pk > 0 && self.p.keys() < o.pk {
                            if self.p.bt <= 0.0 {
                                self.say(&format!("Нужно ключей: {}", o.pk));
                                self.p.bt = 1.5;
                            }
                            continue;
                        }
                        self.p.st.gold -= o.pr as f32;
                        if o.pk > 0 {
                            self.p.st.keys -= o.pk as f32;
                        }
                        if o.it < 0 {
                            self.p.st.hp = (self.p.st.hp + 2.0).min(self.p.st.mhp);
                            self.say("Здоровье восстановлено");
                            self.pick.remove(i);
                        } else {
                            if o.cg != 0 {
                                for j in 0..self.pick.len() {
                                    if j != i && self.pick[j].cg == o.cg {
                                        self.pick[j].gone = true;
                                    }
                                }
                            }
                            self.pick.remove(i);
                            self.take_item_effect(o.it as usize);
                        }
                    }
                }
            }
        }
    }

    // ---------- комнаты ----------

    fn upd_rooms(&mut self) {
        let ri = self.cur;
        let (skip, rx, ry, rw, rh, boss, gx, gy) = {
            let r = &self.rooms[ri];
            (self.rs[ri].cl || r.gold || r.start || r.shop, r.x, r.y, r.w, r.h, r.boss, r.gx, r.gy)
        };
        if skip {
            return;
        }
        let n = self.mons.iter().filter(|e| !e.dead && cell_x(e.x) == gx && cell_y(e.y) == gy).count();
        let inside = |p: &Player| {
            !p.dead && p.x > rx as f32 + 0.2 && p.x < (rx + rw) as f32 - 0.2 && p.y > ry as f32 + 0.2 && p.y < (ry + rh) as f32 - 0.2
        };
        let ins = inside(&self.p) || self.p2.as_ref().map_or(false, |q| inside(q));
        let lk = self.rs[ri].lk;
        if !lk && ins && n > 0 {
            self.rs[ri].lk = true;
            let mut doors: Vec<(i32, i32)> = Vec::new();
            for d in self.rooms[ri].doors.iter() {
                if self.map[d.y as usize][d.x as usize] == 8 {
                    doors.push((d.x, d.y));
                }
            }
            for &(x, y) in doors.iter() {
                self.map[y as usize][x as usize] = 3;
            }
            self.rs[ri].rg = doors;
            if boss {
                self.intro = 3.2;
                self.boss_on = true;
                self.flash = 0.6;
                self.shake = 0.5;
                for m in self.mons.iter_mut() {
                    if m.boss {
                        m.aw = 3.0;
                    }
                }
            } else {
                self.say("Двери заперты!");
            }
        } else if lk && n == 0 {
            self.rs[ri].lk = false;
            self.rs[ri].cl = true;
            if let Some(a) = self.p.act.as_mut() {
                if a.kind == ActKind::Room {
                    a.c = (a.c + 1.0).min(a.m);
                }
            }
            if !boss {
                let dr = DIFFS[self.diff].dr;
                if self.rng.next_f32() < 0.2 * dr {
                    let (x, y) = self.drop_pos(ri);
                    self.pick.push(Pick::new(PickKind::HalfHeart, x, y));
                }
                if self.rng.next_f32() < 0.3 * dr {
                    let (x, y) = self.drop_pos(ri);
                    self.pick.push(Pick::coin(x, y, 1));
                }
                if self.rng.next_f32() < 0.18 * dr {
                    let (x, y) = self.drop_pos(ri);
                    self.pick.push(Pick::new(PickKind::Bomb, x, y));
                }
                if self.rng.next_f32() < 0.012 * dr {
                    let (x, y) = self.drop_pos(ri);
                    let it = self.take_item() as i32;
                    self.pick.push(Pick::item(x, y, it));
                }
            }
            let rg = self.rs[ri].rg.clone();
            for &(x, y) in rg.iter() {
                if self.map[y as usize][x as usize] == 3 {
                    self.map[y as usize][x as usize] = 8;
                }
            }
            if !boss {
                self.say("Комната зачищена");
            }
        }
    }

    // ---------- ИИ монстров ----------

    fn ai(&mut self, i: usize, dt: f32) {
        if self.mons[i].bt > 0.0 {
            self.mons[i].bt -= dt;
            self.hurt_mon(i, dt * 1.6, true);
            if self.mons[i].dead {
                return;
            }
        }
        if self.mons[i].pt > 0.0 {
            self.mons[i].pt -= dt;
            self.hurt_mon(i, dt * 1.1, true);
            if self.mons[i].dead {
                return;
            }
        }
        let mut e = self.mons[i].clone();
        let (px, py) = (self.p.x, self.p.y);
        let dx = px - e.x;
        let dy = py - e.y;
        let d0 = hyp(dx, dy);
        let d = if d0 == 0.0 { 1.0 } else { d0 };
        let ux = dx / d;
        let uy = dy / d;
        e.fl -= dt;
        e.cd -= dt;
        e.ux = ux;
        e.uy = uy;
        if e.boss && self.box_hit(e.x, e.y, e.col_r(), false) {
            let (cx, cy) = (self.rooms[self.cur].cx, self.rooms[self.cur].cy);
            e.x = cx as f32 + 0.5;
            e.y = cy as f32 + 0.5;
        }
        let lim = if e.boss { 14.0 } else { 10.0 };
        e.s_t -= dt;
        if e.s_t <= 0.0 {
            e.s_t = 0.1 + self.rng.next_f32() * 0.06;
            e.sv = d < lim && self.los(e.x, e.y, px, py);
        }
        let see = e.sv && d < lim;
        if see || (e.beh == Beh::Bat && d < 9.0) {
            e.aw = 3.0;
            e.lx = px;
            e.ly = py;
        } else {
            e.aw -= dt;
        }
        if e.beh == Beh::Charge && e.st != 0 {
            e.aw = e.aw.max(0.3);
        }
        let mut tx = 0.0f32;
        let mut ty = 0.0f32;
        let mut sp = e.sp;
        let mut dir = false;
        if e.aw <= 0.0 {
            e.wt -= dt;
            if e.wt <= 0.0 {
                e.wa = self.rng.next_f32() * 6.3;
                e.wt = 1.0 + self.rng.next_f32() * 2.0;
            }
            tx = e.wa.cos() * 0.35;
            ty = e.wa.sin() * 0.35;
        } else {
            let gx = e.lx - e.x;
            let gy = e.ly - e.y;
            let gd0 = hyp(gx, gy);
            let gd = if gd0 == 0.0 { 1.0 } else { gd0 };
            let hx = gx / gd;
            let hy = gy / gd;
            if e.boss {
                let r = self.boss_ai(&mut e, dt, ux, uy);
                tx = r.0;
                ty = r.1;
                sp = r.2 * e.sp;
                if r.3 {
                    dir = true;
                    sp = 1.0;
                }
            } else if e.beh == Beh::Slime {
                tx = hx;
                ty = hy;
                sp *= 0.3 + 1.2 * (self.t * 3.0 + e.a).sin().abs();
            } else if e.beh == Beh::Bat {
                e.a += dt * 1.8 * e.dir;
                if self.rng.next_f32() < dt * 0.4 {
                    e.dir = -e.dir;
                }
                if e.st == 1 {
                    e.stt -= dt;
                    tx = ux;
                    ty = uy;
                    sp *= 2.3;
                    if e.stt <= 0.0 {
                        e.st = 0;
                        e.cd = 2.5 + self.rng.next_f32() * 2.0;
                    }
                } else {
                    let ox = px + e.a.cos() * 2.3 - e.x;
                    let oy = py + e.a.sin() * 2.3 - e.y;
                    let od0 = hyp(ox, oy);
                    let od = if od0 == 0.0 { 1.0 } else { od0 };
                    tx = ox / od;
                    ty = oy / od;
                    if e.cd <= 0.0 {
                        e.st = 1;
                        e.stt = 0.6;
                    }
                }
            } else if e.beh == Beh::Gun {
                if see {
                    e.wt -= dt;
                    if e.wt <= 0.0 {
                        e.dir = -e.dir;
                        e.wt = 1.5 + self.rng.next_f32() * 2.0;
                    }
                    if d < 3.5 {
                        tx = -ux;
                        ty = -uy;
                    } else if d > 6.0 {
                        tx = ux;
                        ty = uy;
                    } else {
                        tx = -uy * e.dir;
                        ty = ux * e.dir;
                    }
                    if e.cd <= 0.0 {
                        e.cd = 1.5 + self.rng.next_f32() * 0.6;
                        let a = uy.atan2(ux);
                        let n: i32 = if e.fan { 3 } else { 1 };
                        for k in 0..n {
                            let off = (k as f32 - (n - 1) as f32 / 2.0) * 0.28;
                            self.enemy_bullet(e.x, e.y, e.boss, e.dm, a + off, 4.6);
                        }
                    }
                } else {
                    tx = hx * 0.7;
                    ty = hy * 0.7;
                }
            } else {
                // бык: заряжается и несётся по прямой
                if e.st == 0 {
                    tx = hx * 0.55;
                    ty = hy * 0.55;
                    if see && d < 7.0 && e.cd <= 0.0 {
                        e.st = 1;
                        e.stt = 0.6;
                        e.dx = ux;
                        e.dy = uy;
                    }
                } else if e.st == 1 {
                    e.stt -= dt;
                    if e.stt <= 0.0 {
                        e.st = 2;
                        e.stt = 1.0;
                    }
                } else if e.st == 2 {
                    dir = true;
                    e.stt -= dt;
                    tx = e.dx * 8.0;
                    ty = e.dy * 8.0;
                    sp = 1.0;
                } else {
                    e.stt -= dt;
                    if e.stt <= 0.0 {
                        e.st = 0;
                        e.cd = 1.2;
                    }
                }
            }
        }
        if !dir {
            if e.tt > 0.0 {
                e.tt -= dt;
                let q = e.ta.cos();
                let s = e.ta.sin();
                let nx = tx * q - ty * s;
                let ny = tx * s + ty * q;
                tx = nx;
                ty = ny;
            }
            for j in 0..self.mons.len() {
                if j == i {
                    continue;
                }
                let o = &self.mons[j];
                if o.dead {
                    continue;
                }
                let ox = e.x - o.x;
                let oy = e.y - o.y;
                let od = hyp(ox, oy);
                if od > 0.0 && od < e.r + o.r + 0.15 {
                    tx += ox / od * 0.7;
                    ty += oy / od * 0.7;
                }
            }
            let k = (dt * 6.0).min(1.0);
            e.vx += (tx * sp - e.vx) * k;
            e.vy += (ty * sp - e.vy) * k;
        } else {
            e.vx = tx * sp;
            e.vy = ty * sp;
        }
        let (nx, ny, h) = self.try_move(e.x, e.y, e.col_r(), e.vx * dt, e.vy * dt, false);
        e.x = nx;
        e.y = ny;
        if h != 0 && !dir && e.tt <= 0.0 {
            e.tt = 0.5;
            e.ta = if self.rng.next_f32() < 0.5 { 1.3 } else { -1.3 };
        }
        if e.beh == Beh::Charge && e.st == 2 && (h != 0 || e.stt <= 0.0) {
            e.st = 3;
            e.stt = 0.9;
            self.shake = 0.12;
        }
        let touch = hyp(px - e.x, py - e.y) < e.r + self.p.r * 0.8;
        let dmg = if e.st == 2 { 2.0 } else { e.dm };
        if i < self.mons.len() {
            self.mons[i] = e;
        }
        if touch {
            self.hurt_player(dmg);
        }
    }

    /// Порядок атак босса. Возвращает (направление x, y, множитель скорости, рывок).
    fn boss_ai(&mut self, e: &mut Monster, dt: f32, ux: f32, uy: f32) -> (f32, f32, f32, bool) {
        e.stt -= dt;
        if e.stt <= 0.0 {
            let n = e.q.chars().count();
            e.si = (e.si + 1) % n;
            let s = e.q.chars().nth(e.si).unwrap_or('c');
            e.bs = s;
            e.stt = match s {
                'c' => 2.4,
                'r' => 0.9,
                'f' => 0.9,
                's' => 0.9,
                'd' => 1.3,
                _ => 2.6,
            };
            if s == 'r' {
                self.shake = 0.25;
                let cnt = std::cmp::min(36, 14 + (self.floor >> 1) * 4);
                let o = self.rng.next_f32() * 6.0;
                for i in 0..cnt {
                    self.enemy_bullet(e.x, e.y, true, e.dm, o + i as f32 * 6.283 / cnt as f32, 4.4);
                }
            }
            if s == 'f' {
                let a = uy.atan2(ux);
                let kk: i32 = if self.floor >= 3 { 3 } else { 2 };
                for i in -kk..=kk {
                    self.enemy_bullet(e.x, e.y, true, e.dm, a + i as f32 * 0.2, 5.4);
                }
            }
            let cap = if e.bk == 4 { 6 } else { 9 };
            if s == 's' && self.mons.len() < cap {
                let kinds: [MonKind; 2] = match self.path {
                    Some(pa) if self.floor > 6 => {
                        let m = path_mobs(pa);
                        [m[0], m[1]]
                    }
                    _ => [MonKind::Bat, MonKind::Slime],
                };
                let ox = if self.wall(e.x + 1.0, e.y, false) { 0.0 } else { 1.0 };
                let m1 = self.mob(kinds[0], e.x + ox, e.y);
                self.mons.push(m1);
                if e.bk != 4 {
                    let ox2 = if self.wall(e.x - 1.0, e.y, false) { 0.0 } else { -1.0 };
                    let m2 = self.mob(kinds[1], e.x + ox2, e.y);
                    self.mons.push(m2);
                }
            }
            if s == 'd' {
                e.dx = ux;
                e.dy = uy;
            }
            if s == 'p' {
                self.ring_atk(e);
            }
        }
        e.wind = e.bs == 'd' && e.stt > 0.7;
        if e.bk == 4 {
            e.sdt -= dt;
            if e.sdt <= 0.0 {
                e.sd = if self.rng.next_f32() < 0.5 { 1.0 } else { -1.0 };
                e.sdt = 1.5 + self.rng.next_f32() * 1.5;
            }
            let d = hyp(self.p.x - e.x, self.p.y - e.y);
            let k = if d > 5.0 {
                0.7
            } else if d < 3.0 {
                -0.7
            } else {
                0.0
            };
            return (-uy * e.sd * 0.8 + ux * k, ux * e.sd * 0.8 + uy * k, 0.85, false);
        }
        if e.bs == 'c' {
            return (ux, uy, 1.0, false);
        }
        if e.bs == 'd' && !e.wind {
            return (e.dx * 7.0, e.dy * 7.0, 1.0, true);
        }
        (0.0, 0.0, 0.0, false)
    }

    pub fn enemy_bullet(&mut self, x: f32, y: f32, boss: bool, dm: f32, a: f32, s: f32) {
        if self.bul.len() > 280 {
            return;
        }
        let k = DIFFS[self.diff].eb;
        let r = if boss { 0.17 } else { 0.13 } * k;
        let mut b = Bullet::base(x, y, a.cos() * s * k, a.sin() * s * k, 3.2 / k, r);
        b.pl = false;
        b.dm = if dm > 0.0 { dm } else { 1.0 };
        self.bul.push(b);
    }

    // ---------- стрельба игрока ----------

    pub fn shoot(&mut self) {
        let st = self.p.st.clone();
        let (px, py, fx, fy, ch) = (self.p.x, self.p.y, self.p.fx, self.p.fy, self.p.ch);
        let own = self.me();
        let b = fy.atan2(fx);
        if self.p.melee {
            self.throw_boom(b);
            return;
        }
        let n = std::cmp::max(1, st.multi.round() as i32);
        let skin = match ch {
            5 => Skin::Weak,
            6 => Skin::LetterN,
            7 => Skin::Tape,
            9 => Skin::Astral,
            11 => Skin::Bottle,
            _ => {
                if st.terra > 0.5 {
                    Skin::Terra
                } else {
                    Skin::Normal
                }
            }
        };
        for i in 0..n {
            let a = b + (i as f32 - (n - 1) as f32 / 2.0) * 0.2 + (self.rng.next_f32() - 0.5) * 0.05;
            let base_r: f32 = if ch > 5 { 0.15 } else { 0.12 };
            let rad = ((base_r + st.big * 0.1) * st.msz).max(0.05);
            let mut bl = Bullet::base(px + a.cos() * 0.35, py + a.sin() * 0.35, a.cos() * 8.0 * st.bsp, a.sin() * 8.0 * st.bsp, st.range / st.bsp, rad);
            bl.d = st.dmg * if ch == 5 { 1.25 } else { 1.0 };
            bl.own = own;
            bl.skin = skin;
            bl.pi = st.pierce.round() as i32;
            bl.bn = st.bounce.round() as i32;
            bl.hm = st.home > 0.5;
            bl.bu = st.burn > 0.5;
            bl.po = st.poison > 0.5;
            bl.tb = st.terra > 0.5;
            self.bul.push(bl);
        }
        if st.prism > 0.5 {
            self.p.pc += 1;
            if self.p.pc % 4 == 0 {
                for j in -2i32..=2 {
                    let a = b + j as f32 * 0.16;
                    let mut bl = Bullet::base(px + a.cos() * 0.35, py + a.sin() * 0.35, a.cos() * 9.0, a.sin() * 9.0, st.range, 0.13);
                    bl.d = st.dmg * 0.6;
                    bl.pi = 2 + st.pierce.round() as i32;
                    bl.bn = st.bounce.round() as i32;
                    bl.bu = st.burn > 0.5;
                    bl.po = st.poison > 0.5;
                    bl.rb = j + 3;
                    bl.own = own;
                    bl.skin = Skin::Rainbow;
                    self.bul.push(bl);
                }
            }
        }
    }

    /// Бумеранг Стража: одновременно в полёте не больше `multi` штук.
    fn throw_boom(&mut self, b: f32) {
        let st = self.p.st.clone();
        let own = self.me();
        let active = self.bul.iter().filter(|q| q.bm && q.own == own).count() as i32;
        if active >= st.multi.round() as i32 {
            return;
        }
        let side: f32 = if active % 2 == 1 { 1.0 } else { -1.0 };
        let off: f32 = if active > 0 { side * 0.14 * ((active as f32) / 2.0).ceil() } else { 0.0 };
        let a = b + off;
        let (px, py) = (self.p.x, self.p.y);
        let mut bl = Bullet::base(px + a.cos() * 0.35, py + a.sin() * 0.35, a.cos() * 10.0, a.sin() * 10.0, 12.0, ((0.26 + st.big * 0.08) * st.msz).max(0.12));
        bl.d = st.dmg * 1.25;
        bl.pi = 999;
        bl.bu = st.burn > 0.5;
        bl.po = st.poison > 0.5;
        bl.tb = st.terra > 0.5;
        bl.bm = true;
        bl.own = own;
        bl.rot = (active as f32) * 1.9;
        bl.skin = Skin::Boomerang;
        bl.dist = 2.0 + st.range * 2.4;
        self.bul.push(bl);
    }

    fn boom(&mut self, b: &mut Bullet, dt: f32) {
        // к кому возвращается: владелец 0 лежит в `p`, владелец 1 — в `p2`
        let (ox, oy, odead) = if b.own == 1 {
            match self.p2.as_ref() {
                Some(q) => (q.x, q.y, q.dead),
                None => (b.x, b.y, true),
            }
        } else {
            (self.p.x, self.p.y, self.p.dead)
        };
        if odead {
            b.l = 0.0;
            return;
        }
        b.rot += dt * if b.ph { 21.0 } else { 16.0 };
        if b.rot > 6.2831855 {
            b.rot -= 6.2831855;
        }
        if !b.ph {
            b.tr += hyp(b.vx, b.vy) * dt;
            if b.tr >= b.dist {
                b.ph = true;
                b.hit.clear();
            }
        }
        if b.ph {
            let dx = ox - b.x;
            let dy = oy - b.y;
            let d0 = hyp(dx, dy);
            let d = if d0 == 0.0 { 1.0 } else { d0 };
            if d < 0.5 {
                b.l = 0.0;
                self.puff(ox, oy, "#d6e4f5", 4);
                return;
            }
            b.vx = dx / d * 11.0;
            b.vy = dy / d * 11.0;
            b.l = 9.0;
        }
    }

    // ---------- пули ----------

    fn step_bullet(&mut self, i: usize, dt: f32) {
        if self.freeze > 0.0 && !self.bul[i].pl {
            return;
        }
        // список попаданий забираем без копирования, чтобы не выделять память каждый кадр
        let hit = std::mem::take(&mut self.bul[i].hit);
        let mut b = self.bul[i].clone();
        b.hit = hit;
        if b.hm {
            let mut best: Option<usize> = None;
            let mut bd = 36.0f32;
            for (j, e) in self.mons.iter().enumerate() {
                if e.dead {
                    continue;
                }
                let d = (e.x - b.x) * (e.x - b.x) + (e.y - b.y) * (e.y - b.y);
                if d < bd {
                    bd = d;
                    best = Some(j);
                }
            }
            if let Some(j) = best {
                let (ex, ey) = (self.mons[j].x, self.mons[j].y);
                let s = hyp(b.vx, b.vy);
                let a = b.vy.atan2(b.vx);
                let mut da = (ey - b.y).atan2(ex - b.x) - a;
                da = da.sin().atan2(da.cos());
                let na = a + da * (dt * 5.0).min(1.0);
                b.vx = na.cos() * s;
                b.vy = na.sin() * s;
            }
        }
        if b.bm {
            self.boom(&mut b, dt);
        }
        b.l -= dt;
        if (b.tb || b.rb > 0 || b.skin == Skin::Weak) && self.parts.len() < 380 && self.rng.next_f32() < 0.5 {
            let col = if b.rb > 0 {
                let h = (b.rb as f32 * 60.0 + self.t * 200.0) % 360.0;
                hsl_to_rgb(h, 0.95, 0.6)
            } else if b.skin == Skin::Weak {
                (79, 184, 255)
            } else {
                (109, 255, 176)
            };
            self.add_part(Part { x: b.x, y: b.y, vx: 0.0, vy: 0.0, l: 0.3, col });
        }
        let nx = b.x + b.vx * dt;
        let ny = b.y + b.vy * dt;
        if !(b.bm && b.ph) && self.wall(nx, ny, false) {
            if b.pl && !self.bar.is_empty() {
                self.hit_barrel(nx, ny, b.d);
            }
            if b.bm {
                if !b.ph {
                    b.ph = true;
                    b.hit.clear();
                }
            } else if b.bn > 0 {
                b.bn -= 1;
                if self.wall(nx, b.y, false) {
                    b.vx = -b.vx;
                }
                if self.wall(b.x, ny, false) {
                    b.vy = -b.vy;
                }
                if !self.wall(nx, b.y, false) && !self.wall(b.x, ny, false) {
                    b.vx = -b.vx;
                    b.vy = -b.vy;
                }
            } else {
                self.puff(b.x, b.y, "#aaaaaa", 3);
                b.l = 0.0;
            }
        } else {
            b.x = nx;
            b.y = ny;
        }
        if b.pl {
            for j in 0..self.mons.len() {
                if self.mons[j].dead {
                    continue;
                }
                let id = self.mons[j].id;
                if b.hit.contains(&id) {
                    continue;
                }
                let (ex, ey, er) = (self.mons[j].x, self.mons[j].y, self.mons[j].r);
                if hyp(ex - b.x, ey - b.y) < er + b.r {
                    // убийство и заряд активки засчитываем стрелку
                    let sw = b.own == 1 && self.p2.is_some();
                    if sw {
                        self.swap_players();
                    }
                    self.hurt_mon(j, b.d, false);
                    if sw {
                        self.swap_players();
                    }
                    if b.bu {
                        self.mons[j].bt = 2.5;
                    }
                    if b.po {
                        self.mons[j].pt = 4.0;
                    }
                    b.hit.push(id);
                    self.puff(b.x, b.y, "#ffffff", 3);
                    let left = b.pi;
                    b.pi -= 1;
                    if left <= 0 {
                        b.l = 0.0;
                        break;
                    }
                }
            }
        } else {
            if !self.p.dead && hyp(self.p.x - b.x, self.p.y - b.y) < self.p.r + b.r {
                self.hurt_player(b.dm);
                b.l = 0.0;
            } else {
                let hit2 = match self.p2.as_ref() {
                    Some(q) => !q.dead && hyp(q.x - b.x, q.y - b.y) < q.r + b.r,
                    None => false,
                };
                if hit2 {
                    self.swap_players();
                    self.hurt_player(b.dm);
                    self.swap_players();
                    b.l = 0.0;
                }
            }
        }
        if i >= self.bul.len() {
            return;
        }
        if b.l <= 0.0 {
            if b.skin == Skin::Bottle {
                self.shatter(&b);
            }
            self.bul.remove(i);
        } else {
            self.bul[i] = b;
        }
    }

    // ---------- ловушки, газ, бомбы ----------

    /// 0 — шипы убраны, 1 — предупреждение, 2 — шипы выдвинуты.
    pub fn spike_state(&self, s: &Spike) -> u8 {
        let ph = (self.t + s.o) % 3.2;
        if ph < 1.9 {
            0
        } else if ph < 2.5 {
            1
        } else {
            2
        }
    }

    fn trap_upd(&mut self, dt: f32) {
        let (cgx, cgy) = (self.rooms[self.cur].gx, self.rooms[self.cur].gy);
        for si in 0..self.spk.len() {
            let k = self.spk[si];
            if k.x / crate::dungeon::CW != cgx || k.y / crate::dungeon::CH != cgy {
                continue;
            }
            if self.spike_state(&k) == 2 {
                self.each_player(|g| {
                    if g.p.x.floor() as i32 == k.x && g.p.y.floor() as i32 == k.y {
                        g.hurt_player(1.0);
                    }
                });
                if !k.mh {
                    self.spk[si].mh = true;
                    for j in 0..self.mons.len() {
                        let e = &self.mons[j];
                        if e.dead || e.boss || e.beh == Beh::Bat {
                            continue;
                        }
                        if e.x.floor() as i32 == k.x && e.y.floor() as i32 == k.y {
                            self.hurt_mon(j, 3.0, false);
                        }
                    }
                }
            } else {
                self.spk[si].mh = false;
            }
        }
        let mut i = self.rings.len();
        while i > 0 {
            i -= 1;
            if i >= self.rings.len() {
                continue;
            }
            let mut g = self.rings[i];
            if g.t > 0.0 {
                g.t -= dt;
                if let Some(e) = self.mons.iter().find(|m| m.id == g.eid && !m.dead) {
                    g.x = e.x;
                    g.y = e.y;
                }
                self.rings[i] = g;
                continue;
            }
            g.r += g.sp * dt;
            if g.r > 11.0 {
                self.rings.remove(i);
                continue;
            }
            self.rings[i] = g;
            self.each_player(|gm| {
                let dx = gm.p.x - g.x;
                let dy = gm.p.y - g.y;
                let d = hyp(dx, dy);
                if (d - g.r).abs() < 0.4 {
                    let da = dy.atan2(dx) - g.g;
                    let da = da.sin().atan2(da.cos()).abs();
                    if da > g.gw {
                        gm.hurt_player(1.0);
                    }
                }
            });
        }
    }

    fn upd_gas(&mut self, dt: f32) {
        let mut i = self.gas.len();
        while i > 0 {
            i -= 1;
            self.gas[i].l -= dt;
            let g = self.gas[i];
            for j in 0..self.mons.len() {
                let e = &self.mons[j];
                if !e.dead && hyp(e.x - g.x, e.y - g.y) < 1.3 {
                    self.hurt_mon(j, dt * 3.0, true);
                }
            }
            if self.rng.next_f32() < dt * 25.0 && self.parts.len() < 380 {
                let ox = (self.rng.next_f32() - 0.5) * 2.0;
                let oy = (self.rng.next_f32() - 0.5) * 2.0;
                self.add_part(Part { x: g.x + ox, y: g.y + oy, vx: 0.0, vy: -0.6, l: 0.5, col: (143, 224, 58) });
            }
            if g.l <= 0.0 && i < self.gas.len() {
                self.gas.remove(i);
            }
        }
    }

    fn upd_bombs(&mut self, dt: f32) {
        let mut i = self.bombs.len();
        while i > 0 {
            i -= 1;
            if i >= self.bombs.len() {
                continue;
            }
            let mut b = self.bombs[i];
            if b.vx != 0.0 || b.vy != 0.0 {
                let nx = b.x + b.vx * dt;
                let ny = b.y + b.vy * dt;
                if self.wall(nx, b.y, false) {
                    b.vx *= -0.35;
                } else {
                    b.x = nx;
                }
                if self.wall(b.x, ny, false) {
                    b.vy *= -0.35;
                } else {
                    b.y = ny;
                }
                let fr = (1.0 - dt * 3.2).max(0.0);
                b.vx *= fr;
                b.vy *= fr;
                if b.vx.abs() + b.vy.abs() < 0.15 {
                    b.vx = 0.0;
                    b.vy = 0.0;
                }
            }
            b.l -= dt;
            if b.l <= 0.0 {
                if b.hostile {
                    self.puff(b.x, b.y, "#ff8a2a", 16);
                    self.shake = 0.2;
                    self.each_player(|g| {
                        if hyp(g.p.x - b.x, g.p.y - b.y) < 2.0 {
                            g.hurt_player(1.0);
                        }
                    });
                } else {
                    self.blast(b.x, b.y, 3.0, 14.0, "#ffb030", BlastFx::None);
                    self.break_blocks(b.x, b.y, 2.6);
                    self.barrel_boom(b.x, b.y, 2.6);
                }
                if i < self.bombs.len() {
                    self.bombs.remove(i);
                }
            } else {
                self.bombs[i] = b;
            }
        }
    }

    pub fn hit_barrel(&mut self, x: f32, y: f32, d: f32) {
        let k = (y.floor() as i32) * MAP_COLS + x.floor() as i32;
        let dmg = if d > 0.0 { d } else { 1.0 };
        let dead = match self.bar.get_mut(&k) {
            Some(o) => {
                o.hp -= dmg;
                o.hp <= 0.0
            }
            None => false,
        };
        if dead {
            self.barrel_die(k);
        }
    }
}

/// Радуга для пуль «Последней призмы».
pub fn hsl_to_rgb(h: f32, s: f32, l: f32) -> (u8, u8, u8) {
    let c = (1.0 - (2.0 * l - 1.0).abs()) * s;
    let hp = h / 60.0;
    let x = c * (1.0 - (hp % 2.0 - 1.0).abs());
    let (r1, g1, b1) = if hp < 1.0 {
        (c, x, 0.0)
    } else if hp < 2.0 {
        (x, c, 0.0)
    } else if hp < 3.0 {
        (0.0, c, x)
    } else if hp < 4.0 {
        (0.0, x, c)
    } else if hp < 5.0 {
        (x, 0.0, c)
    } else {
        (c, 0.0, x)
    };
    let m = l - c / 2.0;
    (((r1 + m) * 255.0) as u8, ((g1 + m) * 255.0) as u8, ((b1 + m) * 255.0) as u8)
}
