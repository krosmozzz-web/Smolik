//! Характеристики героя и эффекты предметов. Сгенерировано из JS-версии: имена полей совпадают.
use crate::data::CharacterDef;

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Stat { Dmg, Rate, Spd, Hp, Mhp, Multi, Pierce, Bounce, Home, Vamp, Shield, Range, Big, Burn, Keys, Bsp, Gold, Luck, Poison, Dark, Terra, Prism, Msz, Act }

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Op { Add, Mul, Set }

#[derive(Clone, Copy, Debug)]
pub struct Effect { pub stat: Stat, pub op: Op, pub value: f32 }

#[derive(Clone, Debug, PartialEq)]
pub struct Stats {
    pub dmg: f32,
    pub rate: f32,
    pub spd: f32,
    pub hp: f32,
    pub mhp: f32,
    pub multi: f32,
    pub pierce: f32,
    pub bounce: f32,
    pub home: f32,
    pub vamp: f32,
    pub shield: f32,
    pub range: f32,
    pub big: f32,
    pub burn: f32,
    pub keys: f32,
    pub bsp: f32,
    pub gold: f32,
    pub luck: f32,
    pub poison: f32,
    pub dark: f32,
    pub terra: f32,
    pub prism: f32,
    pub msz: f32,
    pub act: f32,
}

impl Default for Stats {
    fn default() -> Self {
        Stats {
            dmg: 3.5,
            rate: 2.6,
            spd: 3.6,
            hp: 3.5,
            mhp: 3.5,
            multi: 1.0,
            pierce: 0.0,
            bounce: 0.0,
            home: 0.0,
            vamp: 0.0,
            shield: 0.0,
            range: 0.95,
            big: 0.0,
            burn: 0.0,
            keys: 0.0,
            bsp: 1.0,
            gold: 0.0,
            luck: 0.0,
            poison: 0.0,
            dark: 0.0,
            terra: 0.0,
            prism: 0.0,
            msz: 1.0,
            act: 0.0,
        }
    }
}

impl Stats {
    pub fn get(&self, s: Stat) -> f32 {
        match s {
            Stat::Dmg => self.dmg,
            Stat::Rate => self.rate,
            Stat::Spd => self.spd,
            Stat::Hp => self.hp,
            Stat::Mhp => self.mhp,
            Stat::Multi => self.multi,
            Stat::Pierce => self.pierce,
            Stat::Bounce => self.bounce,
            Stat::Home => self.home,
            Stat::Vamp => self.vamp,
            Stat::Shield => self.shield,
            Stat::Range => self.range,
            Stat::Big => self.big,
            Stat::Burn => self.burn,
            Stat::Keys => self.keys,
            Stat::Bsp => self.bsp,
            Stat::Gold => self.gold,
            Stat::Luck => self.luck,
            Stat::Poison => self.poison,
            Stat::Dark => self.dark,
            Stat::Terra => self.terra,
            Stat::Prism => self.prism,
            Stat::Msz => self.msz,
            Stat::Act => self.act,
        }
    }

    pub fn set(&mut self, s: Stat, v: f32) {
        match s {
            Stat::Dmg => self.dmg = v,
            Stat::Rate => self.rate = v,
            Stat::Spd => self.spd = v,
            Stat::Hp => self.hp = v,
            Stat::Mhp => self.mhp = v,
            Stat::Multi => self.multi = v,
            Stat::Pierce => self.pierce = v,
            Stat::Bounce => self.bounce = v,
            Stat::Home => self.home = v,
            Stat::Vamp => self.vamp = v,
            Stat::Shield => self.shield = v,
            Stat::Range => self.range = v,
            Stat::Big => self.big = v,
            Stat::Burn => self.burn = v,
            Stat::Keys => self.keys = v,
            Stat::Bsp => self.bsp = v,
            Stat::Gold => self.gold = v,
            Stat::Luck => self.luck = v,
            Stat::Poison => self.poison = v,
            Stat::Dark => self.dark = v,
            Stat::Terra => self.terra = v,
            Stat::Prism => self.prism = v,
            Stat::Msz => self.msz = v,
            Stat::Act => self.act = v,
        }
    }

    /// Применяет один эффект предмета.
    pub fn apply(&mut self, e: &Effect) {
        let cur = self.get(e.stat);
        let next = match e.op {
            Op::Add => cur + e.value,
            Op::Mul => cur * e.value,
            Op::Set => e.value,
        };
        self.set(e.stat, next);
    }

    /// Стартовые характеристики выбранного героя.
    pub fn from_character(c: &CharacterDef) -> Stats {
        let mut s = Stats::default();
        s.hp = c.hp;
        s.mhp = c.hp;
        s.dmg = c.damage;
        s.rate = c.fire_rate;
        s.spd = c.speed;
        s.pierce = c.pierce as f32;
        s.big = c.big;
        s.home = if c.home { 1.0 } else { 0.0 };
        if c.multi > 1 {
            s.multi = c.multi as f32;
        }
        s
    }
}
