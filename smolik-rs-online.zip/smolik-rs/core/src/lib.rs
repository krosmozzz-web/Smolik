//! Ядро Smolik: данные и правила без графики. Графика живёт в крейте `app`.
pub mod actions;
pub mod data;
pub mod defs;
pub mod dungeon;
pub mod game;
pub mod profile;
pub mod rng;
pub mod sim;
pub mod stats;
pub mod wire;

#[cfg(test)]
mod tests {
    use super::*;
    use crate::defs::*;
    use crate::game::{Game, Input, PickKind};
    use crate::profile::{Profile, RunResult};
    use crate::stats::Stats;

    #[test]
    fn data_counts_match_js_version() {
        assert_eq!(data::CHARACTERS.len(), 12);
        assert_eq!(data::ITEMS.len(), 74);
        assert_eq!(data::BOSSES.len(), 15);
    }

    #[test]
    fn soda_has_four_hp() {
        let soda = data::CHARACTERS.iter().find(|c| c.name == "Сода").unwrap();
        assert_eq!(soda.hp, 4.0);
    }

    #[test]
    fn sharp_blade_adds_one_damage() {
        let item = data::ITEMS.iter().find(|i| i.name == "Острый клинок").unwrap();
        let mut st = Stats::default();
        let before = st.dmg;
        for e in item.effects {
            st.apply(e);
        }
        assert_eq!(st.dmg, before + 1.0);
    }

    #[test]
    fn rng_is_deterministic() {
        let mut a = rng::Rng::new(42);
        let mut b = rng::Rng::new(42);
        for _ in 0..100 {
            assert_eq!(a.next_u32(), b.next_u32());
        }
    }

    #[test]
    fn rng_matches_js_mulberry32() {
        let mut r = rng::Rng::new(42);
        let expected: [u32; 5] = [2581720956, 1925393290, 3661312704, 2876485805, 750819978];
        for e in expected.iter() {
            assert_eq!(r.next_u32(), *e);
        }
    }

    /// (сид, этаж, хеш раскладки, число комнат), снято с JS-версии с тем же генератором.
    const GOLDEN: &[(u32, i32, u64, usize)] = &[
        (1, 1, 12770323758523346274, 10),
        (1, 2, 13392601199625697198, 12),
        (1, 3, 15815987315828362891, 13),
        (1, 4, 15815987315828362891, 13),
        (1, 6, 15815987315828362891, 13),
        (1, 8, 15815987315828362891, 13),
        (2, 1, 7610303640252760016, 10),
        (2, 2, 6615288532099549482, 12),
        (2, 3, 2695208514962808304, 13),
        (2, 4, 2695208514962808304, 13),
        (2, 6, 2695208514962808304, 13),
        (2, 8, 2695208514962808304, 13),
        (3, 1, 8643431129028617793, 10),
        (3, 2, 7935723418773046036, 12),
        (3, 3, 4808102707343809722, 13),
        (3, 4, 4808102707343809722, 13),
        (3, 6, 4808102707343809722, 13),
        (3, 8, 4808102707343809722, 13),
        (4, 1, 16584844656889740961, 10),
        (4, 2, 852056374850529444, 12),
        (4, 3, 15585059936425459363, 13),
        (4, 4, 15585059936425459363, 13),
        (4, 6, 15585059936425459363, 13),
        (4, 8, 15585059936425459363, 13),
        (5, 1, 6119880428164057213, 10),
        (5, 2, 3691817963430426801, 12),
        (5, 3, 9006364235839568236, 13),
        (5, 4, 9006364235839568236, 13),
        (5, 6, 9006364235839568236, 13),
        (5, 8, 9006364235839568236, 13),
        (6, 1, 17926733154950999135, 10),
        (6, 2, 6110244055787236785, 12),
        (6, 3, 2503024409284290420, 13),
        (6, 4, 2503024409284290420, 13),
        (6, 6, 2503024409284290420, 13),
        (6, 8, 2503024409284290420, 13),
    ];

    #[test]
    fn layouts_match_js_golden() {
        for &(seed, floor, hash, rooms) in GOLDEN.iter() {
            let mut r = rng::Rng::new(seed);
            let layout = dungeon::gen_layout(floor, &mut r);
            assert_eq!(layout.rooms.len(), rooms, "seed {} floor {}", seed, floor);
            assert_eq!(dungeon::digest(&layout), hash, "seed {} floor {}", seed, floor);
        }
    }

    #[test]
    fn boss_door_is_open_and_gold_door_locks_after_floor_one() {
        let mut r = rng::Rng::new(1);
        let l = dungeon::gen_layout(3, &mut r);
        let (bx, by) = l.boss_door;
        assert_eq!(l.map[by as usize][bx as usize], 8);
        let gold = l.rooms.iter().find(|x| x.gold).unwrap();
        let parent = &l.rooms[gold.parent.unwrap()];
        let door = parent.doors.iter().find(|d| (d.dx, d.dy) == (gold.gx - parent.gx, gold.gy - parent.gy)).unwrap();
        assert_eq!(l.map[door.y as usize][door.x as usize], 5);
    }

    // ---------- новое: игровое ядро ----------

    #[test]
    fn item_table_indices_match_rules() {
        let name = |i: usize| data::ITEMS[i].name;
        assert_eq!(name(17), "Зелье Эниприсы");
        assert_eq!(name(34), "Сердце Зверя");
        assert_eq!(name(44), "Горшок мёда");
        assert_eq!(name(52), "Святой Грааль");
        assert_eq!(name(56), "Зап Эниприсы");
        assert_eq!(name(59), "Клинок Холодной Скорби");
        assert_eq!(name(60), "Бомба Богдана");
        assert_eq!(name(69), "Рикошет-шторм");
        assert_eq!(name(70), "Клинок Земли");
        assert_eq!(name(72), "Микро-пули");
        for i in 56..=69 {
            assert!(item_active(i).is_some(), "item {}", i);
        }
        assert!(item_excluded(59));
        assert_eq!(item_path(45), Some(Path::Hell));
        assert_eq!(item_path(54), Some(Path::Heaven));
    }

    #[test]
    fn every_floor_generates_with_boss_shop_and_items() {
        for floor in 1..=9 {
            let mut g = Game::new(0, [0; 3], 1, 100 + floor as u32);
            g.floor = floor;
            if floor > 6 {
                g.path = Some(if floor % 2 == 0 { Path::Hell } else { Path::Heaven });
            }
            g.gen_floor();
            assert_eq!(g.mons.iter().filter(|m| m.boss).count(), 1, "floor {}", floor);
            let items = g.pick.iter().filter(|p| p.kind == PickKind::Item).count();
            assert_eq!(items, 6, "floor {}", floor);
            assert!(g.mons.iter().all(|m| m.hp.is_finite() && m.x.is_finite()));
            let (sx, sy) = g.stairs;
            assert_eq!(g.map[sy as usize][sx as usize], 0, "stairs spot must be floor, floor {}", floor);
        }
    }

    #[test]
    fn same_seed_gives_same_floor() {
        let a = Game::new(0, [0; 3], 1, 7);
        let b = Game::new(0, [0; 3], 1, 7);
        assert_eq!(a.map, b.map);
        assert_eq!(a.mons.len(), b.mons.len());
        for (m, n) in a.mons.iter().zip(b.mons.iter()) {
            assert_eq!(m.x, n.x);
            assert_eq!(m.y, n.y);
        }
    }

    #[test]
    fn heroes_start_with_their_stats() {
        let g = Game::new(1, [0; 3], 1, 1);
        assert_eq!(g.p.st.hp, 3.0);
        assert_eq!(g.p.st.pierce, 1.0);
        let g = Game::new(4, [0; 3], 1, 1);
        assert_eq!(g.p.st.multi, 2.0);
        let g = Game::new(10, [0; 3], 1, 1);
        assert_eq!(g.p.st.shield, 3.0);
        assert!(g.p.melee);
        let g = Game::new(8, [0; 3], 1, 1);
        assert!(g.p.act.is_some());
    }

    #[test]
    fn upgrades_and_casual_bonus_apply() {
        let g = Game::new(0, [2, 2, 2], 0, 1);
        assert_eq!(g.p.st.mhp, 3.5 + 2.0 + 1.0);
        assert!((g.p.st.dmg - 4.5).abs() < 1e-5);
        assert!((g.p.st.rate - 2.6 * 1.2).abs() < 1e-5);
        assert_eq!(g.p.st.shield, 1.0);
    }

    #[test]
    fn items_change_stats() {
        let mut g = Game::new(0, [0; 3], 1, 1);
        let dmg = g.p.st.dmg;
        g.apply_item(0);
        assert_eq!(g.p.st.dmg, dmg + 1.0);
        g.p.st.hp = 1.0;
        g.apply_item(17);
        assert_eq!(g.p.st.hp, g.p.st.mhp);
        g.apply_item(34);
        assert_eq!(g.p.st.mhp, 4.5);
        g.apply_item(56);
        assert_eq!(g.p.act.unwrap().id, ActId::Zap);
        g.apply_item(59);
        assert!(g.p.st.dark > 0.5);
        assert_eq!(g.p.act.unwrap().id, ActId::Reap);
        assert_eq!(g.p.act.unwrap().c, 0.0);
    }

    #[test]
    fn bot_run_does_not_panic_and_stays_finite() {
        for seed in 1..=4u32 {
            for hero in [0usize, 4, 10, 11] {
                let mut g = Game::new(hero, [0; 3], 1, seed);
                g.p.st.mhp = 60.0;
                g.p.st.hp = 60.0;
                let mut t = 0.0f32;
                for step in 0..6000 {
                    t += 0.016;
                    let inp = Input { ix: (t * 0.7).cos(), iy: (t * 1.1).sin(), ax: (t * 2.3).cos(), ay: (t * 1.7).sin() };
                    g.update(0.016, &inp);
                    if step % 400 == 0 {
                        g.use_act();
                        g.throw_bomb();
                    }
                    if g.choose {
                        g.choose_path(Path::Hell);
                    }
                    assert!(g.p.x.is_finite() && g.p.y.is_finite(), "seed {} hero {} step {}", seed, hero, step);
                    if g.over {
                        break;
                    }
                }
            }
        }
    }

    #[test]
    fn killing_all_mobs_clears_room_and_boss_drops_choice() {
        let mut g = Game::new(0, [0; 3], 1, 3);
        g.p.st.mhp = 99.0;
        g.p.st.hp = 99.0;
        // убиваем босса напрямую
        let bi = g.mons.iter().position(|m| m.boss).unwrap();
        g.mons[bi].hp = 0.0;
        g.hurt_mon(bi, 1.0, false);
        assert!(g.mons[bi].dead);
        let (sx, sy) = g.stairs;
        assert_eq!(g.map[sy as usize][sx as usize], 2);
        let group: Vec<_> = g.pick.iter().filter(|p| p.kind == PickKind::Item && p.cg > 0 && p.cg < 1000).collect();
        assert_eq!(group.len(), 2);
    }

    #[test]
    fn floor_six_boss_opens_path_choice() {
        let mut g = Game::new(0, [0; 3], 1, 5);
        g.floor = 6;
        g.gen_floor();
        let bi = g.mons.iter().position(|m| m.boss).unwrap();
        g.hurt_mon(bi, 1e6, false);
        assert!(g.choose);
        assert!(g.mid_win);
        g.choose_path(Path::Heaven);
        assert!(!g.choose);
        g.floor = 7;
        g.gen_floor();
        let boss = g.mons.iter().find(|m| m.boss).unwrap();
        assert!(boss.bk >= 11 && boss.bk <= 13);
    }

    #[test]
    fn final_boss_ends_run_with_win() {
        let mut g = Game::new(0, [0; 3], 1, 9);
        g.path = Some(Path::Hell);
        g.floor = 9;
        g.gen_floor();
        let bi = g.mons.iter().position(|m| m.boss).unwrap();
        g.hurt_mon(bi, 1e6, false);
        assert!(g.fin);
        for _ in 0..200 {
            g.update(0.016, &Input::default());
        }
        assert!(g.over && g.win);
    }

    #[test]
    fn profile_roundtrip_and_unlocks() {
        let mut p = Profile::default();
        assert!(p.unlocked(0) && p.unlocked(11));
        assert!(!p.unlocked(1) && !p.unlocked(6));
        p.apply_run(&RunResult { win: false, floor: 4, gold: 120, kills: 45, mid_win: false, pal_unlock: false, guard_unlock: false });
        assert!(p.unlocked(1) && p.unlocked(2) && p.pal && p.unlocked(8));
        assert_eq!(p.coins, 120);
        p.quiz[6] = true;
        p.up = [1, 2, 0];
        let q = Profile::from_text(&p.to_text());
        assert_eq!(p, q);
        assert!(q.unlocked(6));
    }

    // ---------- онлайн-кооператив ----------

    fn bot_input(t: f32) -> Input {
        Input { ix: (t * 0.7).cos(), iy: (t * 1.1).sin(), ax: (t * 2.3).cos(), ay: (t * 1.7).sin() }
    }

    #[test]
    fn coop_bot_run_keeps_both_players_finite_and_unswapped() {
        use crate::game::RemoteCtl;
        for seed in 1..=3u32 {
            let mut g = Game::new(0, [0; 3], 1, seed);
            g.add_player2(10, [0; 3]);
            g.p.st.mhp = 40.0;
            g.p.st.hp = 40.0;
            if let Some(q) = g.p2.as_mut() {
                q.st.mhp = 40.0;
                q.st.hp = 40.0;
            }
            let mut t = 0.0f32;
            for step in 0..4000 {
                t += 0.016;
                let inp = bot_input(t);
                let rc = RemoteCtl { inp: bot_input(t + 1.3), act: step % 500 == 7, bomb: step % 700 == 9, ..Default::default() };
                g.update_with(0.016, &inp, Some(&rc));
                if g.choose {
                    g.choose_path(Path::Hell);
                }
                let q = g.p2.as_ref().unwrap();
                assert!(g.p.x.is_finite() && g.p.y.is_finite() && q.x.is_finite() && q.y.is_finite(), "seed {} step {}", seed, step);
                assert!(!g.swapped);
                if g.over {
                    break;
                }
            }
        }
    }

    #[test]
    fn game_continues_until_both_players_die() {
        let mut g = Game::new(0, [0; 3], 1, 4);
        g.add_player2(0, [0; 3]);
        g.p.st.shield = 0.0;
        g.hurt_player(100.0);
        assert!(g.p.dead);
        assert!(!g.over);
        g.swap_players();
        g.p.st.shield = 0.0;
        g.hurt_player(100.0);
        g.swap_players();
        assert!(g.over);
        assert!(!g.swapped);
    }

    #[test]
    fn next_floor_revives_the_fallen_partner() {
        let mut g = Game::new(0, [0; 3], 1, 6);
        g.add_player2(1, [0; 3]);
        g.swap_players();
        g.p.st.shield = 0.0;
        g.hurt_player(100.0);
        g.swap_players();
        assert!(g.p2.as_ref().unwrap().dead);
        assert!(!g.over);
        g.floor = 2;
        g.gen_floor();
        let q = g.p2.as_ref().unwrap();
        assert!(!q.dead);
        assert_eq!(q.st.hp, 1.0);
    }

    #[test]
    fn wire_hello_and_ctl_roundtrip() {
        use crate::wire;
        let h = wire::encode_hello(10, [1, 2, 0]);
        assert_eq!(wire::decode_hello(&h), Some((10, [1, 2, 0])));
        assert!(wire::decode_hello(&[0, 1, 2]).is_none());
        let c = wire::Ctl { ix: 1.0, iy: -1.0, ax: 0.5, ay: 0.0, x: 3.5, y: 7.25, vx: 0.5, vy: -0.5, epoch: 9, act_n: 3, bomb_n: 250 };
        assert_eq!(wire::Ctl::decode(&c.encode()), Some(c));
        assert!(wire::Ctl::decode(&[1, 2, 3]).is_none());
    }

    #[test]
    fn wire_snapshot_roundtrip_keeps_what_the_screen_needs() {
        use crate::game::RemoteCtl;
        use crate::wire;
        let mut host = Game::new(0, [0; 3], 1, 11);
        host.add_player2(10, [0; 3]);
        host.rec_parts = true;
        let mut t = 0.0f32;
        for step in 0..400 {
            t += 0.016;
            let rc = RemoteCtl { inp: bot_input(t + 0.5), ..Default::default() };
            host.update_with(0.016, &bot_input(t), Some(&rc));
            if step % 100 == 0 {
                host.use_act();
            }
        }
        let mut client = wire::client_game(10, [0; 3], 1, 0);
        client.net_apply_floor(&host.net_floor()).unwrap();
        assert_eq!(client.rooms.len(), host.rooms.len());
        assert_eq!(client.floor, host.floor);
        client.net_apply_state(&host.net_state(1)).unwrap();
        assert_eq!(client.cur, host.cur);
        // у клиента «свой» герой — это второй игрок хоста
        assert_eq!(client.p.ch, 10);
        assert_eq!(client.p2.as_ref().unwrap().ch, 0);
        let on_screen = host.mons.iter().filter(|m| !m.dead && host.in_cur_cell(m.x, m.y)).count();
        assert_eq!(client.mons.len(), on_screen);
        let hq = host.p2.as_ref().unwrap();
        assert!((client.p.st.hp - hq.st.hp).abs() < 1e-5);
        assert_eq!(client.p.items, hq.items);
        let (gx, gy) = (host.room().gx, host.room().gy);
        for j in 0..crate::dungeon::CH {
            for i in 0..crate::dungeon::CW {
                assert_eq!(client.tile(gx * crate::dungeon::CW + i, gy * crate::dungeon::CH + j), host.tile(gx * crate::dungeon::CW + i, gy * crate::dungeon::CH + j));
            }
        }
        for (a, b) in client.mons.iter().zip(host.mons.iter().filter(|m| !m.dead && host.in_cur_cell(m.x, m.y))) {
            assert_eq!(a.id, b.id);
            assert!((a.x - b.x).abs() < 0.02 && (a.y - b.y).abs() < 0.02);
        }
    }

    #[test]
    fn wire_rejects_garbage_and_truncated_snapshots() {
        use crate::wire;
        let mut host = Game::new(0, [0; 3], 1, 21);
        host.add_player2(4, [0; 3]);
        let mut client = wire::client_game(4, [0; 3], 1, 0);
        client.net_apply_floor(&host.net_floor()).unwrap();
        assert!(client.net_apply_state(&[1, 2, 3]).is_none());
        let s = host.net_state(1);
        for cut in [0usize, 5, 50, s.len() / 2, s.len() - 1].iter() {
            assert!(client.net_apply_state(&s[..*cut]).is_none(), "cut {}", cut);
        }
        let f = host.net_floor();
        let mut other = wire::client_game(4, [0; 3], 1, 0);
        for cut in [0usize, 3, f.len() / 2, f.len() - 1].iter() {
            assert!(other.net_apply_floor(&f[..*cut]).is_none(), "cut {}", cut);
        }
        // после всех отказов состояние клиента целое
        assert!(client.net_apply_state(&s).is_some());
    }

    #[test]
    fn boomerang_returns_to_its_owner_and_counts_per_player() {
        let mut g = Game::new(10, [0; 3], 1, 8);
        g.add_player2(10, [0; 3]);
        g.p.fx = 1.0;
        g.p.fy = 0.0;
        g.shoot();
        g.swap_players();
        g.p.fx = -1.0;
        g.p.fy = 0.0;
        g.shoot();
        g.swap_players();
        let mine = g.bul.iter().filter(|b| b.bm && b.own == 0).count();
        let theirs = g.bul.iter().filter(|b| b.bm && b.own == 1).count();
        assert_eq!((mine, theirs), (1, 1));
        // второй бросок того же игрока при одном бумеранге в воздухе ничего не добавляет
        g.shoot();
        assert_eq!(g.bul.iter().filter(|b| b.bm && b.own == 0).count(), 1);
    }

    #[test]
    fn forge_costs_grow() {
        let mut p = Profile::default();
        p.coins = 100;
        assert!(p.buy_upgrade(0));
        assert_eq!(p.coins, 80);
        assert!(p.buy_upgrade(0));
        assert_eq!(p.coins, 40);
        assert!(!p.buy_upgrade(0));
    }
}
