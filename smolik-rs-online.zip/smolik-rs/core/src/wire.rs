//! Онлайн-кооператив на двоих: двоичный формат сообщений и снимки игры. Без внешних крейтов.
//!
//! Схема: хост считает всю игру (оба героя, враги, пули), клиент присылает свой ввод и позицию,
//! а получает снимки состояния. Клиент сам двигает своего героя (нет задержки управления)
//! и рисует мир из снимков теми же функциями, что и одиночная игра.
//!
//! Кадр в сети: `u32` длина (LE), затем `u8` тип сообщения и тело. Все разборы возвращают `Option`,
//! так что битое или злонамеренное сообщение не роняет игру.
use crate::data::{BOSSES, CHARACTERS, ITEMS, ROOMS};
use crate::defs::*;
use crate::dungeon::{Door, Room, CH, CW, GN, MAP_COLS, MAP_ROWS};
use crate::game::*;
use crate::profile::UPGRADE_MAX;
use crate::stats::Stats;

pub const MAGIC: [u8; 4] = *b"SMOL";
pub const VERSION: u8 = 1;

pub const MSG_HELLO: u8 = 1;
pub const MSG_WELCOME: u8 = 2;
pub const MSG_FLOOR: u8 = 3;
pub const MSG_STATE: u8 = 4;
pub const MSG_CTL: u8 = 5;
pub const MSG_BYE: u8 = 6;

/// Сколько секунд между снимками, которые хост шлёт клиенту.
pub const SNAP_DT: f32 = 1.0 / 30.0;

const TAU: f32 = 6.2831855;

// ---------------------------------------------------------------- запись и чтение

pub struct W {
    pub b: Vec<u8>,
}

impl W {
    pub fn new() -> W {
        W { b: Vec::with_capacity(1024) }
    }
    pub fn u8(&mut self, v: u8) {
        self.b.push(v);
    }
    pub fn u16(&mut self, v: u16) {
        self.b.extend_from_slice(&v.to_le_bytes());
    }
    pub fn i16(&mut self, v: i16) {
        self.b.extend_from_slice(&v.to_le_bytes());
    }
    pub fn u32(&mut self, v: u32) {
        self.b.extend_from_slice(&v.to_le_bytes());
    }
    pub fn i32(&mut self, v: i32) {
        self.b.extend_from_slice(&v.to_le_bytes());
    }
    pub fn f32(&mut self, v: f32) {
        self.b.extend_from_slice(&v.to_le_bytes());
    }
    pub fn bool(&mut self, v: bool) {
        self.b.push(if v { 1 } else { 0 });
    }
    /// Короткая строка: длина (1 байт) и UTF-8.
    pub fn text(&mut self, s: &str) {
        let bytes = s.as_bytes();
        let n = bytes.len().min(240);
        self.u8(n as u8);
        self.b.extend_from_slice(&bytes[..n]);
    }
    /// Координата в тайлах (0…655), точность 0,01.
    pub fn pos(&mut self, v: f32) {
        self.u16((v.max(0.0).min(655.0) * 100.0).round() as u16);
    }
    /// Число со знаком (±327), точность 0,01.
    pub fn q100(&mut self, v: f32) {
        self.i16((v.max(-327.0).min(327.0) * 100.0).round() as i16);
    }
    /// Угол 0…2π в 16 битах.
    pub fn ang(&mut self, a: f32) {
        let v = a.rem_euclid(TAU);
        self.u16((v * 10000.0).min(65000.0) as u16);
    }
    /// Малое число со знаком в один байт: ±12,7, точность 0,1.
    pub fn q10_i8(&mut self, v: f32) {
        let x = (v * 10.0).round().max(-127.0).min(127.0) as i8;
        self.u8(x as u8);
    }
    /// Единичная составляющая направления: ±1, точность 0,01.
    pub fn dir(&mut self, v: f32) {
        let x = (v * 100.0).round().max(-100.0).min(100.0) as i8;
        self.u8(x as u8);
    }
}

pub struct R<'a> {
    b: &'a [u8],
    i: usize,
}

impl<'a> R<'a> {
    pub fn new(b: &'a [u8]) -> R<'a> {
        R { b, i: 0 }
    }
    fn take(&mut self, n: usize) -> Option<&'a [u8]> {
        if self.i + n > self.b.len() {
            return None;
        }
        let s = &self.b[self.i..self.i + n];
        self.i += n;
        Some(s)
    }
    pub fn u8(&mut self) -> Option<u8> {
        let s = self.take(1)?;
        Some(s[0])
    }
    pub fn u16(&mut self) -> Option<u16> {
        let s = self.take(2)?;
        Some(u16::from_le_bytes([s[0], s[1]]))
    }
    pub fn i16(&mut self) -> Option<i16> {
        let s = self.take(2)?;
        Some(i16::from_le_bytes([s[0], s[1]]))
    }
    pub fn u32(&mut self) -> Option<u32> {
        let s = self.take(4)?;
        Some(u32::from_le_bytes([s[0], s[1], s[2], s[3]]))
    }
    pub fn i32(&mut self) -> Option<i32> {
        let s = self.take(4)?;
        Some(i32::from_le_bytes([s[0], s[1], s[2], s[3]]))
    }
    /// Дробное число; NaN и бесконечности заменяются нулём.
    pub fn f32(&mut self) -> Option<f32> {
        let s = self.take(4)?;
        let v = f32::from_le_bytes([s[0], s[1], s[2], s[3]]);
        Some(if v.is_finite() { v } else { 0.0 })
    }
    pub fn bool(&mut self) -> Option<bool> {
        Some(self.u8()? != 0)
    }
    pub fn text(&mut self) -> Option<String> {
        let n = self.u8()? as usize;
        let s = self.take(n)?;
        Some(String::from_utf8_lossy(s).to_string())
    }
    pub fn pos(&mut self) -> Option<f32> {
        Some(self.u16()? as f32 / 100.0)
    }
    pub fn q100(&mut self) -> Option<f32> {
        Some(self.i16()? as f32 / 100.0)
    }
    pub fn ang(&mut self) -> Option<f32> {
        Some(self.u16()? as f32 / 10000.0)
    }
    pub fn q10_i8(&mut self) -> Option<f32> {
        Some(self.u8()? as i8 as f32 / 10.0)
    }
    pub fn dir(&mut self) -> Option<f32> {
        Some(self.u8()? as i8 as f32 / 100.0)
    }
}

fn bit(b: bool, n: u8) -> u8 {
    if b {
        1 << n
    } else {
        0
    }
}

// ---------------------------------------------------------------- перечисления <-> байты

const MON_KINDS: [MonKind; 15] = [
    MonKind::Slime,
    MonKind::Bat,
    MonKind::Gun,
    MonKind::Charge,
    MonKind::Imp,
    MonKind::Hound,
    MonKind::Wisp,
    MonKind::Angel,
    MonKind::Cherub,
    MonKind::Guardian,
    MonKind::Shroom,
    MonKind::Spider,
    MonKind::Bomber,
    MonKind::Turret,
    MonKind::Boss,
];

const ACT_IDS: [ActId; 15] = [
    ActId::Zap,
    ActId::Dof,
    ActId::Pact,
    ActId::Seal,
    ActId::Reap,
    ActId::Bomb,
    ActId::Sand,
    ActId::Flask,
    ActId::Drag,
    ActId::Fog,
    ActId::Aura,
    ActId::Whirl,
    ActId::Kama,
    ActId::Rage,
    ActId::Storm,
];

const SKINS: [Skin; 10] = [
    Skin::Normal,
    Skin::Weak,
    Skin::LetterN,
    Skin::Tape,
    Skin::Astral,
    Skin::Bottle,
    Skin::Shard,
    Skin::Boomerang,
    Skin::Terra,
    Skin::Rainbow,
];

const PICK_KINDS: [PickKind; 8] = [
    PickKind::Coin,
    PickKind::Key,
    PickKind::Bomb,
    PickKind::Heart,
    PickKind::HalfHeart,
    PickKind::DoubleHeart,
    PickKind::Chest,
    PickKind::Item,
];

fn idx_of<T: PartialEq + Copy>(arr: &[T], v: T) -> u8 {
    match arr.iter().position(|x| *x == v) {
        Some(i) => i as u8,
        None => 0,
    }
}

fn pick_of<T: Copy>(arr: &[T], i: u8) -> T {
    let k = (i as usize).min(arr.len() - 1);
    arr[k]
}

fn stats_arr(s: &Stats) -> [f32; 24] {
    [
        s.dmg, s.rate, s.spd, s.hp, s.mhp, s.multi, s.pierce, s.bounce, s.home, s.vamp, s.shield, s.range, s.big, s.burn, s.keys, s.bsp, s.gold, s.luck,
        s.poison, s.dark, s.terra, s.prism, s.msz, s.act,
    ]
}

fn stats_from(a: &[f32; 24]) -> Stats {
    Stats {
        dmg: a[0],
        rate: a[1],
        spd: a[2],
        hp: a[3],
        mhp: a[4],
        multi: a[5],
        pierce: a[6],
        bounce: a[7],
        home: a[8],
        vamp: a[9],
        shield: a[10],
        range: a[11],
        big: a[12],
        burn: a[13],
        keys: a[14],
        bsp: a[15],
        gold: a[16],
        luck: a[17],
        poison: a[18],
        dark: a[19],
        terra: a[20],
        prism: a[21],
        msz: a[22],
        act: a[23],
    }
}

// ---------------------------------------------------------------- рукопожатие и управление

/// Первое сообщение клиента: кем играет и какие улучшения кузницы у него есть.
pub fn encode_hello(hero: usize, up: [i32; 3]) -> Vec<u8> {
    let mut w = W::new();
    w.b.extend_from_slice(&MAGIC);
    w.u8(VERSION);
    w.u8(hero.min(255) as u8);
    for v in up.iter() {
        w.u8((*v).max(0).min(255) as u8);
    }
    w.b
}

pub fn decode_hello(data: &[u8]) -> Option<(usize, [i32; 3])> {
    let mut r = R::new(data);
    for m in MAGIC.iter() {
        if r.u8()? != *m {
            return None;
        }
    }
    if r.u8()? != VERSION {
        return None;
    }
    let hero = (r.u8()? as usize).min(CHARACTERS.len() - 1);
    let mut up = [0i32; 3];
    for v in up.iter_mut() {
        *v = (r.u8()? as i32).min(UPGRADE_MAX);
    }
    Some((hero, up))
}

/// Ответ хоста: версия совпала, сложность и герой хоста.
pub fn encode_welcome(diff: usize, host_hero: usize) -> Vec<u8> {
    let mut w = W::new();
    w.u8(VERSION);
    w.u8(diff.min(2) as u8);
    w.u8(host_hero.min(255) as u8);
    w.b
}

pub fn decode_welcome(data: &[u8]) -> Option<(usize, usize)> {
    let mut r = R::new(data);
    if r.u8()? != VERSION {
        return None;
    }
    let diff = (r.u8()? as usize).min(2);
    let hero = (r.u8()? as usize).min(CHARACTERS.len() - 1);
    Some((diff, hero))
}

/// Что клиент шлёт хосту примерно 30 раз в секунду.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Ctl {
    pub ix: f32,
    pub iy: f32,
    pub ax: f32,
    pub ay: f32,
    /// Где клиент видит своего героя (движение считается у клиента).
    pub x: f32,
    pub y: f32,
    pub vx: f32,
    pub vy: f32,
    /// Последний `epoch`, который клиент получил от хоста.
    pub epoch: u8,
    /// Счётчики нажатий: хост сравнивает с прошлым значением, поэтому нажатие не потеряется.
    pub act_n: u8,
    pub bomb_n: u8,
}

impl Ctl {
    pub fn encode(&self) -> Vec<u8> {
        let mut w = W::new();
        for v in [self.ix, self.iy, self.ax, self.ay, self.x, self.y, self.vx, self.vy].iter() {
            w.f32(*v);
        }
        w.u8(self.epoch);
        w.u8(self.act_n);
        w.u8(self.bomb_n);
        w.b
    }

    pub fn decode(data: &[u8]) -> Option<Ctl> {
        let mut r = R::new(data);
        let ix = r.f32()?;
        let iy = r.f32()?;
        let ax = r.f32()?;
        let ay = r.f32()?;
        let x = r.f32()?;
        let y = r.f32()?;
        let vx = r.f32()?;
        let vy = r.f32()?;
        let epoch = r.u8()?;
        let act_n = r.u8()?;
        let bomb_n = r.u8()?;
        Some(Ctl { ix: ix.max(-2.0).min(2.0), iy: iy.max(-2.0).min(2.0), ax: ax.max(-2.0).min(2.0), ay: ay.max(-2.0).min(2.0), x, y, vx, vy, epoch, act_n, bomb_n })
    }
}

// ---------------------------------------------------------------- игрок

struct PPos {
    x: f32,
    y: f32,
    vx: f32,
    vy: f32,
    fx: f32,
    fy: f32,
    anim: f32,
}

fn put_player(w: &mut W, p: &Player) {
    w.f32(p.x);
    w.f32(p.y);
    w.q100(p.vx);
    w.q100(p.vy);
    w.q100(p.fx);
    w.q100(p.fy);
    w.u8(p.ch.min(255) as u8);
    w.bool(p.dead);
    w.f32(p.inv);
    w.f32(p.anim);
    w.u16(p.bombs.max(0).min(9999) as u16);
    w.i32(p.kills);
    for v in stats_arr(&p.st).iter() {
        w.f32(*v);
    }
    let n = p.items.len().min(255);
    w.u8(n as u8);
    for it in p.items.iter().take(n) {
        w.u8((*it).min(255) as u8);
    }
    match p.act {
        Some(a) => {
            w.u8(1);
            w.u8(idx_of(&ACT_IDS, a.id));
            w.f32(a.m);
            w.f32(a.c);
            w.i16(match a.item {
                Some(v) => v.min(30000) as i16,
                None => -1,
            });
        }
        None => w.u8(0),
    }
}

/// Читает игрока в `p`, кроме положения и поворота: их отдаёт вызывающему, чтобы он решил, что принять.
fn get_player(r: &mut R, p: &mut Player) -> Option<PPos> {
    let x = r.f32()?;
    let y = r.f32()?;
    let vx = r.q100()?;
    let vy = r.q100()?;
    let fx = r.q100()?;
    let fy = r.q100()?;
    let ch = (r.u8()? as usize).min(CHARACTERS.len() - 1);
    let dead = r.bool()?;
    let inv = r.f32()?;
    let anim = r.f32()?;
    let bombs = r.u16()? as i32;
    let kills = r.i32()?;
    let mut a = [0.0f32; 24];
    for v in a.iter_mut() {
        *v = r.f32()?;
    }
    let n = r.u8()? as usize;
    let mut items: Vec<usize> = Vec::new();
    for _ in 0..n {
        let it = r.u8()? as usize;
        if it < ITEMS.len() {
            items.push(it);
        }
    }
    let act = if r.u8()? != 0 {
        let id = pick_of(&ACT_IDS, r.u8()?);
        let m = r.f32()?;
        let c = r.f32()?;
        let item = r.i16()?;
        let d = act_def(id);
        Some(Act { id, kind: d.kind, m, c, item: if item >= 0 && (item as usize) < ITEMS.len() { Some(item as usize) } else { None } })
    } else {
        None
    };
    p.ch = ch;
    p.dead = dead;
    p.inv = inv;
    p.bombs = bombs;
    p.kills = kills;
    p.st = stats_from(&a);
    p.items = items;
    p.act = act;
    p.melee = CHARACTERS[ch].melee;
    p.color = if p.st.dark > 0.5 { "#5a2a8a" } else { CHARACTERS[ch].color };
    Some(PPos { x, y, vx, vy, fx, fy, anim })
}

// ---------------------------------------------------------------- враги, снаряды и прочее

fn put_mon(w: &mut W, m: &Monster) {
    w.u32(m.id);
    w.u8(idx_of(&MON_KINDS, m.kind));
    w.pos(m.x);
    w.pos(m.y);
    w.q100(m.vx);
    w.q100(m.vy);
    w.u8((m.r * 100.0).round().max(0.0).min(255.0) as u8);
    w.u16((m.hp.max(0.0) * 10.0).min(65000.0).round() as u16);
    w.u16((m.mhp.max(0.0) * 10.0).min(65000.0).round() as u16);
    let flags = bit(m.fl > 0.0, 0) | bit(m.bt > 0.0, 1) | bit(m.pt > 0.0, 2) | bit(m.wind, 3) | bit(m.boss, 4) | bit(m.aw > 0.0, 5);
    w.u8(flags);
    w.ang(m.a);
    w.dir(m.ux);
    w.dir(m.uy);
    w.u8(m.st.max(0).min(255) as u8);
    w.u8(m.bk.min(255) as u8);
}

fn get_mon(r: &mut R) -> Option<Monster> {
    let id = r.u32()?;
    let kind = pick_of(&MON_KINDS, r.u8()?);
    let mut m = Monster::blank(kind);
    m.id = id;
    let x = r.pos()?;
    let y = r.pos()?;
    m.x = x;
    m.y = y;
    // цель плавного движения у клиента
    m.lx = x;
    m.ly = y;
    m.vx = r.q100()?;
    m.vy = r.q100()?;
    m.r = r.u8()? as f32 / 100.0;
    m.hp = r.u16()? as f32 / 10.0;
    m.mhp = r.u16()? as f32 / 10.0;
    let f = r.u8()?;
    m.fl = if f & 1 != 0 { 0.1 } else { 0.0 };
    m.bt = if f & 2 != 0 { 1.0 } else { 0.0 };
    m.pt = if f & 4 != 0 { 1.0 } else { 0.0 };
    m.wind = f & 8 != 0;
    m.boss = f & 16 != 0;
    m.aw = if f & 32 != 0 { 3.0 } else { 0.0 };
    m.a = r.ang()?;
    m.ux = r.dir()?;
    m.uy = r.dir()?;
    m.st = r.u8()? as i32;
    m.bk = (r.u8()? as usize).min(BOSSES.len() - 1);
    if m.boss {
        m.kind = MonKind::Boss;
        m.beh = Beh::Boss;
        m.color = BOSSES[m.bk].color;
        m.name = BOSSES[m.bk].name;
    }
    Some(m)
}

fn put_bul(w: &mut W, b: &Bullet) {
    w.pos(b.x);
    w.pos(b.y);
    w.q100(b.vx);
    w.q100(b.vy);
    w.u8((b.r * 100.0).round().max(0.0).min(255.0) as u8);
    w.u8(bit(b.pl, 0) | bit(b.bu, 1) | bit(b.po, 2) | bit(b.tb, 3) | bit(b.bm, 4) | bit(b.ph, 5) | bit(b.hm, 6) | bit(b.own == 1, 7));
    w.u8(idx_of(&SKINS, b.skin));
    w.u8(b.rb.max(0).min(255) as u8);
    w.ang(b.rot);
}

fn get_bul(r: &mut R) -> Option<Bullet> {
    let x = r.pos()?;
    let y = r.pos()?;
    let vx = r.q100()?;
    let vy = r.q100()?;
    let rad = r.u8()? as f32 / 100.0;
    let mut b = Bullet::base(x, y, vx, vy, 1.0, rad);
    let f = r.u8()?;
    b.pl = f & 1 != 0;
    b.bu = f & 2 != 0;
    b.po = f & 4 != 0;
    b.tb = f & 8 != 0;
    b.bm = f & 16 != 0;
    b.ph = f & 32 != 0;
    b.hm = f & 64 != 0;
    b.own = if f & 128 != 0 { 1 } else { 0 };
    b.skin = pick_of(&SKINS, r.u8()?);
    b.rb = r.u8()? as i32;
    b.rot = r.ang()?;
    Some(b)
}

fn put_pick(w: &mut W, p: &Pick) {
    w.pos(p.x);
    w.pos(p.y);
    w.u8(idx_of(&PICK_KINDS, p.kind));
    w.i16(p.v.max(-30000).min(30000) as i16);
    w.u8(bit(p.gold, 0) | bit(p.gone, 1));
    w.i16(p.it.max(-1).min(30000) as i16);
    w.i16(p.pr.max(0).min(30000) as i16);
    w.u8(p.pk.max(0).min(255) as u8);
}

fn get_pick(r: &mut R) -> Option<Pick> {
    let x = r.pos()?;
    let y = r.pos()?;
    let kind = pick_of(&PICK_KINDS, r.u8()?);
    let mut p = Pick::new(kind, x, y);
    p.v = r.i16()? as i32;
    let f = r.u8()?;
    p.gold = f & 1 != 0;
    p.gone = f & 2 != 0;
    let it = r.i16()? as i32;
    // предмет, которого нет в таблице, показывать нельзя: рисунок берётся по номеру
    p.it = if it >= ITEMS.len() as i32 { 0 } else { it };
    p.pr = r.i16()? as i32;
    p.pk = r.u8()? as i32;
    Some(p)
}

// ---------------------------------------------------------------- этаж и снимок

impl Game {
    /// Статичная часть этажа: комнаты, шипы, путь. Хост шлёт её один раз при входе на этаж.
    pub fn net_floor(&self) -> Vec<u8> {
        let mut w = W::new();
        w.i16(self.floor.max(0).min(30000) as i16);
        w.u8(match self.path {
            None => 0,
            Some(Path::Hell) => 1,
            Some(Path::Heaven) => 2,
        });
        w.i16(self.boss_door.0 as i16);
        w.i16(self.boss_door.1 as i16);
        w.i16(self.stairs.0 as i16);
        w.i16(self.stairs.1 as i16);
        let n = self.rooms.len().min(255);
        w.u8(n as u8);
        for rm in self.rooms.iter().take(n) {
            w.u8(rm.gx as u8);
            w.u8(rm.gy as u8);
            w.u8(bit(rm.start, 0) | bit(rm.boss, 1) | bit(rm.gold, 2) | bit(rm.shop, 3));
            w.u8(rm.kind.min(255) as u8);
            w.u8(rm.x as u8);
            w.u8(rm.y as u8);
            w.u8(rm.w as u8);
            w.u8(rm.h as u8);
            w.u16(rm.area.max(0).min(65000) as u16);
            w.u8(rm.cx as u8);
            w.u8(rm.cy as u8);
            let nd = rm.doors.len().min(8);
            w.u8(nd as u8);
            for d in rm.doors.iter().take(nd) {
                w.u8(d.x as u8);
                w.u8(d.y as u8);
                w.u8(d.dx as i8 as u8);
                w.u8(d.dy as i8 as u8);
            }
        }
        let ns = self.spk.len().min(60000);
        w.u16(ns as u16);
        for k in self.spk.iter().take(ns) {
            w.u8(k.x as u8);
            w.u8(k.y as u8);
            w.f32(k.o);
        }
        w.b
    }

    /// Клиент: принимает этаж целиком. Карта заливается стенами, нужные клетки придут в снимках.
    pub fn net_apply_floor(&mut self, data: &[u8]) -> Option<()> {
        let mut r = R::new(data);
        let floor = r.i16()? as i32;
        let path = match r.u8()? {
            1 => Some(Path::Hell),
            2 => Some(Path::Heaven),
            _ => None,
        };
        let boss_door = (r.i16()? as i32, r.i16()? as i32);
        let stairs = (r.i16()? as i32, r.i16()? as i32);
        let n = r.u8()? as usize;
        if n == 0 {
            return None;
        }
        let mut rooms: Vec<Room> = Vec::new();
        for _ in 0..n {
            let gx = r.u8()? as i32;
            let gy = r.u8()? as i32;
            if gx >= GN || gy >= GN {
                return None;
            }
            let f = r.u8()?;
            let kind = (r.u8()? as usize).min(ROOMS.len() - 1);
            let x = r.u8()? as i32;
            let y = r.u8()? as i32;
            let w = r.u8()? as i32;
            let h = r.u8()? as i32;
            if w < 3 || h < 3 || x + w > MAP_COLS || y + h > MAP_ROWS {
                return None;
            }
            let area = r.u16()? as i32;
            let cx = r.u8()? as i32;
            let cy = r.u8()? as i32;
            let nd = r.u8()? as usize;
            let mut doors: Vec<Door> = Vec::new();
            for _ in 0..nd {
                let dx0 = r.u8()? as i32;
                let dy0 = r.u8()? as i32;
                let ddx = r.u8()? as i8 as i32;
                let ddy = r.u8()? as i8 as i32;
                doors.push(Door { x: dx0, y: dy0, dx: ddx, dy: ddy });
            }
            rooms.push(Room {
                gx,
                gy,
                parent: None,
                depth: 0,
                start: f & 1 != 0,
                boss: f & 2 != 0,
                gold: f & 4 != 0,
                shop: f & 8 != 0,
                kind,
                x,
                y,
                w,
                h,
                area,
                cx,
                cy,
                doors,
            });
        }
        let ns = r.u16()? as usize;
        let mut spk: Vec<Spike> = Vec::new();
        for _ in 0..ns {
            let x = r.u8()? as i32;
            let y = r.u8()? as i32;
            let o = r.f32()?;
            spk.push(Spike { x, y, o, mh: false });
        }
        self.floor = floor;
        self.path = path;
        self.boss_door = boss_door;
        self.stairs = stairs;
        self.rs = vec![RoomState::default(); rooms.len()];
        self.rooms = rooms;
        self.cur = 0;
        self.spk = spk;
        self.map = vec![vec![1u8; MAP_COLS as usize]; MAP_ROWS as usize];
        self.brk.clear();
        self.bar.clear();
        self.mons.clear();
        self.pick.clear();
        self.bul.clear();
        self.bombs.clear();
        self.gas.clear();
        self.rings.clear();
        self.parts.clear();
        self.net_seq = 0;
        Some(())
    }

    /// Хост: снимок динамического состояния для клиента. Первым идёт игрок-клиент, вторым — сам хост.
    pub fn net_state(&mut self, seq: u32) -> Vec<u8> {
        let mut w = W::new();
        w.u32(seq);
        w.i16(self.floor.max(0).min(30000) as i16);
        w.u8(match self.path {
            None => 0,
            Some(Path::Hell) => 1,
            Some(Path::Heaven) => 2,
        });
        w.u8(self.cur.min(255) as u8);
        w.u8(bit(self.over, 0) | bit(self.win, 1) | bit(self.choose, 2) | bit(self.fin, 3) | bit(self.boss_on, 4) | bit(self.mid_win, 5) | bit(self.pal_unlock, 6) | bit(self.won, 7));
        w.f32(self.t);
        w.f32(self.freeze.max(0.0));
        w.f32(self.intro.max(0.0));
        w.f32(self.shake.max(0.0));
        w.f32(self.flash.max(0.0));
        w.u8(self.epoch);
        match self.toast.as_ref() {
            Some((s, l)) => {
                w.u8(1);
                w.text(s);
                w.f32(*l);
            }
            None => w.u8(0),
        }
        match self.ban.as_ref() {
            Some(b) => {
                w.u8(1);
                w.text(&b.title);
                w.text(&b.desc);
                w.u8(b.rarity);
                w.f32(b.l);
            }
            None => w.u8(0),
        }
        let q = match self.p2.as_ref() {
            Some(q) => q.clone(),
            None => self.p.clone(),
        };
        put_player(&mut w, &q);
        put_player(&mut w, &self.p);

        // тайлы текущей комнаты
        let (gx, gy) = (self.rooms[self.cur].gx, self.rooms[self.cur].gy);
        for j in 0..CH {
            for i in 0..CW {
                w.u8(self.tile(gx * CW + i, gy * CH + j));
            }
        }
        // состояния комнат для миникарты
        w.u8(self.rs.len().min(255) as u8);
        for s in self.rs.iter().take(255) {
            w.u8(bit(s.vis, 0) | bit(s.cl, 1) | bit(s.lk, 2));
        }
        // камни, которые можно взорвать, и бочки в текущей комнате
        let mut keys: Vec<u16> = Vec::new();
        for &k in self.brk.iter() {
            let (x, y) = (k % MAP_COLS, k / MAP_COLS);
            if x / CW == gx && y / CH == gy && keys.len() < 200 {
                keys.push(k.max(0).min(65000) as u16);
            }
        }
        w.u16(keys.len() as u16);
        for k in keys.iter() {
            w.u16(*k);
        }
        let mut bars: Vec<(u8, u8, u8)> = Vec::new();
        for o in self.bar.values() {
            if o.x / CW == gx && o.y / CH == gy && bars.len() < 60 {
                bars.push((o.x as u8, o.y as u8, o.hp.max(0.0).min(255.0) as u8));
            }
        }
        w.u8(bars.len() as u8);
        for b in bars.iter() {
            w.u8(b.0);
            w.u8(b.1);
            w.u8(b.2);
        }

        let mut mons: Vec<&Monster> = Vec::new();
        for m in self.mons.iter() {
            if !m.dead && self.in_cur_cell(m.x, m.y) && mons.len() < 90 {
                mons.push(m);
            }
        }
        w.u16(mons.len() as u16);
        for m in mons.iter() {
            put_mon(&mut w, m);
        }
        let mut picks: Vec<&Pick> = Vec::new();
        for p in self.pick.iter() {
            if !p.gone && self.in_cur_cell(p.x, p.y) && picks.len() < 60 {
                picks.push(p);
            }
        }
        w.u16(picks.len() as u16);
        for p in picks.iter() {
            put_pick(&mut w, p);
        }
        let mut buls: Vec<&Bullet> = Vec::new();
        for b in self.bul.iter() {
            if self.in_cur_cell(b.x, b.y) && buls.len() < 260 {
                buls.push(b);
            }
        }
        w.u16(buls.len() as u16);
        for b in buls.iter() {
            put_bul(&mut w, b);
        }
        let nb = self.bombs.len().min(40);
        w.u8(nb as u8);
        for b in self.bombs.iter().take(nb) {
            w.pos(b.x);
            w.pos(b.y);
            w.u8((b.l * 100.0).round().max(0.0).min(255.0) as u8);
            w.bool(b.hostile);
        }
        let ng = self.gas.len().min(40);
        w.u8(ng as u8);
        for g in self.gas.iter().take(ng) {
            w.pos(g.x);
            w.pos(g.y);
        }
        let nr = self.rings.len().min(20);
        w.u8(nr as u8);
        for g in self.rings.iter().take(nr) {
            w.pos(g.x);
            w.pos(g.y);
            w.u16((g.r.max(0.0) * 100.0).min(65000.0).round() as u16);
            w.ang(g.g);
            w.u8((g.gw * 100.0).round().max(0.0).min(255.0) as u8);
            w.u8((g.t.max(0.0) * 50.0).round().min(255.0) as u8);
        }
        let parts = std::mem::take(&mut self.new_parts);
        let np = parts.len().min(160);
        w.u16(np as u16);
        for q in parts.iter().take(np) {
            w.pos(q.x);
            w.pos(q.y);
            w.q10_i8(q.vx);
            w.q10_i8(q.vy);
            w.u8((q.l * 100.0).round().max(0.0).min(255.0) as u8);
            w.u8(q.col.0);
            w.u8(q.col.1);
            w.u8(q.col.2);
        }
        w.b
    }

    /// Клиент: принимает снимок. Либо применяется целиком, либо ничего не меняется (`None`).
    pub fn net_apply_state(&mut self, data: &[u8]) -> Option<()> {
        let mut r = R::new(data);
        let seq = r.u32()?;
        let floor = r.i16()? as i32;
        if floor != self.floor {
            // этаж ещё не принят: ждём сообщение с этажом
            return None;
        }
        let path = match r.u8()? {
            1 => Some(Path::Hell),
            2 => Some(Path::Heaven),
            _ => None,
        };
        let cur = r.u8()? as usize;
        if cur >= self.rooms.len() {
            return None;
        }
        let fl = r.u8()?;
        let t = r.f32()?;
        let freeze = r.f32()?;
        let intro = r.f32()?;
        let shake = r.f32()?;
        let flash = r.f32()?;
        let epoch = r.u8()?;
        let toast = if r.u8()? != 0 {
            let s = r.text()?;
            let l = r.f32()?;
            Some((s, l))
        } else {
            None
        };
        let ban = if r.u8()? != 0 {
            let title = r.text()?;
            let desc = r.text()?;
            let rarity = r.u8()?;
            let l = r.f32()?;
            Some(Banner { title, desc, rarity, l })
        } else {
            None
        };

        let first = self.net_seq == 0;
        let moved = first || epoch != self.epoch;

        let mut me = self.p.clone();
        let was_dead = me.dead;
        let sp = get_player(&mut r, &mut me)?;
        let off = hyp(sp.x - me.x, sp.y - me.y);
        if moved || me.dead != was_dead || me.dead || off > 2.5 {
            me.x = sp.x;
            me.y = sp.y;
            me.vx = sp.vx;
            me.vy = sp.vy;
        }

        let mut him = match self.p2.as_ref() {
            Some(q) => q.clone(),
            None => make_player(0, [0; 3], self.diff),
        };
        let sh = get_player(&mut r, &mut him)?;
        him.vx = sh.vx;
        him.vy = sh.vy;
        him.fx = sh.fx;
        him.fy = sh.fy;
        if moved || hyp(sh.x - him.x, sh.y - him.y) > 3.0 {
            him.x = sh.x;
            him.y = sh.y;
            him.anim = sh.anim;
        }
        let goal = (sh.x, sh.y);

        let mut tiles = [0u8; (CW * CH) as usize];
        for v in tiles.iter_mut() {
            *v = r.u8()?;
        }
        let nrs = r.u8()? as usize;
        if nrs != self.rooms.len() {
            return None;
        }
        let mut rs: Vec<RoomState> = Vec::new();
        for _ in 0..nrs {
            let b = r.u8()?;
            rs.push(RoomState { vis: b & 1 != 0, cl: b & 2 != 0, lk: b & 4 != 0, rg: Vec::new() });
        }
        let nk = r.u16()? as usize;
        let mut keys: Vec<i32> = Vec::new();
        for _ in 0..nk {
            keys.push(r.u16()? as i32);
        }
        let nbar = r.u8()? as usize;
        let mut bars: Vec<Barrel> = Vec::new();
        for _ in 0..nbar {
            let x = r.u8()? as i32;
            let y = r.u8()? as i32;
            let hp = r.u8()? as f32;
            bars.push(Barrel { x, y, hp });
        }
        let nm = r.u16()? as usize;
        let mut mons: Vec<Monster> = Vec::new();
        for _ in 0..nm {
            mons.push(get_mon(&mut r)?);
        }
        let np = r.u16()? as usize;
        let mut picks: Vec<Pick> = Vec::new();
        for _ in 0..np {
            picks.push(get_pick(&mut r)?);
        }
        let nbu = r.u16()? as usize;
        let mut buls: Vec<Bullet> = Vec::new();
        for _ in 0..nbu {
            buls.push(get_bul(&mut r)?);
        }
        let nbo = r.u8()? as usize;
        let mut bombs: Vec<Bomb> = Vec::new();
        for _ in 0..nbo {
            let x = r.pos()?;
            let y = r.pos()?;
            let l = r.u8()? as f32 / 100.0;
            let hostile = r.bool()?;
            bombs.push(Bomb { x, y, l, vx: 0.0, vy: 0.0, hostile });
        }
        let ngs = r.u8()? as usize;
        let mut gas: Vec<Gas> = Vec::new();
        for _ in 0..ngs {
            let x = r.pos()?;
            let y = r.pos()?;
            gas.push(Gas { x, y, l: 1.0 });
        }
        let nri = r.u8()? as usize;
        let mut rings: Vec<RingAtk> = Vec::new();
        for _ in 0..nri {
            let x = r.pos()?;
            let y = r.pos()?;
            let rr = r.u16()? as f32 / 100.0;
            let g = r.ang()?;
            let gw = r.u8()? as f32 / 100.0;
            let tt = r.u8()? as f32 / 50.0;
            rings.push(RingAtk { x, y, r: rr, sp: 0.0, g, gw, t: tt, eid: 0 });
        }
        let npt = r.u16()? as usize;
        let mut newp: Vec<Part> = Vec::new();
        for _ in 0..npt {
            let x = r.pos()?;
            let y = r.pos()?;
            let vx = r.q10_i8()?;
            let vy = r.q10_i8()?;
            let l = r.u8()? as f32 / 100.0;
            let c0 = r.u8()?;
            let c1 = r.u8()?;
            let c2 = r.u8()?;
            newp.push(Part { x, y, vx, vy, l, col: (c0, c1, c2) });
        }

        // разобрано без ошибок: применяем
        let (gx, gy) = (self.rooms[cur].gx, self.rooms[cur].gy);
        self.net_seq = seq.max(1);
        self.path = path;
        self.cur = cur;
        self.over = fl & 1 != 0;
        self.win = fl & 2 != 0;
        self.choose = fl & 4 != 0;
        self.fin = fl & 8 != 0;
        self.boss_on = fl & 16 != 0;
        self.mid_win = fl & 32 != 0;
        self.pal_unlock = fl & 64 != 0;
        self.won = fl & 128 != 0;
        self.t = t;
        self.freeze = freeze;
        self.intro = intro;
        self.shake = shake;
        self.flash = flash;
        self.epoch = epoch;
        self.toast = toast;
        self.ban = ban;
        self.p = me;
        self.p2 = Some(him);
        self.goal2 = goal;
        for j in 0..CH {
            for i in 0..CW {
                self.map[(gy * CH + j) as usize][(gx * CW + i) as usize] = tiles[(j * CW + i) as usize];
            }
        }
        self.rs = rs;
        self.brk.retain(|&k| !((k % MAP_COLS) / CW == gx && (k / MAP_COLS) / CH == gy));
        for k in keys {
            self.brk.insert(k);
        }
        self.bar.retain(|_, o| !(o.x / CW == gx && o.y / CH == gy));
        for o in bars {
            self.bar.insert(o.y * MAP_COLS + o.x, o);
        }
        // враги, которые уже были на экране, продолжают плавно ехать из текущей точки
        let mut mons = mons;
        for m in mons.iter_mut() {
            if let Some(old) = self.mons.iter().find(|o| o.id == m.id) {
                if hyp(m.lx - old.x, m.ly - old.y) < 3.0 {
                    m.x = old.x;
                    m.y = old.y;
                }
            }
        }
        self.mons = mons;
        self.pick = picks;
        self.bul = buls;
        self.bombs = bombs;
        self.gas = gas;
        self.rings = rings;
        for q in newp {
            if self.parts.len() < 380 {
                self.parts.push(q);
            }
        }
        Some(())
    }

    /// Клиент: движение собственного героя по тем же правилам, что у хоста (предсказание без задержки).
    fn client_move(&mut self, dt: f32, inp: &Input) {
        let fz = if self.intro > 0.0 { 0.0 } else { 1.0 };
        let mut ix = fz * inp.ix;
        let mut iy = fz * inp.iy;
        let im = hyp(ix, iy);
        if im > 1.0 {
            ix /= im;
            iy /= im;
        }
        let k = (dt * 12.0).min(1.0);
        let spd = self.p.st.spd;
        self.p.vx += (ix * spd - self.p.vx) * k;
        self.p.vy += (iy * spd - self.p.vy) * k;
        let (nx, ny, _) = self.try_move(self.p.x, self.p.y, self.p.r, self.p.vx * dt, self.p.vy * dt, true);
        self.p.x = nx;
        self.p.y = ny;
        let moving = hyp(self.p.vx, self.p.vy) > 0.3;
        self.p.anim += dt * if moving { 10.0 } else { 2.0 };
        let ax = fz * inp.ax;
        let ay = fz * inp.ay;
        let am = hyp(ax, ay);
        if am > 0.25 {
            self.p.fx = ax / am;
            self.p.fy = ay / am;
        } else if im > 0.2 {
            self.p.fx = ix / im;
            self.p.fy = iy / im;
        }
    }

    /// Клиент: шаг между снимками. Двигает своего героя, плавно подтягивает остальное и гасит таймеры.
    pub fn client_step(&mut self, dt: f32, inp: &Input) {
        self.t += dt;
        self.shake -= dt;
        self.flash -= dt;
        if self.intro > 0.0 {
            self.intro -= dt;
        }
        let mut drop_ban = false;
        if let Some(b) = self.ban.as_mut() {
            b.l -= dt;
            drop_ban = b.l <= 0.0;
        }
        if drop_ban {
            self.ban = None;
        }
        let mut drop_toast = false;
        if let Some(t) = self.toast.as_mut() {
            t.1 -= dt;
            drop_toast = t.1 <= 0.0;
        }
        if drop_toast {
            self.toast = None;
        }
        for q in self.parts.iter_mut() {
            q.x += q.vx * dt;
            q.y += q.vy * dt;
            q.l -= dt;
        }
        self.parts.retain(|q| q.l > 0.0);
        if self.p.st.mhp >= 8.0 && !self.guard_unlock {
            self.guard_unlock = true;
        }
        if self.over || self.choose || self.net_seq == 0 {
            return;
        }
        if !self.p.dead {
            self.client_move(dt, inp);
        }
        let k2 = (dt * 14.0).min(1.0);
        let goal = self.goal2;
        if let Some(q) = self.p2.as_mut() {
            q.x += (goal.0 - q.x) * k2;
            q.y += (goal.1 - q.y) * k2;
            let moving = hyp(q.vx, q.vy) > 0.3;
            q.anim += dt * if moving { 10.0 } else { 2.0 };
        }
        let frozen = self.freeze > 0.0;
        let k3 = (dt * 16.0).min(1.0);
        for m in self.mons.iter_mut() {
            if !frozen {
                m.lx += m.vx * dt;
                m.ly += m.vy * dt;
            }
            m.x += (m.lx - m.x) * k3;
            m.y += (m.ly - m.y) * k3;
        }
        for b in self.bul.iter_mut() {
            if frozen && !b.pl {
                continue;
            }
            b.x += b.vx * dt;
            b.y += b.vy * dt;
            if b.bm {
                b.rot += dt * if b.ph { 21.0 } else { 16.0 };
                if b.rot > TAU {
                    b.rot -= TAU;
                }
            }
        }
        for b in self.bombs.iter_mut() {
            b.l -= dt;
        }
    }
}

/// Игра клиента до первого снимка: свой герой и герой хоста.
pub fn client_game(hero: usize, up: [i32; 3], diff: usize, host_hero: usize) -> Game {
    let mut g = Game::new(hero, up, diff, 1);
    g.add_player2(host_hero, [0; 3]);
    g.toast = None;
    g.net_seq = 0;
    g.is_client = true;
    g
}
