//! Таблицы, которых нет в data.rs: типы монстров, сложность, активные предметы, правила выпадения предметов.
//! Всё снято с JS-версии 0.6.9.
use crate::data::ITEMS;

/// Поведение (ИИ) монстра. Разные виды могут вести себя одинаково («like» в JS).
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Beh {
    Slime,
    Bat,
    Gun,
    Charge,
    Boss,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum MonKind {
    Slime,
    Bat,
    Gun,
    Charge,
    Imp,
    Hound,
    Wisp,
    Angel,
    Cherub,
    Guardian,
    Shroom,
    Spider,
    Bomber,
    Turret,
    Boss,
}

pub struct MonDef {
    pub beh: Beh,
    pub hp: f32,
    pub r: f32,
    pub sp: f32,
    pub color: &'static str,
    /// Урон при касании (до множителя сложности).
    pub contact: f32,
    pub name: &'static str,
}

pub fn mon_def(k: MonKind) -> MonDef {
    let (beh, hp, r, sp, color, contact, name) = match k {
        MonKind::Slime => (Beh::Slime, 6.0, 0.36, 1.8, "#6cc46c", 0.5, "Слизень"),
        MonKind::Bat => (Beh::Bat, 3.0, 0.24, 2.8, "#8a5aaa", 0.5, "Летучая мышь"),
        MonKind::Gun => (Beh::Gun, 7.0, 0.3, 1.8, "#e9e2d0", 1.0, "Стрелок"),
        MonKind::Charge => (Beh::Charge, 11.0, 0.4, 1.5, "#c0603a", 1.0, "Бык"),
        MonKind::Imp => (Beh::Gun, 7.0, 0.3, 1.9, "#e0402a", 1.0, "Бес"),
        MonKind::Hound => (Beh::Charge, 12.0, 0.38, 1.7, "#b8501a", 1.0, "Гончая"),
        MonKind::Wisp => (Beh::Bat, 4.0, 0.24, 3.0, "#ff9a2a", 0.5, "Огонёк"),
        MonKind::Angel => (Beh::Gun, 8.0, 0.3, 1.9, "#f4f0d8", 1.0, "Ангел"),
        MonKind::Cherub => (Beh::Bat, 4.0, 0.24, 3.0, "#ffe9c0", 0.5, "Херувим"),
        MonKind::Guardian => (Beh::Charge, 13.0, 0.4, 1.6, "#d8c070", 1.0, "Страж"),
        MonKind::Shroom => (Beh::Gun, 6.0, 0.3, 1.3, "#d05050", 0.5, "Гриб"),
        MonKind::Spider => (Beh::Charge, 8.0, 0.3, 2.1, "#6a2ab0", 1.0, "Паук"),
        MonKind::Bomber => (Beh::Slime, 5.0, 0.32, 1.9, "#555555", 0.5, "Бомбардир"),
        MonKind::Turret => (Beh::Gun, 12.0, 0.4, 0.0, "#8a8a96", 1.0, "Турель"),
        MonKind::Boss => (Beh::Boss, 6.0, 0.36, 1.8, "#6cc46c", 1.0, "Босс"),
    };
    MonDef { beh, hp, r, sp, color, contact, name }
}

/// Обычные монстры земных этажей (порядок важен: чем глубже, тем больше видов).
pub const NORMAL_MOBS: [MonKind; 8] = [
    MonKind::Slime,
    MonKind::Bat,
    MonKind::Gun,
    MonKind::Charge,
    MonKind::Shroom,
    MonKind::Bomber,
    MonKind::Spider,
    MonKind::Turret,
];

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Path {
    Hell,
    Heaven,
}

pub fn path_mobs(p: Path) -> [MonKind; 4] {
    match p {
        Path::Hell => [MonKind::Wisp, MonKind::Imp, MonKind::Hound, MonKind::Charge],
        Path::Heaven => [MonKind::Cherub, MonKind::Angel, MonKind::Guardian, MonKind::Gun],
    }
}

/// Индексы боссов в `BOSSES` для этажей 7, 8, 9 выбранного пути.
pub fn path_bosses(p: Path) -> [usize; 3] {
    match p {
        Path::Hell => [8, 9, 10],
        Path::Heaven => [11, 12, 13],
    }
}

/// Цвета стен и пола. a/b — шахматка пола, w — стена, f — торец стены.
pub struct Theme {
    pub a: &'static str,
    pub b: &'static str,
    pub w: &'static str,
    pub f: &'static str,
}

pub static THEMES: [Theme; 3] = [
    Theme { a: "#2e251c", b: "#2a2219", w: "#4a3f33", f: "#6a5a46" },
    Theme { a: "#1f2a2e", b: "#1b2529", w: "#334a52", f: "#4c6f7c" },
    Theme { a: "#2e1f26", b: "#2a1b22", w: "#52303f", f: "#7a465c" },
];
pub static THEME_HELL: Theme = Theme { a: "#2a0d08", b: "#240a06", w: "#5a1a0a", f: "#b8480f" };
pub static THEME_HEAVEN: Theme = Theme { a: "#cfd6ea", b: "#c3cbe2", w: "#8f9cc4", f: "#e4eafb" };
pub static THEME_BOSS: Theme = Theme { a: "#2a0a0a", b: "#200707", w: "#6a1212", f: "#a02020" };
pub static THEME_BOSS_HEAVEN: Theme = Theme { a: "#3a3410", b: "#332d0c", w: "#8a7a30", f: "#d8c040" };
pub static THEME_SHOP: Theme = Theme { a: "#1d2e22", b: "#18281c", w: "#2c5a3c", f: "#3f8a58" };
pub static THEME_GOLD: Theme = Theme { a: "#3a3010", b: "#332a0c", w: "#7a6420", f: "#b89a30" };

/// Сложность: множитель урона по игроку, HP врагов, шанса выпадения, скорости вражеских пуль.
pub struct Difficulty {
    pub dm: f32,
    pub hp: f32,
    pub dr: f32,
    pub eb: f32,
    pub name: &'static str,
    pub desc: &'static str,
}

pub static DIFFS: [Difficulty; 3] = [
    Difficulty { dm: 1.0, hp: 0.85, dr: 1.3, eb: 1.0, name: "Казуальный", desc: "Больше усилений и лечения, +1 HP и щит, враги бьют базовым уроном." },
    Difficulty { dm: 1.0, hp: 1.0, dr: 0.7, eb: 1.0, name: "Обычный", desc: "Стандартный баланс, усилений стало меньше." },
    Difficulty { dm: 2.0, hp: 1.35, dr: 0.45, eb: 0.8, name: "Хард", desc: "Враги бьют ×2, у них больше HP, усилений мало, но их пули меньше и медленнее." },
];

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum ActKind {
    /// Заряжается со временем.
    Time,
    /// Заряжается нанесённым уроном.
    Dmg,
    /// Заряжается на новом этаже.
    Floor,
    /// Заряжается зачисткой комнаты.
    Room,
    /// Заряжается убийствами.
    Kill,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum ActId {
    Zap,
    Dof,
    Pact,
    Seal,
    Reap,
    Bomb,
    Sand,
    Flask,
    Drag,
    Fog,
    Aura,
    Whirl,
    Kama,
    Rage,
    Storm,
}

pub struct ActDef {
    pub kind: ActKind,
    pub max: f32,
    pub label: &'static str,
}

pub fn act_def(id: ActId) -> ActDef {
    let (kind, max, label) = match id {
        ActId::Zap => (ActKind::Time, 5.0, "Зап"),
        ActId::Dof => (ActKind::Dmg, 60.0, "Взрыв"),
        ActId::Pact => (ActKind::Floor, 1.0, "Договор"),
        ActId::Seal => (ActKind::Room, 3.0, "Свет"),
        ActId::Reap => (ActKind::Kill, 10.0, "Жатва"),
        ActId::Bomb => (ActKind::Time, 8.0, "Бомба"),
        ActId::Sand => (ActKind::Room, 3.0, "Время"),
        ActId::Flask => (ActKind::Room, 4.0, "Фляга"),
        ActId::Drag => (ActKind::Dmg, 40.0, "Огонь"),
        ActId::Fog => (ActKind::Room, 3.0, "Туман"),
        ActId::Aura => (ActKind::Time, 20.0, "Аура"),
        ActId::Whirl => (ActKind::Time, 7.0, "Вихрь"),
        ActId::Kama => (ActKind::Floor, 1.0, "Кама"),
        ActId::Rage => (ActKind::Kill, 8.0, "Ярость"),
        ActId::Storm => (ActKind::Kill, 6.0, "Шторм"),
    };
    ActDef { kind, max, label }
}

/// Какой активный предмет даёт предмет с этим номером в `ITEMS`.
pub fn item_active(i: usize) -> Option<ActId> {
    match i {
        56 => Some(ActId::Zap),
        57 => Some(ActId::Dof),
        58 => Some(ActId::Pact),
        59 => Some(ActId::Reap),
        60 => Some(ActId::Bomb),
        61 => Some(ActId::Sand),
        62 => Some(ActId::Flask),
        63 => Some(ActId::Drag),
        64 => Some(ActId::Fog),
        65 => Some(ActId::Aura),
        66 => Some(ActId::Whirl),
        67 => Some(ActId::Kama),
        68 => Some(ActId::Rage),
        69 => Some(ActId::Storm),
        _ => None,
    }
}

/// С какого этажа предмет может выпадать.
pub fn item_min_floor(i: usize) -> i32 {
    match i {
        7 | 19 => 5,
        4 | 8 | 18 | 20 | 27 | 29 | 31 | 32 | 33 | 39 | 70 | 71 => 3,
        5 | 6 | 11 | 12 | 22 | 24 | 25 | 26 | 38 | 42 | 72 => 2,
        _ => 1,
    }
}

/// Предметы, которые выпадают только на пути Ада (45..=49) или Рая (50..=54).
pub fn item_path(i: usize) -> Option<Path> {
    match i {
        45..=49 => Some(Path::Hell),
        50..=54 => Some(Path::Heaven),
        _ => None,
    }
}

/// Предметы, которые не попадают в случайный пул (Клинок Холодной Скорби — награда паладину).
pub fn item_excluded(i: usize) -> bool {
    i == 59
}

pub const SWORD_ITEM: usize = 59;

/// Вес предмета при розыгрыше: редкие реже, удача сдвигает веса.
pub fn item_weight(rarity: u8, luck: f32) -> f32 {
    let base = [0.0f32, 10.0, 7.0, 4.0, 2.0, 0.8];
    let r = (rarity as usize).min(5);
    if r == 1 {
        base[r] / (1.0 + luck * 0.1)
    } else {
        base[r] * (1.0 + luck * (r as f32 - 1.0) * 0.25)
    }
}

pub fn item_count() -> usize {
    ITEMS.len()
}

/// Разбор «#rrggbb» или «#rgb».
pub fn rgb(h: &str) -> (u8, u8, u8) {
    let s = h.trim_start_matches('#');
    let p = |i: usize, n: usize| u8::from_str_radix(&s[i..i + n], 16).unwrap_or(0);
    if s.len() == 3 {
        (p(0, 1) * 17, p(1, 1) * 17, p(2, 1) * 17)
    } else if s.len() >= 6 {
        (p(0, 2), p(2, 2), p(4, 2))
    } else {
        (255, 0, 255)
    }
}

/// Палитра пиксельных спрайтов предметов.
pub fn pal(c: char) -> Option<(u8, u8, u8)> {
    let h = match c {
        'k' => "#1a1410",
        'w' => "#ffffff",
        'r' => "#d03a2a",
        'b' => "#3a8ae0",
        'c' => "#6fe0ff",
        'g' => "#f0c030",
        'G' => "#4caf50",
        'p' => "#9a6ad8",
        'o' => "#e08a3c",
        'n' => "#8a5a30",
        's' => "#aab4c0",
        'y' => "#f7e060",
        'd' => "#1a1208",
        'm' => "#a02020",
        'h' => "#ff7a9a",
        'e' => "#444444",
        'u' => "#6a2ab0",
        'v' => "#d2a8ff",
        'j' => "#8a5a10",
        'i' => "#d9981f",
        'a' => "#fff0a0",
        'l' => "#fffbe0",
        't' => "#8fe3c0",
        _ => return None,
    };
    Some(rgb(h))
}

/// Цвет редкости: 1 обычный … 5 легендарный.
pub const RARITY_COLORS: [&str; 6] = ["#ffffff", "#bbbbbb", "#7fe08a", "#6fb8ff", "#c080ff", "#ffb030"];
