//! Детерминированный генератор (mulberry32). Тот же алгоритм можно поставить в JS-версию,
//! тогда один сид даст одинаковые этажи в обеих версиях.
pub struct Rng(u32);

impl Rng {
    pub fn new(seed: u32) -> Self {
        Rng(seed)
    }

    pub fn next_u32(&mut self) -> u32 {
        self.0 = self.0.wrapping_add(0x6D2B79F5);
        let mut t = self.0;
        t = (t ^ (t >> 15)).wrapping_mul(t | 1);
        t ^= t.wrapping_add((t ^ (t >> 7)).wrapping_mul(t | 61));
        t ^ (t >> 14)
    }

    /// Число от 0 (включительно) до 1 (не включая), с двойной точностью как в JS.
    pub fn next_f64(&mut self) -> f64 {
        self.next_u32() as f64 / 4294967296.0
    }

    /// Целое от 0 до n-1, то же что `R(n)` в JS-версии.
    pub fn below(&mut self, n: usize) -> usize {
        (self.next_f64() * n as f64) as usize
    }

    /// Число от 0 (включительно) до 1 (не включая).
    pub fn next_f32(&mut self) -> f32 {
        self.next_u32() as f32 / 4294967296.0
    }

    /// Целое от lo до hi включительно.
    pub fn range(&mut self, lo: i32, hi: i32) -> i32 {
        lo + (self.next_f64() * (hi - lo + 1) as f64) as i32
    }
}
