//! Игровые данные. Сгенерировано из работающей JS-версии (персонажи, предметы, боссы, комнаты).
use crate::stats::{Effect, Op, Stat};

pub struct CharacterDef {
    pub name: &'static str,
    pub hp: f32,
    pub damage: f32,
    pub fire_rate: f32,
    pub speed: f32,
    pub color: &'static str,
    pub description: &'static str,
    pub quest: &'static str,
    pub pierce: u32,
    pub big: f32,
    pub armor: f32,
    pub multi: u32,
    pub home: bool,
    pub melee: bool,
    pub secret: bool,
    /// Номер вопроса викторины для открытия, -1 если не нужен.
    pub quiz: i32,
}

pub static CHARACTERS: &[CharacterDef] = &[
    CharacterDef { name: "Смолик", hp: 3.5, damage: 3.5, fire_rate: 2.6, speed: 3.6, color: "#e08a3c", description: "Универсал", quest: "Открыт сразу", pierce: 0, big: 0.0, armor: 0.0, multi: 1, home: false, melee: false, secret: false, quiz: -1 },
    CharacterDef { name: "Лучник", hp: 3.0, damage: 2.5, fire_rate: 3.24, speed: 4.2, color: "#5fae5f", description: "Быстрый, пули пробивают", quest: "Убей 40 врагов", pierce: 1, big: 0.0, armor: 0.0, multi: 1, home: false, melee: false, secret: false, quiz: -1 },
    CharacterDef { name: "Маг", hp: 3.0, damage: 3.0, fire_rate: 2.4, speed: 3.6, color: "#9a6ad8", description: "Пули наводятся на цель", quest: "Дойди до 4 этажа", pierce: 0, big: 0.0, armor: 0.0, multi: 1, home: true, melee: false, secret: false, quiz: -1 },
    CharacterDef { name: "Рыцарь", hp: 6.0, damage: 5.0, fire_rate: 1.6, speed: 2.9, color: "#9aa4b0", description: "Танк с тяжёлыми пулями", quest: "Собери 150 монет", pierce: 0, big: 0.4, armor: 0.0, multi: 1, home: false, melee: false, secret: false, quiz: -1 },
    CharacterDef { name: "Тень", hp: 2.0, damage: 2.6, fire_rate: 3.0, speed: 5.0, color: "#5a5a82", description: "Двойной выстрел, очень быстрая", quest: "Победи Владыку", pierce: 0, big: 0.0, armor: 0.0, multi: 2, home: false, melee: false, secret: false, quiz: -1 },
    CharacterDef { name: "Кросмоз", hp: 3.0, damage: 3.0, fire_rate: 2.2, speed: 3.8, color: "#3aa0ff", description: "Энергия Вакфу: светящиеся пробивающие сгустки", quest: "Победи Владыку 2 раза", pierce: 1, big: 0.2, armor: 0.0, multi: 1, home: false, melee: false, secret: false, quiz: -1 },
    CharacterDef { name: "NgrOK", hp: 3.5, damage: 3.0, fire_rate: 2.6, speed: 3.8, color: "#9a4ad0", description: "Стреляет буквами N", quest: "Пройди опрос: 5 вопросов", pierce: 0, big: 0.2, armor: 0.0, multi: 1, home: false, melee: false, secret: false, quiz: 6 },
    CharacterDef { name: "Windy", hp: 3.0, damage: 2.6, fire_rate: 3.4, speed: 4.4, color: "#c07aff", description: "Стреляет кассетами, быстрая", quest: "Пройди опрос: 5 вопросов", pierce: 1, big: 0.0, armor: 0.0, multi: 1, home: false, melee: false, secret: false, quiz: 7 },
    CharacterDef { name: "Падший паладин", hp: 4.0, damage: 4.0, fire_rate: 1.9, speed: 3.2, color: "#d8c070", description: "Свет и Тьма. Найди меч...", quest: "???", pierce: 1, big: 0.0, armor: 0.0, multi: 1, home: false, melee: false, secret: true, quiz: -1 },
    CharacterDef { name: "Царь батюшка (Oromss)", hp: 4.0, damage: 3.2, fire_rate: 2.3, speed: 3.4, color: "#e8b84a", description: "Стреляет астрал-шарами, пробивают врагов", quest: "Пройди опрос: 5 вопросов", pierce: 1, big: 0.25, armor: 0.0, multi: 1, home: false, melee: false, secret: false, quiz: 9 },
    CharacterDef { name: "Страж", hp: 4.0, damage: 3.4, fire_rate: 1.7, speed: 3.1, color: "#7a98b8", description: "Ближний бой: бумеранг, много брони", quest: "Собери 8 ячеек сердец за один забег", pierce: 0, big: 0.0, armor: 3.0, multi: 1, home: false, melee: true, secret: false, quiz: -1 },
    CharacterDef { name: "Сода", hp: 4.0, damage: 3.2, fire_rate: 2.2, speed: 3.4, color: "#3fbf5f", description: "Бутылка разбивается на осколки", quest: "Открыт сразу", pierce: 0, big: 0.0, armor: 0.0, multi: 1, home: false, melee: false, secret: false, quiz: -1 },
];

pub struct ItemDef {
    pub name: &'static str,
    pub description: &'static str,
    pub icon: &'static str,
    /// 1 — обычный ... 5 — легендарный.
    pub rarity: u8,
    /// Простые эффекты на характеристики. Если пусто и `custom_js` задан, эффект нужно портировать вручную.
    pub effects: &'static [Effect],
    pub custom_js: Option<&'static str>,
    pub pixels: &'static [&'static str],
}

pub static ITEMS: &[ItemDef] = &[
    ItemDef { name: "Острый клинок", description: "+1 урон", icon: "🔪", rarity: 1, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &["......kk", ".....ksk", "....ksk.", "...ksk..", "kkksk...", "kgkk....", ".kgk....", "..nk...."] },
    ItemDef { name: "Энергетик", description: "быстрее стрельба", icon: "⚡", rarity: 1, effects: &[Effect { stat: Stat::Rate, op: Op::Mul, value: 1.25 }], custom_js: None, pixels: &["....kkk.", "...kyyk.", "..kyyk..", ".kyyyyk.", "..kkyyk.", "...kyk..", "...kk...", "........"] },
    ItemDef { name: "Сапоги", description: "быстрее бег", icon: "👟", rarity: 1, effects: &[Effect { stat: Stat::Spd, op: Op::Add, value: 0.5 }], custom_js: None, pixels: &[".kkkk...", ".knnk...", ".knnk...", ".knnkkk.", ".knnnnnk", "knnnnnnk", "kkkkkkkk", "........"] },
    ItemDef { name: "Сердце-контейнер", description: "+1 макс. HP", icon: "💖", rarity: 1, effects: &[Effect { stat: Stat::Hp, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Mhp, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &[".kk..kk.", "khhkkhhk", "khwhhhhk", "khhhhhhk", "khhhhhhk", ".khhhhk.", "..khhk..", "...kk..."] },
    ItemDef { name: "Двойной выстрел", description: "+1 снаряд, −20% урона", icon: "✌️", rarity: 3, effects: &[Effect { stat: Stat::Dmg, op: Op::Mul, value: 0.8 }, Effect { stat: Stat::Multi, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &["........", ".kk..kk.", "kyykkyyk", "kyykkyyk", ".kk..kk.", "........", "........", "........"] },
    ItemDef { name: "Пробой", description: "пули пробивают врагов", icon: "🏹", rarity: 2, effects: &[Effect { stat: Stat::Pierce, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &["........", "...k....", "..kwk...", "kkkwkkkk", "ksssswwk", "..kwk...", "...k....", "........"] },
    ItemDef { name: "Рикошет", description: "пули отскакивают от стен", icon: "🏀", rarity: 2, effects: &[Effect { stat: Stat::Bounce, op: Op::Add, value: 2.0 }], custom_js: None, pixels: &["..kkkk..", ".kooook.", "kowooook", "kooooook", "kooooook", "kooooook", ".kooook.", "..kkkk.."] },
    ItemDef { name: "Самонаведение", description: "пули ищут цель", icon: "🎯", rarity: 3, effects: &[Effect { stat: Stat::Home, op: Op::Set, value: 1.0 }], custom_js: None, pixels: &["..kkkk..", ".krrrrk.", "krwwwwrk", "krwrrwrk", "krwrrwrk", "krwwwwrk", ".krrrrk.", "..kkkk.."] },
    ItemDef { name: "Вампиризм", description: "лечение при убийстве", icon: "🧛", rarity: 3, effects: &[Effect { stat: Stat::Vamp, op: Op::Add, value: 0.08 }], custom_js: None, pixels: &["...kk...", "...kk...", "..krrk..", ".krrrrk.", "krrwrrrk", "krrrrrrk", ".krrrrk.", "..kkkk.."] },
    ItemDef { name: "Щит", description: "блокирует один удар", icon: "🛡️", rarity: 2, effects: &[Effect { stat: Stat::Shield, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &["kkkkkkkk", "kbbbbbbk", "kbbwwbbk", "kbbwwbbk", ".kbbbbk.", "..kbbk..", "...kk...", "........"] },
    ItemDef { name: "Дальность", description: "пули летят дальше", icon: "🔭", rarity: 1, effects: &[Effect { stat: Stat::Range, op: Op::Mul, value: 1.3 }], custom_js: None, pixels: &["......kk", ".....kck", "....kcck", "...kssk.", "..kssk..", ".kssk...", "ksk.....", "kk......"] },
    ItemDef { name: "Большие пули", description: "крупнее и сильнее", icon: "💣", rarity: 2, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 0.6 }, Effect { stat: Stat::Big, op: Op::Add, value: 0.5 }], custom_js: None, pixels: &["....kyk.", ".....k..", "..kkkk..", ".kkkkkk.", "kkwkkkkk", "kkkkkkkk", "kkkkkkkk", ".kkkkkk."] },
    ItemDef { name: "Огненные пули", description: "поджигают врагов", icon: "🔥", rarity: 2, effects: &[Effect { stat: Stat::Burn, op: Op::Set, value: 1.0 }], custom_js: None, pixels: &["...k....", "..kok...", "..kook..", ".kooook.", ".koyyok.", "koyyyyok", "koyyyyok", ".kkkkkk."] },
    ItemDef { name: "Вакфу-кристалл", description: "+Скорость атаки", icon: "💎", rarity: 2, effects: &[Effect { stat: Stat::Rate, op: Op::Mul, value: 1.3 }], custom_js: None, pixels: &["...kk...", "..kcck..", ".kcwcck.", "kcwccbbk", "kccbbbbk", ".kcbbbk.", "..kbbk..", "...kk..."] },
    ItemDef { name: "Связка ключей", description: "+2 ключа", icon: "🗝️", rarity: 1, effects: &[Effect { stat: Stat::Keys, op: Op::Add, value: 2.0 }], custom_js: None, pixels: &["..kkk...", ".kgggk..", ".kg.gk..", ".kgggk..", "..kgk...", "..kgkk..", "..kgk...", "..kgkk.."] },
    ItemDef { name: "Плащ Сэдиды", description: "+Скорость бега", icon: "🧥", rarity: 2, effects: &[Effect { stat: Stat::Spd, op: Op::Add, value: 0.8 }], custom_js: None, pixels: &["..kkkk..", ".kppppk.", "kppwwppk", "kppppppk", "kpbppbpk", "kpbppbpk", "kpbppbpk", "kkkkkkkk"] },
    ItemDef { name: "Яйцо Дофуса", description: "+2 макс. HP", icon: "🥚", rarity: 3, effects: &[Effect { stat: Stat::Hp, op: Op::Add, value: 2.0 }, Effect { stat: Stat::Mhp, op: Op::Add, value: 2.0 }], custom_js: None, pixels: &["..kkkk..", ".kGGGGk.", "kGGwGGGk", "kGGGGoGk", "kGoGGGGk", "kGGGGGGk", ".kGGGGk.", "..kkkk.."] },
    ItemDef { name: "Зелье Эниприсы", description: "Полное лечение", icon: "🧪", rarity: 1, effects: &[], custom_js: Some("p => p.hp = p.mhp"), pixels: &["..kkkk..", "...kk...", "..kwwk..", ".krrrrk.", "krrwrrrk", "krrrrrrk", ".krrrrk.", "..kkkk.."] },
    ItemDef { name: "Меч Иопа", description: "+1.5 урона", icon: "🗡️", rarity: 3, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 1.5 }], custom_js: None, pixels: &["......kk", ".....ksk", "....kswk", "...kswk.", "kkkswk..", ".kgsk...", ".nkgk...", "nnk.k..."] },
    ItemDef { name: "Око Сакрие", description: "+Дальность, наведение", icon: "👁️", rarity: 3, effects: &[Effect { stat: Stat::Range, op: Op::Mul, value: 1.4 }, Effect { stat: Stat::Home, op: Op::Set, value: 1.0 }], custom_js: None, pixels: &["........", ".kkkkkk.", "kwwwwwwk", "kwwbbwwk", "kwwbkwwk", "kwwwwwwk", ".kkkkkk.", "........"] },
    ItemDef { name: "Лук Крэ", description: "+1 снаряд, −20% дальности, пули медленнее", icon: "🪃", rarity: 3, effects: &[Effect { stat: Stat::Range, op: Op::Mul, value: 0.8 }, Effect { stat: Stat::Multi, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Bsp, op: Op::Mul, value: 0.9 }], custom_js: None, pixels: &[".kk.....", "k.nk....", "k..nk...", "k..gwwws", "k..nk...", "k.nk....", ".kk.....", "........"] },
    ItemDef { name: "Пух Тофу", description: "+2 щита", icon: "🐥", rarity: 2, effects: &[Effect { stat: Stat::Shield, op: Op::Add, value: 2.0 }], custom_js: None, pixels: &["..kkkk..", ".kyyyyk.", "kyykkyyk", "kyyyyyyk", "kyyooyyk", "kyyyyyyk", ".kyyyyk.", "..k..k.."] },
    ItemDef { name: "Дротик Зобаля", description: "+2 пробивания", icon: "📍", rarity: 2, effects: &[Effect { stat: Stat::Pierce, op: Op::Add, value: 2.0 }], custom_js: None, pixels: &["......sk", ".....sk.", "....sk..", "...nk...", "..nk....", ".rrk....", "rrr.....", "rr......"] },
    ItemDef { name: "Шляпа Йопуко", description: "+1 HP, +скорость", icon: "🎩", rarity: 2, effects: &[Effect { stat: Stat::Hp, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Mhp, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Spd, op: Op::Add, value: 0.4 }], custom_js: None, pixels: &["...kkk..", "..kGGGk.", ".kGGGGGk", "kGGGGGGk", "kkkkkkkk", "kGGGGGGk", "kkkkkkkk", "........"] },
    ItemDef { name: "Кольцо Нокмаа", description: "+0.7 урона, +скорость атаки", icon: "💍", rarity: 2, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 0.7 }, Effect { stat: Stat::Rate, op: Op::Mul, value: 1.1 }], custom_js: None, pixels: &["...cc...", "..kggk..", ".kg..gk.", "kg....gk", "kg....gk", ".kg..gk.", "..kggk..", "........"] },
    ItemDef { name: "Бумеранг Эха", description: "+3 рикошета", icon: "🪓", rarity: 2, effects: &[Effect { stat: Stat::Bounce, op: Op::Add, value: 3.0 }], custom_js: None, pixels: &["kkk.....", "knnk....", "knnnk...", ".knnnk..", "..knnnk.", "...knnk.", "....knnk", "....kkkk"] },
    ItemDef { name: "Сфера Ноксиса", description: "+1 урон, поджог", icon: "🔮", rarity: 3, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Burn, op: Op::Set, value: 1.0 }], custom_js: None, pixels: &["..kkkk..", ".kppppk.", "kpwppppk", "kpwppppk", "kppppppk", "kppppbpk", ".kppppk.", "..kkkk.."] },
    ItemDef { name: "Клык Вампира", description: "+Вампиризм", icon: "🦷", rarity: 3, effects: &[Effect { stat: Stat::Vamp, op: Op::Add, value: 0.15 }], custom_js: None, pixels: &["kkkkkkkk", "kwwwwwwk", ".kwwwwk.", ".kwwwwk.", "..kwwk..", "..kwrk..", "...kk...", "........"] },
    ItemDef { name: "Перо Ваба", description: "+1 скорость бега", icon: "🪶", rarity: 1, effects: &[Effect { stat: Stat::Spd, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &["......kk", ".....kbk", "....kbck", "...kbck.", "..kbck..", ".kbck...", "kknk....", "kn......"] },
    ItemDef { name: "Бомба Богдана", description: "Крупные пули, +1.5 урона", icon: "🧨", rarity: 3, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 1.5 }, Effect { stat: Stat::Big, op: Op::Add, value: 0.5 }], custom_js: None, pixels: &["....kyk.", ".....k..", "..kkkk..", ".kkwkkk.", "kkwkkkkk", "kkkkkkkk", ".kkkkkk.", "..kkkk.."] },
    ItemDef { name: "Щит Кроноса", description: "+1 щит, +1 HP", icon: "🔰", rarity: 3, effects: &[Effect { stat: Stat::Hp, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Mhp, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Shield, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &["kkkkkkkk", "kssssssk", "kssrrssk", "kssrrssk", ".kssssk.", "..kssk..", "...kk...", "........"] },
    ItemDef { name: "Корона Ксёлора", description: "+0.5 урона, +скорость атаки, +1 HP", icon: "👑", rarity: 4, effects: &[Effect { stat: Stat::Hp, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Mhp, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Dmg, op: Op::Add, value: 0.5 }, Effect { stat: Stat::Rate, op: Op::Mul, value: 1.1 }], custom_js: None, pixels: &["........", "k..k..k.", "kgkkgkgk", "kggggggk", "kgrggbgk", "kggggggk", "kkkkkkkk", "........"] },
    ItemDef { name: "Череп Нокса", description: "+1 урон, пробой, вампиризм", icon: "💀", rarity: 4, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Pierce, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Vamp, op: Op::Add, value: 0.05 }], custom_js: None, pixels: &[".kkkkkk.", "kwwwwwwk", "kwkwwkwk", "kwkwwkwk", "kwwwwwwk", ".kwkkwk.", ".kwwwwk.", "..kkkk.."] },
    ItemDef { name: "Звезда Эли", description: "+1 снаряд, +скорость атаки, −10% урона, пули медленнее", icon: "⭐", rarity: 4, effects: &[Effect { stat: Stat::Dmg, op: Op::Mul, value: 0.9 }, Effect { stat: Stat::Rate, op: Op::Mul, value: 1.1 }, Effect { stat: Stat::Multi, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Bsp, op: Op::Mul, value: 0.85 }], custom_js: None, pixels: &["...kk...", "...gg...", "kkggggkk", "kgggyggk", ".kgyygk.", "..kggk..", ".kg..gk.", "kk....kk"] },
    ItemDef { name: "Сердце Зверя", description: "+1 макс. HP, полное лечение", icon: "🫀", rarity: 3, effects: &[], custom_js: Some("p => { p.mhp++; p.hp = p.mhp; }"), pixels: &["........", ".kk..kk.", "krrkkrrk", "krrrrrrk", "krwrrrrk", ".krrrrk.", "..krrk..", "...kk..."] },
    ItemDef { name: "Кошелёк Гобба", description: "+10 монет, +1 ключ", icon: "", rarity: 1, effects: &[Effect { stat: Stat::Gold, op: Op::Add, value: 10.0 }, Effect { stat: Stat::Keys, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &["..kkkk..", ".knnnnk.", "..knnk..", ".knnnnk.", "knnnggnk", "knnnggnk", ".knnnnk.", "..kkkk.."] },
    ItemDef { name: "Клевер Удачи", description: "+0.3 урона, +скорость атаки, +1 удача", icon: "", rarity: 1, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 0.3 }, Effect { stat: Stat::Rate, op: Op::Mul, value: 1.15 }, Effect { stat: Stat::Luck, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &["..kk.kk.", ".kGGkGGk", ".kGGGGGk", "..kGGGk.", ".kGGGGGk", ".kGGkGGk", "..kk.nk.", "....nk.."] },
    ItemDef { name: "Гриб Тофу", description: "+1 HP, крупнее пули", icon: "", rarity: 2, effects: &[Effect { stat: Stat::Hp, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Mhp, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Big, op: Op::Add, value: 0.3 }], custom_js: None, pixels: &["..kkkk..", ".krwrrrk", "krrrwrrk", "krwrrrrk", "kkkkkkkk", "..kwwk..", "..kwwk..", "..kkkk.."] },
    ItemDef { name: "Рог Быка", description: "+1.2 урона", icon: "", rarity: 2, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 1.2 }], custom_js: None, pixels: &[".....kkk", "....kwwk", "...kwwk.", "..kwwk..", "..kwwk..", ".kwwk...", ".kwk....", "kkk....."] },
    ItemDef { name: "Часы Эниприсы", description: "+35% скорость атаки", icon: "", rarity: 2, effects: &[Effect { stat: Stat::Rate, op: Op::Mul, value: 1.35 }], custom_js: None, pixels: &["kkkkkkkk", ".kwwwwk.", "..kyyk..", "...kk...", "...kk...", "..kyyk..", ".kyyyyk.", "kkkkkkkk"] },
    ItemDef { name: "Капля Росы", description: "+Дальность, +скорость бега", icon: "", rarity: 1, effects: &[Effect { stat: Stat::Spd, op: Op::Add, value: 0.3 }, Effect { stat: Stat::Range, op: Op::Mul, value: 1.2 }], custom_js: None, pixels: &["...kk...", "...kk...", "..kbbk..", ".kbwbbk.", "kbwbbbbk", "kbbbbbbk", ".kbbbbk.", "..kkkk.."] },
    ItemDef { name: "Подкова", description: "+1 ключ, +5 монет, +1 удача", icon: "", rarity: 1, effects: &[Effect { stat: Stat::Gold, op: Op::Add, value: 5.0 }, Effect { stat: Stat::Keys, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Luck, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &["kk....kk", "ks....sk", "ks....sk", "ks....sk", "kss..ssk", ".ksssssk", "..ksssk.", "...kkk.."] },
    ItemDef { name: "Лунный камень", description: "+1 пробой, +дальность", icon: "", rarity: 2, effects: &[Effect { stat: Stat::Range, op: Op::Mul, value: 1.15 }, Effect { stat: Stat::Pierce, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &["..kkkk..", ".kwwcck.", "kwwcccck", "kwcccbbk", "kwccbbbk", ".kcbbbk.", "..kkkk..", "........"] },
    ItemDef { name: "Печать Хранителя", description: "+1 щит, +0.5 урона", icon: "", rarity: 2, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 0.5 }, Effect { stat: Stat::Shield, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &["..kkkk..", ".kppppk.", "kppyyppk", "kpyyyypk", "kppyyppk", ".kppppk.", "..kkkk..", "........"] },
    ItemDef { name: "Горшок мёда", description: "Лечение, +скорость бега", icon: "", rarity: 1, effects: &[], custom_js: Some("p => { p.hp = p.mhp; p.spd += .2; }"), pixels: &["..knnk..", ".kyyyyk.", "kyyyyyyk", "kyywwyyk", "kyyyyyyk", "kyyyyyyk", ".kyyyyk.", "..kkkk.."] },
    ItemDef { name: "Рог Чёрта", description: "+1.5 урона, поджог", icon: "", rarity: 4, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 1.5 }, Effect { stat: Stat::Burn, op: Op::Set, value: 1.0 }], custom_js: None, pixels: &[".....kk.", "....kmrk", "...kmrk.", "..kmrk..", ".kmrk...", "kmrk....", "kmrk....", "kkk....."] },
    ItemDef { name: "Адский уголь", description: "+0.5 урона, +скорость атаки", icon: "", rarity: 2, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 0.5 }, Effect { stat: Stat::Rate, op: Op::Mul, value: 1.2 }], custom_js: None, pixels: &["..k.k...", ".kokok..", "kooyook.", "kooyyook", "kroooork", "krrooork", ".krrrrk.", "..kkkk.."] },
    ItemDef { name: "Цепь Цербера", description: "+1 снаряд, +1 пробой, −15% урона, −10% дальности", icon: "", rarity: 4, effects: &[Effect { stat: Stat::Dmg, op: Op::Mul, value: 0.85 }, Effect { stat: Stat::Range, op: Op::Mul, value: 0.9 }, Effect { stat: Stat::Multi, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Pierce, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &[".kkk....", "ke.ek...", "ke.eekk.", ".kkk.ekk", "..kkke.k", "...kekk.", "..ke.ek.", "...kkk.."] },
    ItemDef { name: "Сердце Демона", description: "+2 макс. HP, вампиризм", icon: "", rarity: 4, effects: &[Effect { stat: Stat::Hp, op: Op::Add, value: 2.0 }, Effect { stat: Stat::Mhp, op: Op::Add, value: 2.0 }, Effect { stat: Stat::Vamp, op: Op::Add, value: 0.1 }], custom_js: None, pixels: &[".kk..kk.", "kppkkppk", "kpwppppk", "kppppppk", "kppppppk", ".kppppk.", "..kppk..", "...kk..."] },
    ItemDef { name: "Плащ Тьмы", description: "+скорость бега, +1 щит", icon: "", rarity: 2, effects: &[Effect { stat: Stat::Spd, op: Op::Add, value: 0.8 }, Effect { stat: Stat::Shield, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &["..kkkk..", ".kmmmmk.", "kmmddmmk", "kmmddmmk", "kmdddmmk", "kmdmmdmk", "kmdmmdmk", "kkkkkkkk"] },
    ItemDef { name: "Нимб", description: "+1 HP, +1 щит", icon: "", rarity: 2, effects: &[Effect { stat: Stat::Hp, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Mhp, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Shield, op: Op::Add, value: 1.0 }], custom_js: None, pixels: &["........", "..kkkk..", ".kyyyyk.", "kyk..kyk", "kyk..kyk", ".kyyyyk.", "..kkkk..", "........"] },
    ItemDef { name: "Крыло Ангела", description: "+скорость бега, +дальность", icon: "", rarity: 2, effects: &[Effect { stat: Stat::Spd, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Range, op: Op::Mul, value: 1.2 }], custom_js: None, pixels: &["k.......", "kk......", "kwk.....", "kwwkk...", "kwwwwkk.", ".kwwwwwk", "..kwwwwk", "...kkkk."] },
    ItemDef { name: "Святой Грааль", description: "Полное лечение, +1 макс. HP", icon: "", rarity: 5, effects: &[], custom_js: Some("p => { p.mhp++; p.hp = p.mhp; }"), pixels: &["kkkkkkkk", "kggggggk", "kgyyyygk", ".kggggk.", "..kggk..", "..kggk..", ".kggggk.", "kkkkkkkk"] },
    ItemDef { name: "Лира Серафима", description: "+скорость атаки, наведение", icon: "", rarity: 4, effects: &[Effect { stat: Stat::Rate, op: Op::Mul, value: 1.25 }, Effect { stat: Stat::Home, op: Op::Set, value: 1.0 }], custom_js: None, pixels: &[".kk..kk.", "kgk..kgk", "kgk..kgk", "kgkkkkgk", "kgykkygk", ".kgggkk.", "..kgk...", "..kkk..."] },
    ItemDef { name: "Священный Меч", description: "+2 урона", icon: "", rarity: 5, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 2.0 }], custom_js: None, pixels: &[".....kyk", "....kykk", "...kwk..", "..kwk...", "kkkwk...", "kgkk....", ".kgk....", "..nk...."] },
    ItemDef { name: "Жало Ядокрыла", description: "Ядовитые пули. Огонь + яд = ядовитое облако", icon: "", rarity: 3, effects: &[Effect { stat: Stat::Poison, op: Op::Set, value: 1.0 }], custom_js: None, pixels: &[".......k", "......kG", ".....kGG", "....kGGk", "...kGGk.", "..kGGk..", ".kGGk...", "kGGk...."] },
    ItemDef { name: "Зап Эниприсы", description: "АКТИВ: рывок-телепорт, кулдаун 5 с", icon: "", rarity: 3, effects: &[], custom_js: Some("p => { p.act = { id, k: ACT[id].k, m: ACT[id].m, c: id == 'reap' ? 0 : ACT[id].m }; }"), pixels: &["..kkkk..", ".kbccbk.", "kbc..cbk", "kc....ck", "kc....ck", "kbc..cbk", ".kbccbk.", "..kkkk.."] },
    ItemDef { name: "Заряд Дофуса", description: "АКТИВ: взрыв, заряд за 60 урона", icon: "", rarity: 4, effects: &[], custom_js: Some("p => { p.act = { id, k: ACT[id].k, m: ACT[id].m, c: id == 'reap' ? 0 : ACT[id].m }; }"), pixels: &["..kkkk..", ".kcwcck.", "kcwccbck", "kccccbck", "kcbcccck", "kbcccbck", ".kbbbbk.", "..kkkk.."] },
    ItemDef { name: "Договор Крос", description: "АКТИВ: -1 HP, x2 урон и темп до конца боя", icon: "", rarity: 4, effects: &[], custom_js: Some("p => { p.act = { id, k: ACT[id].k, m: ACT[id].m, c: id == 'reap' ? 0 : ACT[id].m }; }"), pixels: &[".kkkkkk.", "kwwwwwwk", "kwrrrrwk", "kwwwwwwk", "kwrrrwwk", "kwwwwwwk", "kwrrwwwk", ".kkkkkk."] },
    ItemDef { name: "Клинок Холодной Скорби", description: "Форма Тьмы: +80% урона, лайфстил, -2 HP", icon: "", rarity: 5, effects: &[], custom_js: Some("p => { p.dark = 1; p.col = '#5a2a8a'; p.dmg *= 1.8; p.spd *= 1.15; p.vamp += .1; p.mhp = Math.max(1, p.mhp - 2); p.hp = Math.min(p.hp, p.mhp); setAct('reap')(p); game.flash = .6; toast(translate('Тьма поглотила тебя...')); }"), pixels: &["......kk", ".....kck", "....kcwk", "...kcwk.", "kkkcwk..", "kbkck...", ".kbk....", "kk.k...."] },
    ItemDef { name: "Бомба Богдана", description: "АКТИВ: бомба, взрыв через 1.5 с, кулдаун 8 с", icon: "💣", rarity: 3, effects: &[], custom_js: Some("p => { p.act = { id, k: ACT[id].k, m: ACT[id].m, c: id == 'reap' ? 0 : ACT[id].m }; }"), pixels: &["....ky..", "...k....", "..kkkk..", ".kddddk.", "kdwddddk", "kddddddk", ".kddddk.", "..kkkk.."] },
    ItemDef { name: "Песок Времени", description: "АКТИВ: заморозка врагов и пуль на 3 с, 3 комнаты", icon: "⏳", rarity: 3, effects: &[], custom_js: Some("p => { p.act = { id, k: ACT[id].k, m: ACT[id].m, c: id == 'reap' ? 0 : ACT[id].m }; }"), pixels: &["kkkkkkkk", "kyyyyyyk", ".kyyyyk.", "..kyyk..", "..kyyk..", ".kyyyyk.", "kyyyyyyk", "kkkkkkkk"] },
    ItemDef { name: "Фляга Эниприсы", description: "АКТИВ: лечит 2 сердца, 4 комнаты", icon: "🧪", rarity: 3, effects: &[], custom_js: Some("p => { p.act = { id, k: ACT[id].k, m: ACT[id].m, c: id == 'reap' ? 0 : ACT[id].m }; }"), pixels: &["..kkkk..", "..kwwk..", "..kwwk..", ".khhhhk.", "khhwhhhk", "khhhhhhk", ".khhhhk.", "..kkkk.."] },
    ItemDef { name: "Дыхание Дракона", description: "АКТИВ: огненная волна, заряд за 40 урона", icon: "🐲", rarity: 3, effects: &[], custom_js: Some("p => { p.act = { id, k: ACT[id].k, m: ACT[id].m, c: id == 'reap' ? 0 : ACT[id].m }; }"), pixels: &["...k....", "..kok...", "..kook..", ".kooyok.", "kooyyook", "kooyyook", ".koyyok.", "..kkkk.."] },
    ItemDef { name: "Туман Крэ", description: "АКТИВ: отравляет всех в комнате, 3 комнаты", icon: "☠️", rarity: 3, effects: &[], custom_js: Some("p => { p.act = { id, k: ACT[id].k, m: ACT[id].m, c: id == 'reap' ? 0 : ACT[id].m }; }"), pixels: &["..kkk...", ".kGGGk..", "kGGwGGkk", "kGGGGGGk", "kGwGGwGk", ".kGGGGk.", "..kGGk..", "...kk..."] },
    ItemDef { name: "Аура Йопуко", description: "АКТИВ: +1 щит, кулдаун 20 с", icon: "🫧", rarity: 3, effects: &[], custom_js: Some("p => { p.act = { id, k: ACT[id].k, m: ACT[id].m, c: id == 'reap' ? 0 : ACT[id].m }; }"), pixels: &["..kkkk..", ".kvwvvk.", "kvwvvvvk", "kvvvvvvk", "kvvvvvvk", "kvvvvpvk", ".kvppvk.", "..kkkk.."] },
    ItemDef { name: "Вихрь Иопа", description: "АКТИВ: 16 пуль по кругу, кулдаун 7 с", icon: "🌪️", rarity: 3, effects: &[], custom_js: Some("p => { p.act = { id, k: ACT[id].k, m: ACT[id].m, c: id == 'reap' ? 0 : ACT[id].m }; }"), pixels: &["kkkkkkkk", "ksssssk.", ".kkkkssk", "..ksssk.", ".ksskk..", "..kssk..", "...kk...", "........"] },
    ItemDef { name: "Кама-дождь", description: "АКТИВ: монеты (3x3), 1 раз за этаж", icon: "💰", rarity: 3, effects: &[], custom_js: Some("p => { p.act = { id, k: ACT[id].k, m: ACT[id].m, c: id == 'reap' ? 0 : ACT[id].m }; }"), pixels: &["..kkkk..", ".kggggk.", "kgyyyggk", "kgyggook", "kkkkkkkk", ".kggggk.", "kgyyyggk", "kkkkkkkk"] },
    ItemDef { name: "Ярость Быка", description: "АКТИВ: темп x1.5 и скорость x1.3 на 6 с, 8 убийств", icon: "🐂", rarity: 3, effects: &[], custom_js: Some("p => { p.act = { id, k: ACT[id].k, m: ACT[id].m, c: id == 'reap' ? 0 : ACT[id].m }; }"), pixels: &["k......k", "kk....kk", "kwk..kwk", ".kkkkkk.", "kooooook", "kowkkwok", "kooooook", ".kkmmkk."] },
    ItemDef { name: "Рикошет-шторм", description: "АКТИВ: +3 пробоя и +3 рикошета на 5 с, 6 убийств", icon: "🏀", rarity: 3, effects: &[], custom_js: Some("p => { p.act = { id, k: ACT[id].k, m: ACT[id].m, c: id == 'reap' ? 0 : ACT[id].m }; }"), pixels: &["..kkkk..", ".kooyok.", "kooyoook", "kyooooyk", "kooooyok", "kooyooyk", ".koooyk.", "..kkkk.."] },
    ItemDef { name: "Клинок Земли", description: "Зелёные клинки-лучи: +2 урона, +2 пробоя", icon: "", rarity: 5, effects: &[Effect { stat: Stat::Dmg, op: Op::Add, value: 2.0 }, Effect { stat: Stat::Pierce, op: Op::Add, value: 2.0 }, Effect { stat: Stat::Big, op: Op::Add, value: 0.4 }, Effect { stat: Stat::Terra, op: Op::Set, value: 1.0 }], custom_js: None, pixels: &["......kk", ".....kGk", "....kGGk", "...kGcGk", "..kGcGk.", ".kgGGk..", "kgk.k...", "kk......"] },
    ItemDef { name: "Последняя призма", description: "Каждый 4-й выстрел: веер из 5 радужных лучей", icon: "", rarity: 5, effects: &[Effect { stat: Stat::Prism, op: Op::Set, value: 1.0 }], custom_js: None, pixels: &["...kk...", "..kwwk..", ".kwwcwk.", ".kwcwwk.", "kwwwwcwk", "kwwwwwwk", "krygGbpk", "kkkkkkkk"] },
    ItemDef { name: "Микро-пули", description: "Крошечные пули: −40% урона, +80% скорость атаки, пули быстрее", icon: "", rarity: 3, effects: &[Effect { stat: Stat::Dmg, op: Op::Mul, value: 0.6 }, Effect { stat: Stat::Rate, op: Op::Mul, value: 1.8 }, Effect { stat: Stat::Bsp, op: Op::Mul, value: 1.5 }, Effect { stat: Stat::Msz, op: Op::Mul, value: 0.5 }], custom_js: None, pixels: &["........", ".k...k..", "kyk.kyk.", ".k...k..", "...k....", "..kyk...", "...k....", "........"] },
    ItemDef { name: "Кроличья лапка", description: "+2 удачи, +1 ключ", icon: "", rarity: 3, effects: &[Effect { stat: Stat::Keys, op: Op::Add, value: 1.0 }, Effect { stat: Stat::Luck, op: Op::Add, value: 2.0 }], custom_js: None, pixels: &["..kk.kk.", ".kwwkwwk", ".kwwkwwk", "..kwwwk.", ".kwwwwwk", "kwwhwwwk", "kwwwwwwk", ".kkkkkk."] },
];

pub struct BossDef {
    pub name: &'static str,
    pub color: &'static str,
    /// Код порядка атак из JS-версии (буквы обозначают типы атак).
    pub pattern: &'static str,
}

pub static BOSSES: &[BossDef] = &[
    BossDef { name: "Король Слизней", color: "#6cc46c", pattern: "crcf" },
    BossDef { name: "Хозяин Теней", color: "#9a6ad8", pattern: "crsfcr" },
    BossDef { name: "Бык-Разрушитель", color: "#d07a2a", pattern: "dfdrd" },
    BossDef { name: "Владыка Подземелья", color: "#d03a2a", pattern: "crdsfd" },
    BossDef { name: "Королева Летучих", color: "#d070b0", pattern: "sfrfr" },
    BossDef { name: "Око-Страж", color: "#dde0f0", pattern: "rrfrf" },
    BossDef { name: "Каменный Голем", color: "#8a8a96", pattern: "dcdrd" },
    BossDef { name: "Огненный Дух", color: "#f08a2a", pattern: "ffrfd" },
    BossDef { name: "Цербер", color: "#c0402a", pattern: "dfdrd" },
    BossDef { name: "Лорд Пламени", color: "#ff6a2a", pattern: "rfrsf" },
    BossDef { name: "Сатана", color: "#8a1020", pattern: "crdsfdrf" },
    BossDef { name: "Страж Врат", color: "#e8d890", pattern: "dcdrf" },
    BossDef { name: "Серафим", color: "#f0f4ff", pattern: "rfsrf" },
    BossDef { name: "Архангел", color: "#ffd84a", pattern: "crdsfdrf" },
    BossDef { name: "Колючий Король", color: "#6f9a4a", pattern: "cprfpd" },
];

pub struct RoomDef {
    pub name: &'static str,
    /// Прямоугольники (ширина, высота) в клетках; несколько — комната-крест.
    pub rects: &'static [(u32, u32)],
    pub ring: bool,
}

pub static ROOMS: &[RoomDef] = &[
    RoomDef { name: "Обычная", rects: &[(10, 9)], ring: false },
    RoomDef { name: "Большая", rects: &[(18, 13)], ring: false },
    RoomDef { name: "Длинная ↔", rects: &[(18, 6)], ring: false },
    RoomDef { name: "Длинная ↕", rects: &[(7, 13)], ring: false },
    RoomDef { name: "Узкая ↔", rects: &[(18, 3)], ring: false },
    RoomDef { name: "Узкая ↕", rects: &[(3, 13)], ring: false },
    RoomDef { name: "Крест", rects: &[(18, 5), (6, 13)], ring: false },
    RoomDef { name: "Кольцо", rects: &[(18, 13)], ring: true },
];

/// Энергетики курилки: название и цвет банки. Бесплатные.
pub static DRINKS: &[(&str, &str)] = &[
    ("Monster", "#7ad63a"),
    ("Hell", "#e0302a"),
    ("Non Stop", "#2a8ae0"),
];

pub static EMOTES: &[&str] = &["👋", "😂", "🔥", "N"];
