//! Предметы, активные способности, урон, смерть монстров, взрывы. Порт `hurtP`, `hurtE`, `killE`, `ACT`, `blast` из JS.
use crate::data::ITEMS;
use crate::defs::*;
use crate::dungeon::MAP_COLS;
use crate::game::*;
use crate::profile::RunResult;

/// Дополнительный эффект взрыва на врагов.
#[derive(Clone, Copy, Debug)]
pub enum BlastFx {
    None,
    Burn(f32),
    Poison(f32),
}

impl Game {
    // ---------- предметы ----------

    /// Применяет эффект предмета к игроку (без подбора и баннера).
    pub fn apply_item(&mut self, i: usize) {
        let def = &ITEMS[i];
        for e in def.effects.iter() {
            self.p.st.apply(e);
        }
        match i {
            17 | 44 => {
                self.p.st.hp = self.p.st.mhp;
                if i == 44 {
                    self.p.st.spd += 0.2;
                }
            }
            34 | 52 => {
                self.p.st.mhp += 1.0;
                self.p.st.hp = self.p.st.mhp;
            }
            59 => {
                // Клинок Холодной Скорби: форма Тьмы
                self.p.st.dark = 1.0;
                self.p.color = "#5a2a8a";
                self.p.st.dmg *= 1.8;
                self.p.st.spd *= 1.15;
                self.p.st.vamp += 0.1;
                self.p.st.mhp = (self.p.st.mhp - 2.0).max(1.0);
                self.p.st.hp = self.p.st.hp.min(self.p.st.mhp);
                self.set_act(ActId::Reap, Some(i));
                self.flash = 0.6;
                self.say("Тьма поглотила тебя...");
            }
            _ => {
                if let Some(id) = item_active(i) {
                    self.set_act(id, Some(i));
                }
            }
        }
    }

    pub fn set_act(&mut self, id: ActId, item: Option<usize>) {
        let d = act_def(id);
        let c = if id == ActId::Reap { 0.0 } else { d.max };
        self.p.act = Some(Act { id, kind: d.kind, m: d.max, c, item });
    }

    /// Подбор предмета: эффект, список, баннер.
    pub fn take_item_effect(&mut self, i: usize) {
        self.apply_item(i);
        self.p.items.push(i);
        let def = &ITEMS[i];
        let stars: String = "★".repeat(def.rarity as usize);
        self.ban = Some(Banner { title: format!("{} {}", stars, def.name), desc: def.description.to_string(), rarity: def.rarity, l: 3.2 });
        self.flash = 0.15;
    }

    pub fn end_buff(&mut self, id: ActId) {
        match id {
            ActId::Rage => {
                self.p.st.rate /= 1.5;
                self.p.st.spd /= 1.3;
            }
            ActId::Storm => {
                self.p.st.pierce -= 3.0;
                self.p.st.bounce -= 3.0;
            }
            _ => {}
        }
    }

    fn add_buff(&mut self, id: ActId, sec: f32) -> bool {
        if self.p.bf.iter().any(|b| b.id == id) {
            return false;
        }
        match id {
            ActId::Rage => {
                self.p.st.rate *= 1.5;
                self.p.st.spd *= 1.3;
            }
            ActId::Storm => {
                self.p.st.pierce += 3.0;
                self.p.st.bounce += 3.0;
            }
            _ => {}
        }
        self.p.bf.push(Buff { id, t: sec });
        let (x, y) = (self.p.x, self.p.y);
        self.puff(x, y, "#f0c030", 12);
        true
    }

    // ---------- активки и бомбы ----------

    pub fn act_ready(&self) -> bool {
        match self.p.act {
            Some(a) => a.c >= a.m,
            None => false,
        }
    }

    pub fn use_act(&mut self) {
        if self.over || self.choose || self.intro > 0.0 || self.p.dead {
            return;
        }
        let a = match self.p.act {
            Some(a) => a,
            None => return,
        };
        if a.c < a.m {
            return;
        }
        if !self.run_act(a.id) {
            return;
        }
        if let Some(ac) = self.p.act.as_mut() {
            ac.c = 0.0;
        }
    }

    /// false — способность не сработала, заряд не тратится.
    fn run_act(&mut self, id: ActId) -> bool {
        let (px, py) = (self.p.x, self.p.y);
        match id {
            ActId::Zap => {
                let sp = hyp(self.p.vx, self.p.vy);
                let (dx, dy) = if sp > 0.3 { (self.p.vx / sp, self.p.vy / sp) } else { (self.p.fx, self.p.fy) };
                self.puff(px, py, "#6fe0ff", 12);
                for _ in 0..30 {
                    let (nx, ny, _) = self.try_move(self.p.x, self.p.y, self.p.r, dx * 0.1, dy * 0.1, true);
                    self.p.x = nx;
                    self.p.y = ny;
                }
                self.p.inv = self.p.inv.max(0.3);
                let (nx, ny) = (self.p.x, self.p.y);
                self.puff(nx, ny, "#6fe0ff", 12);
                true
            }
            ActId::Dof => {
                self.burst(4.0, 8.0, "#6fe0ff");
                true
            }
            ActId::Pact => {
                if !self.rs[self.cur].lk || self.p.rg {
                    self.say("Нужен бой");
                    return false;
                }
                if self.p.st.hp <= 1.0 {
                    self.say("Мало здоровья");
                    return false;
                }
                self.p.st.hp -= 1.0;
                self.p.st.dmg *= 2.0;
                self.p.st.rate *= 2.0;
                self.p.rg = true;
                self.puff(px, py, "#d03a2a", 14);
                self.flash = 0.2;
                true
            }
            ActId::Seal => {
                self.burst(3.0, 0.0, "#f0c030");
                self.p.st.hp = (self.p.st.hp + 1.0).min(self.p.st.mhp);
                true
            }
            ActId::Reap => {
                self.burst(4.0, 10.0, "#9a5aff");
                true
            }
            ActId::Bomb => {
                self.lob();
                true
            }
            ActId::Sand => {
                self.freeze = 3.0;
                self.flash = 0.25;
                true
            }
            ActId::Flask => {
                if self.p.st.hp >= self.p.st.mhp {
                    self.say("Здоровье полное");
                    return false;
                }
                self.p.st.hp = (self.p.st.hp + 2.0).min(self.p.st.mhp);
                self.puff(px, py, "#ff7a9a", 12);
                true
            }
            ActId::Drag => {
                self.blast(px, py, 4.5, 4.0, "#ff7a2a", BlastFx::Burn(3.0));
                true
            }
            ActId::Fog => {
                self.blast(px, py, 99.0, 0.0, "#6fd06f", BlastFx::Poison(6.0));
                true
            }
            ActId::Aura => {
                self.p.st.shield += 1.0;
                self.puff(px, py, "#8fd0ff", 14);
                true
            }
            ActId::Whirl => {
                let st = self.p.st.clone();
                let own = self.me();
                for i in 0..16 {
                    let a = i as f32 * std::f32::consts::PI / 8.0;
                    let mut b = Bullet::base(px, py, a.cos() * 8.0, a.sin() * 8.0, st.range, 0.14);
                    b.d = st.dmg;
                    b.own = own;
                    b.pi = st.pierce.round() as i32;
                    b.bn = st.bounce.round() as i32;
                    b.bu = st.burn > 0.5;
                    b.po = st.poison > 0.5;
                    self.bul.push(b);
                }
                self.shake = 0.15;
                true
            }
            ActId::Kama => {
                for i in 0..3 {
                    self.pick.push(Pick::coin(px + (i as f32 - 1.0) * 0.6, py + 0.6, 3));
                }
                true
            }
            ActId::Rage => self.add_buff(ActId::Rage, 6.0),
            ActId::Storm => self.add_buff(ActId::Storm, 5.0),
        }
    }

    pub fn throw_bomb(&mut self) {
        if self.over || self.choose || self.intro > 0.0 || self.p.dead || self.p.bombs <= 0 {
            return;
        }
        self.p.bombs -= 1;
        self.lob();
    }

    fn lob(&mut self) {
        let mut x = self.p.x + self.p.fx * 0.5;
        let mut y = self.p.y + self.p.fy * 0.5;
        if self.wall(x, y, false) {
            x = self.p.x;
            y = self.p.y;
        }
        let vx = self.p.fx * 7.5 + self.p.vx * 0.4;
        let vy = self.p.fy * 7.5 + self.p.vy * 0.4;
        self.bombs.push(Bomb { x, y, l: 1.6, vx, vy, hostile: false });
    }

    /// Взрыв вокруг игрока по всем монстрам: урон, оглушение, отброс.
    fn burst(&mut self, r: f32, d: f32, col: &str) {
        self.shake = 0.3;
        self.flash = 0.2;
        let (px, py) = (self.p.x, self.p.y);
        self.ring_parts(px, py, r, col);
        for j in 0..self.mons.len() {
            if self.mons[j].dead {
                continue;
            }
            let dx = self.mons[j].x - px;
            let dy = self.mons[j].y - py;
            let dd0 = hyp(dx, dy);
            let dd = if dd0 == 0.0 { 1.0 } else { dd0 };
            if dd < r {
                if d > 0.0 {
                    self.hurt_mon(j, d, false);
                }
                let m_cd = self.mons[j].cd.max(1.2);
                self.mons[j].cd = m_cd;
                if !self.mons[j].boss && !self.mons[j].dead {
                    let (ex, ey, cr) = (self.mons[j].x, self.mons[j].y, self.mons[j].col_r());
                    let (nx, ny, _) = self.try_move(ex, ey, cr, dx / dd * 1.2, dy / dd * 1.2, false);
                    self.mons[j].x = nx;
                    self.mons[j].y = ny;
                }
            }
        }
    }

    /// Взрыв в точке по монстрам текущей комнаты.
    pub fn blast(&mut self, x: f32, y: f32, r: f32, d: f32, col: &str, fx: BlastFx) {
        self.shake = 0.25;
        self.ring_parts(x, y, r, col);
        for j in 0..self.mons.len() {
            let (dead, ex, ey) = (self.mons[j].dead, self.mons[j].x, self.mons[j].y);
            if dead || !self.in_cur_cell(ex, ey) || hyp(ex - x, ey - y) > r {
                continue;
            }
            if d > 0.0 {
                self.hurt_mon(j, d, false);
            }
            if !self.mons[j].dead {
                match fx {
                    BlastFx::Burn(t) => self.mons[j].bt = t,
                    BlastFx::Poison(t) => self.mons[j].pt = t,
                    BlastFx::None => {}
                }
                let c = self.mons[j].cd.max(1.0);
                self.mons[j].cd = c;
            }
        }
    }

    // ---------- урон ----------

    pub fn hurt_player(&mut self, d: f32) {
        if self.p.inv > 0.0 || self.over {
            return;
        }
        self.p.inv = 1.1;
        self.shake = 0.25;
        if self.p.st.shield > 0.0 {
            self.p.st.shield -= 1.0;
            self.say("Щит поглотил удар");
            return;
        }
        self.p.st.hp -= d * DIFFS[self.diff].dm;
        let (x, y) = (self.p.x, self.p.y);
        self.puff(x, y, "#d03a2a", 8);
        if self.p.st.hp <= 0.0 {
            self.p.st.hp = 0.0;
            self.p.dead = true;
            let partner_alive = match self.p2.as_ref() {
                Some(q) => !q.dead,
                None => false,
            };
            if partner_alive {
                self.say("Игрок погиб. Он вернётся на следующем этаже");
            } else {
                self.finish(false);
            }
        }
    }

    /// Урон монстру с индексом `j`. `quiet` — без вспышки (огонь, яд, газ).
    pub fn hurt_mon(&mut self, j: usize, d: f32, quiet: bool) {
        if j >= self.mons.len() || self.mons[j].dead {
            return;
        }
        self.mons[j].hp -= d;
        if let Some(a) = self.p.act.as_mut() {
            if a.kind == ActKind::Dmg {
                a.c = (a.c + d).min(a.m);
            }
        }
        if !quiet {
            self.mons[j].fl = 0.1;
        }
        if self.mons[j].hp <= 0.0 {
            self.kill_mon(j);
        }
    }

    pub fn kill_mon(&mut self, j: usize) {
        let (x, y, boss, kind, bt, pt, color) = {
            let m = &self.mons[j];
            (m.x, m.y, m.boss, m.kind, m.bt, m.pt, m.color)
        };
        self.mons[j].dead = true;
        if boss {
            self.rings.clear();
        }
        self.p.kills += 1;
        if kind == MonKind::Bomber {
            self.bombs.push(Bomb { x, y, l: 1.0, vx: 0.0, vy: 0.0, hostile: true });
        }
        if let Some(a) = self.p.act.as_mut() {
            if a.kind == ActKind::Kill {
                a.c = (a.c + 1.0).min(a.m);
            }
        }
        if bt > 0.0 && pt > 0.0 {
            self.gas.push(Gas { x, y, l: 2.0 });
        }
        self.puff(x, y, color, if boss { 30 } else { 8 });
        let dr = DIFFS[self.diff].dr;
        let chance = if boss { 1.0 } else { 0.11 * dr };
        if self.rng.next_f32() < chance {
            let v = if boss { 9 } else { 1 + self.rng.below(2) as i32 };
            self.pick.push(Pick::coin(x, y, v));
        }
        if !boss && self.rng.next_f32() < 0.02 * dr {
            self.pick.push(Pick::new(PickKind::Key, x + 0.3, y));
        }
        if self.rng.next_f32() < self.p.st.vamp && self.p.st.hp < self.p.st.mhp {
            self.p.st.hp = (self.p.st.hp + 1.0).min(self.p.st.mhp);
        }
        if boss {
            self.boss_dies(j, x, y);
        }
    }

    fn boss_dies(&mut self, j: usize, x: f32, y: f32) {
        self.boss_on = false;
        self.flash = 0.7;
        self.shake = 0.6;
        for k in 0..self.mons.len() {
            if k != j {
                self.mons[k].dead = true;
            }
        }
        if self.floor == 6 && !self.won {
            self.won = true;
            self.mid_win = true;
            if self.p.gold() >= 100 {
                self.pal_unlock = true;
            }
            self.p.st.gold += 60.0;
            self.say("ПОБЕДА! Владыка повержен. Спуск продолжается!");
            self.flash = 1.0;
            self.choose = true;
        }
        if self.path.is_some() && self.floor >= 9 {
            self.p.st.gold += 100.0;
            self.fin = true;
            self.fin_t = 2.2;
        } else {
            let (sx, sy) = self.stairs;
            self.map[sy as usize][sx as usize] = 2;
        }
        self.cg_ctr += 1;
        let cg = self.cg_ctr;
        let a = self.take_item() as i32;
        let b = self.take_item() as i32;
        let mut p1 = Pick::item(x - 0.7, y, a);
        p1.cg = cg;
        let mut p2 = Pick::item(x + 0.7, y, b);
        p2.cg = cg;
        self.pick.push(p1);
        self.pick.push(p2);
        if self.rng.next_f32() < 0.3 * DIFFS[self.diff].dr {
            self.pick.push(Pick::new(PickKind::DoubleHeart, x, y + 0.9));
        }
        if self.p.ch == 8 && self.p.st.dark < 0.5 && self.floor == 3 {
            self.pick.push(Pick::item(x, y - 0.9, SWORD_ITEM as i32));
        }
        if self.fin {
            let s = if self.path == Some(Path::Hell) { "КОНЦОВКА: Ад склонился перед тобой!" } else { "КОНЦОВКА: Рай признал тебя героем!" };
            self.say(s);
        } else if !self.won || self.floor != 6 {
            self.say("Босс повержен! Выбери 1 из 2 предметов");
        }
    }

    // ---------- босс-атаки и осколки ----------

    pub fn ring_atk(&mut self, e: &Monster) {
        self.shake = 0.2;
        for i in 0..3 {
            let g = self.rng.next_f32() * 6.283;
            self.rings.push(RingAtk { x: e.x, y: e.y, r: 0.8, sp: 4.2 + self.floor as f32 * 0.1, g, gw: 0.5, t: 0.6 + i as f32 * 0.75, eid: e.id });
        }
    }

    /// Бутылка Соды разбивается на осколки.
    pub fn shatter(&mut self, b: &Bullet) {
        self.puff(b.x, b.y, "#7fe0a0", 8);
        let o = self.rng.next_f32() * 6.28;
        for j in 0..6 {
            let a = o + j as f32 * 1.047;
            let v = 5.0 + self.rng.next_f32() * 2.0;
            let mut s = Bullet::base(b.x, b.y, a.cos() * v, a.sin() * v, 0.4, 0.08);
            s.d = (b.d * 0.5).max(0.5);
            s.skin = Skin::Shard;
            s.own = b.own;
            s.bu = b.bu;
            s.po = b.po;
            s.hit = b.hit.clone();
            self.bul.push(s);
        }
    }

    // ---------- камни, бочки, добыча ----------

    pub fn drop_loot(&mut self, x: f32, y: f32) {
        let dr = DIFFS[self.diff].dr;
        if self.rng.next_f32() > 0.4 * (dr + 0.3).min(1.4) {
            return;
        }
        let q = self.rng.next_f32();
        if q < 0.5 {
            let v = 1 + self.rng.below(2) as i32;
            self.pick.push(Pick::coin(x, y, v));
        } else if q < 0.7 {
            self.pick.push(Pick::new(PickKind::HalfHeart, x, y));
        } else if q < 0.85 {
            self.pick.push(Pick::new(PickKind::Bomb, x, y));
        } else if q < 0.95 {
            self.pick.push(Pick::new(PickKind::Key, x, y));
        } else {
            self.pick.push(Pick::new(PickKind::Heart, x, y));
        }
    }

    pub fn break_blocks(&mut self, x: f32, y: f32, rad: f32) {
        let (rx, ry, rw, rh) = {
            let r = &self.rooms[self.cur];
            (r.x, r.y, r.w, r.h)
        };
        let mut n = 0;
        let j0 = (y - rad).floor() as i32;
        let j1 = (y + rad).floor() as i32;
        let i0 = (x - rad).floor() as i32;
        let i1 = (x + rad).floor() as i32;
        for j in j0..=j1 {
            for i in i0..=i1 {
                if i < rx || j < ry || i >= rx + rw || j >= ry + rh {
                    continue;
                }
                let k = j * MAP_COLS + i;
                if self.tile(i, j) != 1 || !self.brk.contains(&k) || hyp(i as f32 + 0.5 - x, j as f32 + 0.5 - y) > rad {
                    continue;
                }
                self.map[j as usize][i as usize] = 0;
                self.brk.remove(&k);
                n += 1;
                self.puff(i as f32 + 0.5, j as f32 + 0.5, "#9a8a74", 7);
                self.drop_loot(i as f32 + 0.5, j as f32 + 0.5);
            }
        }
        if n > 0 {
            self.shake = self.shake.max(0.3);
        }
    }

    pub fn barrel_die(&mut self, k: i32) {
        let o = match self.bar.remove(&k) {
            Some(o) => o,
            None => return,
        };
        self.map[o.y as usize][o.x as usize] = 0;
        let x = o.x as f32 + 0.5;
        let y = o.y as f32 + 0.5;
        self.blast(x, y, 2.3, 12.0, "#ff8a2a", BlastFx::None);
        self.puff(x, y, "#ffd070", 14);
        self.break_blocks(x, y, 1.8);
        self.each_player(|g| {
            if hyp(g.p.x - x, g.p.y - y) < 2.0 {
                g.hurt_player(1.0);
            }
        });
        self.drop_loot(x, y);
        self.barrel_boom(x, y, 2.3);
    }

    pub fn barrel_boom(&mut self, x: f32, y: f32, r: f32) {
        if self.bar.is_empty() {
            return;
        }
        let keys: Vec<i32> = self
            .bar
            .iter()
            .filter(|kv| {
                let o = kv.1;
                hyp(o.x as f32 + 0.5 - x, o.y as f32 + 0.5 - y) <= r
            })
            .map(|kv| *kv.0)
            .collect();
        for k in keys {
            if self.bar.contains_key(&k) {
                self.barrel_die(k);
            }
        }
    }

    // ---------- конец забега ----------

    pub fn finish(&mut self, win: bool) {
        if self.over {
            return;
        }
        self.over = true;
        self.win = win;
    }

    pub fn give_up(&mut self) {
        self.finish(false);
    }

    pub fn choose_path(&mut self, pa: Path) {
        self.path = Some(pa);
        self.choose = false;
        match pa {
            Path::Hell => self.say("Ты выбрал Ад. Спускайся!"),
            Path::Heaven => self.say("Ты выбрал Рай. Поднимайся!"),
        }
    }

    pub fn result(&self) -> RunResult {
        RunResult {
            win: self.win,
            floor: self.floor,
            gold: self.p.gold(),
            kills: self.p.kills,
            mid_win: self.mid_win,
            pal_unlock: self.pal_unlock,
            guard_unlock: self.guard_unlock,
        }
    }
}
