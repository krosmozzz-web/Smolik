//! Состояние забега и генерация этажа. Правила боя живут в `sim.rs`, предметы и активки в `actions.rs`.
//! Порт JS-версии 0.6.9: один игрок, без онлайна. Случайность идёт из `Rng`, поэтому по сиду забег воспроизводим.
use crate::data::{BOSSES, CHARACTERS, ITEMS, ROOMS};
use crate::defs::*;
use crate::dungeon::{self, Room, CH, CW, MAP_COLS, MAP_ROWS};
use crate::rng::Rng;
use crate::stats::Stats;
use std::collections::{HashMap, HashSet};

pub fn hyp(a: f32, b: f32) -> f32 {
    (a * a + b * b).sqrt()
}

/// Номер клетки сетки комнат по координате в тайлах.
pub fn cell_x(x: f32) -> i32 {
    (x / CW as f32).floor() as i32
}
pub fn cell_y(y: f32) -> i32 {
    (y / CH as f32).floor() as i32
}

/// Ввод за кадр. Оси от -1 до 1: движение (ix, iy) и направление стрельбы (ax, ay).
#[derive(Clone, Copy, Debug, Default)]
pub struct Input {
    pub ix: f32,
    pub iy: f32,
    pub ax: f32,
    pub ay: f32,
}

/// Что хост знает о втором игроке на этот кадр: его ввод, где он сам себя видит и одноразовые нажатия.
#[derive(Clone, Copy, Debug, Default)]
pub struct RemoteCtl {
    pub inp: Input,
    /// Клиент прислал свежую позицию (движение считает сам клиент, чтобы не было задержки управления).
    pub has_pos: bool,
    pub x: f32,
    pub y: f32,
    pub vx: f32,
    pub vy: f32,
    /// Номер «телепорта», который клиент уже видел. Если не совпал с `Game::epoch`, позицию клиента игнорируем.
    pub epoch: u8,
    /// Нажата активка (одно срабатывание).
    pub act: bool,
    /// Брошена бомба (одно срабатывание).
    pub bomb: bool,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Skin {
    Normal,
    /// Светящийся сгусток Кросмоза.
    Weak,
    LetterN,
    Tape,
    Astral,
    Bottle,
    Shard,
    Boomerang,
    Terra,
    Rainbow,
}

#[derive(Clone, Debug)]
pub struct Bullet {
    pub x: f32,
    pub y: f32,
    pub vx: f32,
    pub vy: f32,
    /// Урон пули игрока.
    pub d: f32,
    /// Урон вражеской пули.
    pub dm: f32,
    /// Оставшееся время жизни, с.
    pub l: f32,
    pub r: f32,
    /// Пуля игрока (иначе вражеская).
    pub pl: bool,
    pub pi: i32,
    pub bn: i32,
    pub hm: bool,
    pub bu: bool,
    pub po: bool,
    pub tb: bool,
    pub rb: i32,
    pub skin: Skin,
    pub hit: Vec<u32>,
    /// Бумеранг Стража.
    pub bm: bool,
    /// Бумеранг возвращается.
    pub ph: bool,
    pub tr: f32,
    pub dist: f32,
    pub rot: f32,
    /// Чей снаряд: 0 — первый игрок (хост), 1 — второй (онлайн-напарник).
    pub own: u8,
}

impl Bullet {
    pub fn base(x: f32, y: f32, vx: f32, vy: f32, l: f32, r: f32) -> Bullet {
        Bullet {
            x,
            y,
            vx,
            vy,
            d: 0.0,
            dm: 1.0,
            l,
            r,
            pl: true,
            pi: 0,
            bn: 0,
            hm: false,
            bu: false,
            po: false,
            tb: false,
            rb: 0,
            skin: Skin::Normal,
            hit: Vec::new(),
            bm: false,
            ph: false,
            tr: 0.0,
            dist: 0.0,
            rot: 0.0,
            own: 0,
        }
    }
}

#[derive(Clone, Debug)]
pub struct Monster {
    pub id: u32,
    pub kind: MonKind,
    pub beh: Beh,
    /// Урон при касании.
    pub dm: f32,
    pub x: f32,
    pub y: f32,
    pub r: f32,
    /// Радиус столкновения со стенами (0 — брать `r`).
    pub cr: f32,
    pub sp: f32,
    pub hp: f32,
    pub mhp: f32,
    pub color: &'static str,
    pub vx: f32,
    pub vy: f32,
    /// Сколько ещё секунд «помнит» игрока.
    pub aw: f32,
    pub lx: f32,
    pub ly: f32,
    pub wt: f32,
    pub wa: f32,
    pub cd: f32,
    pub st: i32,
    pub stt: f32,
    pub a: f32,
    pub dir: f32,
    /// Таймер вспышки при попадании.
    pub fl: f32,
    /// Горение / яд, оставшееся время.
    pub bt: f32,
    pub pt: f32,
    /// Обход препятствия: время и угол.
    pub tt: f32,
    pub ta: f32,
    pub ux: f32,
    pub uy: f32,
    pub dx: f32,
    pub dy: f32,
    pub fan: bool,
    pub dead: bool,
    pub s_t: f32,
    pub sv: bool,
    pub boss: bool,
    pub bk: usize,
    pub q: &'static str,
    pub si: usize,
    pub bs: char,
    pub wind: bool,
    pub sd: f32,
    pub sdt: f32,
    pub name: &'static str,
}

impl Monster {
    pub fn col_r(&self) -> f32 {
        if self.cr > 0.0 {
            self.cr
        } else {
            self.r
        }
    }

    /// Заготовка монстра без обращения к `Game`: так клиент онлайн-игры собирает врагов из снимка.
    pub fn blank(kind: MonKind) -> Monster {
        let d = mon_def(kind);
        Monster {
            id: 0,
            kind,
            beh: d.beh,
            dm: d.contact,
            x: 0.0,
            y: 0.0,
            r: d.r,
            cr: 0.0,
            sp: d.sp,
            hp: d.hp,
            mhp: d.hp,
            color: d.color,
            vx: 0.0,
            vy: 0.0,
            aw: 0.0,
            lx: 0.0,
            ly: 0.0,
            wt: 0.0,
            wa: 0.0,
            cd: 0.0,
            st: 0,
            stt: 0.0,
            a: 0.0,
            dir: 1.0,
            fl: 0.0,
            bt: 0.0,
            pt: 0.0,
            tt: 0.0,
            ta: 0.0,
            ux: 1.0,
            uy: 0.0,
            dx: 0.0,
            dy: 0.0,
            fan: false,
            dead: false,
            s_t: 0.0,
            sv: false,
            boss: false,
            bk: 0,
            q: "",
            si: 0,
            bs: 'c',
            wind: false,
            sd: 1.0,
            sdt: 0.0,
            name: d.name,
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Act {
    pub id: ActId,
    pub kind: ActKind,
    pub m: f32,
    pub c: f32,
    /// Предмет, который дал активку (для значка).
    pub item: Option<usize>,
}

#[derive(Clone, Copy, Debug)]
pub struct Buff {
    pub id: ActId,
    pub t: f32,
}

#[derive(Clone, Debug)]
pub struct Player {
    pub x: f32,
    pub y: f32,
    pub vx: f32,
    pub vy: f32,
    pub r: f32,
    pub st: Stats,
    pub cd: f32,
    pub inv: f32,
    pub fx: f32,
    pub fy: f32,
    pub ch: usize,
    pub color: &'static str,
    pub items: Vec<usize>,
    /// Пауза между подсказками.
    pub bt: f32,
    pub anim: f32,
    pub dead: bool,
    pub bombs: i32,
    pub melee: bool,
    pub act: Option<Act>,
    /// «Договор» активен до конца боя.
    pub rg: bool,
    pub bf: Vec<Buff>,
    pub pc: i32,
    pub kills: i32,
}

impl Player {
    pub fn gold(&self) -> i32 {
        self.st.gold as i32
    }
    pub fn keys(&self) -> i32 {
        self.st.keys as i32
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum PickKind {
    Coin,
    Key,
    Bomb,
    Heart,
    HalfHeart,
    DoubleHeart,
    Chest,
    /// Предмет (`it` < 0 — лечение в магазине).
    Item,
}

#[derive(Clone, Debug)]
pub struct Pick {
    pub x: f32,
    pub y: f32,
    pub kind: PickKind,
    pub v: i32,
    pub gold: bool,
    pub it: i32,
    pub pr: i32,
    pub pk: i32,
    /// Группа «возьми один»: остальные исчезают.
    pub cg: i32,
    pub gone: bool,
}

impl Pick {
    pub fn new(kind: PickKind, x: f32, y: f32) -> Pick {
        Pick { x, y, kind, v: 1, gold: false, it: 0, pr: 0, pk: 0, cg: 0, gone: false }
    }
    pub fn coin(x: f32, y: f32, v: i32) -> Pick {
        let mut p = Pick::new(PickKind::Coin, x, y);
        p.v = v;
        p
    }
    pub fn item(x: f32, y: f32, it: i32) -> Pick {
        let mut p = Pick::new(PickKind::Item, x, y);
        p.it = it;
        p
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Spike {
    pub x: i32,
    pub y: i32,
    pub o: f32,
    pub mh: bool,
}

#[derive(Clone, Copy, Debug)]
pub struct Barrel {
    pub x: i32,
    pub y: i32,
    pub hp: f32,
}

/// Расходящееся кольцо с «окном» босса Колючий Король.
#[derive(Clone, Copy, Debug)]
pub struct RingAtk {
    pub x: f32,
    pub y: f32,
    pub r: f32,
    pub sp: f32,
    pub g: f32,
    pub gw: f32,
    pub t: f32,
    pub eid: u32,
}

#[derive(Clone, Copy, Debug)]
pub struct Gas {
    pub x: f32,
    pub y: f32,
    pub l: f32,
}

#[derive(Clone, Copy, Debug)]
pub struct Bomb {
    pub x: f32,
    pub y: f32,
    pub l: f32,
    pub vx: f32,
    pub vy: f32,
    /// Вражеская (от взорванного бомбардира).
    pub hostile: bool,
}

#[derive(Clone, Copy, Debug)]
pub struct Part {
    pub x: f32,
    pub y: f32,
    pub vx: f32,
    pub vy: f32,
    pub l: f32,
    pub col: (u8, u8, u8),
}

#[derive(Clone, Debug)]
pub struct Banner {
    pub title: String,
    pub desc: String,
    pub rarity: u8,
    pub l: f32,
}

#[derive(Clone, Debug, Default)]
pub struct RoomState {
    pub vis: bool,
    /// Зачищена.
    pub cl: bool,
    /// Заперта (бой).
    pub lk: bool,
    /// Двери, которые заперли на время боя.
    pub rg: Vec<(i32, i32)>,
}

pub struct Game {
    pub rng: Rng,
    pub diff: usize,
    pub floor: i32,
    pub t: f32,
    pub p: Player,
    pub path: Option<Path>,
    /// Ждём выбора пути Ад/Рай.
    pub choose: bool,
    pub won: bool,
    pub fin: bool,
    pub fin_t: f32,
    pub over: bool,
    pub win: bool,
    pub map: Vec<Vec<u8>>,
    pub brk: HashSet<i32>,
    pub bar: HashMap<i32, Barrel>,
    pub spk: Vec<Spike>,
    pub rings: Vec<RingAtk>,
    pub rooms: Vec<Room>,
    pub rs: Vec<RoomState>,
    pub cur: usize,
    pub mons: Vec<Monster>,
    pub pick: Vec<Pick>,
    pub bul: Vec<Bullet>,
    pub parts: Vec<Part>,
    pub gas: Vec<Gas>,
    pub bombs: Vec<Bomb>,
    pub freeze: f32,
    pub intro: f32,
    pub shake: f32,
    pub flash: f32,
    pub boss_on: bool,
    pub toast: Option<(String, f32)>,
    pub ban: Option<Banner>,
    pub boss_door: (i32, i32),
    pub stairs: (i32, i32),
    pub bag: Vec<usize>,
    pub bi: usize,
    pub used: Vec<bool>,
    pub next_id: u32,
    pub cg_ctr: i32,
    pub guard_unlock: bool,
    pub pal_unlock: bool,
    pub mid_win: bool,
    /// Второй игрок (онлайн-кооператив). У хоста это друг, у клиента — хост.
    pub p2: Option<Player>,
    /// Игроки временно поменяны местами (см. `swap_players`): в `self.p` лежит второй игрок.
    pub swapped: bool,
    /// Счётчик «телепортов» второго игрока (дверь, этаж, рывок): клиент по нему понимает, что позицию надо взять у хоста.
    pub epoch: u8,
    /// Хост копит новые частицы, чтобы отправить их клиенту.
    pub rec_parts: bool,
    pub new_parts: Vec<Part>,
    /// Клиент: куда плавно подтягивать второго игрока.
    pub goal2: (f32, f32),
    /// Клиент: номер последнего принятого снимка (0 — ещё не было).
    pub net_seq: u32,
    /// Эта копия игры принадлежит клиенту онлайн-игры: сама ничего не считает, только показывает снимки хоста.
    pub is_client: bool,
}

/// Игрок по выбранному герою, улучшениям кузницы и сложности.
pub fn make_player(hero: usize, up: [i32; 3], diff: usize) -> Player {
    let hero = if hero < CHARACTERS.len() { hero } else { 0 };
    let k = &CHARACTERS[hero];
    let mut st = Stats::from_character(k);
    st.hp += up[0] as f32;
    st.mhp += up[0] as f32;
    st.dmg += up[1] as f32 * 0.5;
    st.rate *= 1.0 + 0.1 * up[2] as f32;
    st.shield = k.armor;
    if diff == 0 {
        st.mhp += 1.0;
        st.hp += 1.0;
        st.shield += 1.0;
    }
    let mut p = Player {
        x: 0.0,
        y: 0.0,
        vx: 0.0,
        vy: 0.0,
        r: 0.3,
        st,
        cd: 0.0,
        inv: 0.0,
        fx: 0.0,
        fy: 1.0,
        ch: hero,
        color: k.color,
        items: Vec::new(),
        bt: 0.0,
        anim: 0.0,
        dead: false,
        bombs: 1,
        melee: k.melee,
        act: None,
        rg: false,
        bf: Vec::new(),
        pc: 0,
        kills: 0,
    };
    if k.secret {
        let d = act_def(ActId::Seal);
        p.act = Some(Act { id: ActId::Seal, kind: d.kind, m: d.max, c: d.max, item: None });
    }
    p
}

impl Game {
    pub fn new(hero: usize, up: [i32; 3], diff: usize, seed: u32) -> Game {
        let mut rng = Rng::new(seed);
        let hero = if hero < CHARACTERS.len() { hero } else { 0 };
        let diff = diff.min(2);
        let k = &CHARACTERS[hero];
        let p = make_player(hero, up, diff);
        let ids = [0usize, 1, 2, 4, 5, 6, 7, 14];
        let mut v: Vec<(f32, usize)> = Vec::new();
        for &i in ids.iter() {
            let r = rng.next_f32();
            v.push((if i == 4 { r.powf(2.5) } else { r }, i));
        }
        v.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
        let bag: Vec<usize> = v.iter().map(|a| a.1).collect();
        let mut g = Game {
            rng,
            diff,
            floor: 1,
            t: 0.0,
            p,
            path: None,
            choose: false,
            won: false,
            fin: false,
            fin_t: 0.0,
            over: false,
            win: false,
            map: Vec::new(),
            brk: HashSet::new(),
            bar: HashMap::new(),
            spk: Vec::new(),
            rings: Vec::new(),
            rooms: Vec::new(),
            rs: Vec::new(),
            cur: 0,
            mons: Vec::new(),
            pick: Vec::new(),
            bul: Vec::new(),
            parts: Vec::new(),
            gas: Vec::new(),
            bombs: Vec::new(),
            freeze: 0.0,
            intro: 0.0,
            shake: 0.0,
            flash: 0.0,
            boss_on: false,
            toast: None,
            ban: None,
            boss_door: (0, 0),
            stairs: (0, 0),
            bag,
            bi: 0,
            used: vec![false; ITEMS.len()],
            next_id: 0,
            cg_ctr: 0,
            guard_unlock: false,
            pal_unlock: false,
            mid_win: false,
            p2: None,
            swapped: false,
            epoch: 0,
            rec_parts: false,
            new_parts: Vec::new(),
            goal2: (0.0, 0.0),
            net_seq: 0,
            is_client: false,
        };
        g.gen_floor();
        g.say(&format!("Герой: {}. Ключ рядом. Зачисти все комнаты — откроется босс", k.name));
        g
    }

    pub fn say(&mut self, s: &str) {
        self.toast = Some((s.to_string(), 2.8));
    }

    // ---------- второй игрок (онлайн-кооператив) ----------

    /// Меняет местами `self.p` и `self.p2`. Так весь код, написанный под одного игрока,
    /// применяется и ко второму. Вызывается только парой «туда — обратно» без возвратов между ними.
    pub fn swap_players(&mut self) {
        if let Some(q) = self.p2.as_mut() {
            std::mem::swap(&mut self.p, q);
            self.swapped = !self.swapped;
        }
    }

    /// Номер владельца снарядов для игрока, который сейчас лежит в `self.p`.
    pub fn me(&self) -> u8 {
        if self.swapped {
            1
        } else {
            0
        }
    }

    /// Добавляет частицу и, если мы хост, запоминает её для отправки клиенту.
    pub fn add_part(&mut self, q: Part) {
        if self.rec_parts && self.new_parts.len() < 160 {
            self.new_parts.push(q);
        }
        self.parts.push(q);
    }

    /// Подключает второго игрока рядом с первым.
    pub fn add_player2(&mut self, hero: usize, up: [i32; 3]) {
        let mut q = make_player(hero, up, self.diff);
        q.x = self.p.x - 0.7;
        q.y = self.p.y;
        let name = CHARACTERS[q.ch].name;
        self.p2 = Some(q);
        self.say(&format!("К забегу присоединился: {}", name));
    }

    /// Применяет `f` к каждому живому игроку: первого как есть, второго через `swap_players`.
    pub fn each_player<F: FnMut(&mut Game)>(&mut self, mut f: F) {
        if !self.p.dead {
            f(self);
        }
        let alive2 = match self.p2.as_ref() {
            Some(q) => !q.dead,
            None => false,
        };
        if alive2 {
            self.swap_players();
            f(self);
            self.swap_players();
        }
    }

    /// Второй игрок жив и ближе к точке (или первый уже погиб): враг должен целиться в него.
    pub fn p2_closer(&self, x: f32, y: f32) -> bool {
        match self.p2.as_ref() {
            None => false,
            Some(q) => {
                if q.dead {
                    false
                } else if self.p.dead {
                    true
                } else {
                    hyp(q.x - x, q.y - y) < hyp(self.p.x - x, self.p.y - y)
                }
            }
        }
    }

    pub fn diff_def(&self) -> &'static Difficulty {
        &DIFFS[self.diff]
    }

    // ---------- карта и столкновения ----------

    pub fn wall(&self, x: f32, y: f32, pl: bool) -> bool {
        let a = x.floor() as i32;
        let b = y.floor() as i32;
        if a < 0 || b < 0 || a >= MAP_COLS || b >= MAP_ROWS {
            return true;
        }
        let t = self.map[b as usize][a as usize];
        t == 1 || (t > 2 && (t != 8 || !pl))
    }

    pub fn box_hit(&self, x: f32, y: f32, r: f32, pl: bool) -> bool {
        self.wall(x - r, y - r, pl) || self.wall(x + r, y - r, pl) || self.wall(x - r, y + r, pl) || self.wall(x + r, y + r, pl)
    }

    /// Сдвиг с раздельной проверкой осей. Возвращает новые координаты и биты упора (1 — по X, 2 — по Y).
    pub fn try_move(&self, x: f32, y: f32, r: f32, dx: f32, dy: f32, pl: bool) -> (f32, f32, u8) {
        let mut h = 0u8;
        let mut nx = x + dx;
        if self.box_hit(nx, y, r, pl) {
            nx = x;
            h |= 1;
        }
        let mut ny = y + dy;
        if self.box_hit(nx, ny, r, pl) {
            ny = y;
            h |= 2;
        }
        (nx, ny, h)
    }

    pub fn los(&self, x0: f32, y0: f32, x1: f32, y1: f32) -> bool {
        let n = (hyp(x1 - x0, y1 - y0) / 0.4).ceil() as i32;
        let mut i = 1;
        while i < n {
            let f = i as f32 / n as f32;
            if self.wall(x0 + (x1 - x0) * f, y0 + (y1 - y0) * f, false) {
                return false;
            }
            i += 1;
        }
        true
    }

    pub fn tile(&self, x: i32, y: i32) -> u8 {
        if x < 0 || y < 0 || x >= MAP_COLS || y >= MAP_ROWS {
            1
        } else {
            self.map[y as usize][x as usize]
        }
    }

    pub fn room(&self) -> &Room {
        &self.rooms[self.cur]
    }

    /// Монстр в клетке сетки текущей комнаты.
    pub fn in_cur_cell(&self, x: f32, y: f32) -> bool {
        let r = &self.rooms[self.cur];
        cell_x(x) == r.gx && cell_y(y) == r.gy
    }

    // ---------- частицы ----------

    pub fn puff(&mut self, x: f32, y: f32, col: &str, n: i32) {
        if self.parts.len() > 380 {
            return;
        }
        let c = rgb(col);
        for _ in 0..n {
            let a = self.rng.next_f32() * 6.3;
            let s = 1.0 + self.rng.next_f32() * 3.0;
            let l = 0.4 + self.rng.next_f32() * 0.3;
            self.add_part(Part { x, y, vx: a.cos() * s, vy: a.sin() * s, l, col: c });
        }
    }

    pub fn ring_parts(&mut self, x: f32, y: f32, r: f32, col: &str) {
        let c = rgb(col);
        for i in 0..24 {
            let a = i as f32 * 0.2618;
            let s = r.min(5.0) * 2.2;
            self.add_part(Part { x, y, vx: a.cos() * s, vy: a.sin() * s, l: 0.35, col: c });
        }
    }

    // ---------- создание монстров ----------

    pub fn mob(&mut self, kind: MonKind, x: f32, y: f32) -> Monster {
        let d = mon_def(kind);
        let hp = d.hp * (1.0 + self.floor as f32 * 0.2) * DIFFS[self.diff].hp;
        self.next_id += 1;
        let cd = 1.0 + self.rng.next_f32() * 1.5;
        let a = self.rng.next_f32() * 6.28;
        Monster {
            id: self.next_id,
            kind,
            beh: d.beh,
            dm: d.contact,
            x,
            y,
            r: d.r,
            cr: 0.0,
            sp: d.sp,
            hp,
            mhp: hp,
            color: d.color,
            vx: 0.0,
            vy: 0.0,
            aw: 0.0,
            lx: x,
            ly: y,
            wt: 0.0,
            wa: 0.0,
            cd,
            st: 0,
            stt: 0.0,
            a,
            dir: 1.0,
            fl: 0.0,
            bt: 0.0,
            pt: 0.0,
            tt: 0.0,
            ta: 0.0,
            ux: 1.0,
            uy: 0.0,
            dx: 0.0,
            dy: 0.0,
            fan: false,
            dead: false,
            s_t: 0.0,
            sv: false,
            boss: false,
            bk: 0,
            q: "",
            si: 0,
            bs: 'c',
            wind: false,
            sd: 1.0,
            sdt: 0.0,
            name: d.name,
        }
    }

    /// Случайная свободная точка внутри комнаты.
    pub fn rand_floor_pos(&mut self, ri: usize) -> (f32, f32) {
        let (rx, ry, rw, rh, cx, cy) = {
            let r = &self.rooms[ri];
            (r.x, r.y, r.w, r.h, r.cx, r.cy)
        };
        for _ in 0..400 {
            let x = rx as f32 + 1.0 + self.rng.below((rw - 2) as usize) as f32 + 0.5;
            let y = ry as f32 + 1.0 + self.rng.below((rh - 2) as usize) as f32 + 0.5;
            if self.tile(x.floor() as i32, y.floor() as i32) == 0 {
                return (x, y);
            }
        }
        (cx as f32 + 0.5, cy as f32 + 0.5)
    }

    /// Как `rpos` в JS: если не нашли места, возвращаем позицию игрока.
    pub fn drop_pos(&mut self, ri: usize) -> (f32, f32) {
        let (rx, ry, rw, rh) = {
            let r = &self.rooms[ri];
            (r.x, r.y, r.w, r.h)
        };
        for _ in 0..30 {
            let x = rx as f32 + 1.0 + self.rng.below((rw - 2) as usize) as f32 + 0.5;
            let y = ry as f32 + 1.0 + self.rng.below((rh - 2) as usize) as f32 + 0.5;
            if self.tile(x.floor() as i32, y.floor() as i32) == 0 {
                return (x, y);
            }
        }
        (self.p.x, self.p.y)
    }

    fn spawn_mobs(&mut self, ri: usize, k: usize) {
        let f = self.floor;
        let path = self.path;
        for _ in 0..k {
            let (x, y) = self.rand_floor_pos(ri);
            let kind = match path {
                Some(pa) if f > 6 => path_mobs(pa)[self.rng.below(4)],
                _ => {
                    let n = std::cmp::min(NORMAL_MOBS.len() as i32, 1 + f + if f > 2 { 1 } else { 0 }) as usize;
                    NORMAL_MOBS[self.rng.below(n)]
                }
            };
            let m = self.mob(kind, x, y);
            self.mons.push(m);
        }
    }

    // ---------- пул предметов ----------

    pub fn item_ok(&self, i: usize) -> bool {
        if item_min_floor(i) > self.floor {
            return false;
        }
        match item_path(i) {
            None => true,
            Some(pa) => self.path == Some(pa),
        }
    }

    fn pick_weighted(&mut self, a: &[usize]) -> usize {
        let bonus = match self.diff {
            0 => 1.0,
            2 => -0.5,
            _ => 0.0,
        };
        let lk = (self.p.st.luck.max(0.0) + bonus).max(0.0);
        let w: Vec<f32> = a.iter().map(|&i| item_weight(ITEMS[i].rarity, lk)).collect();
        let total: f32 = w.iter().sum();
        let mut s = total * self.rng.next_f32();
        for j in 0..a.len() {
            s -= w[j];
            if s <= 0.0 {
                return a[j];
            }
        }
        a[a.len() - 1]
    }

    /// Выбор предмета для награды или магазина, без повторов, пока есть из чего выбирать.
    pub fn take_item(&mut self) -> usize {
        let n = ITEMS.len();
        let mut a: Vec<usize> = Vec::new();
        for i in 0..n {
            if self.item_ok(i) && !item_excluded(i) && !self.used[i] {
                a.push(i);
            }
        }
        if a.is_empty() {
            for u in self.used.iter_mut() {
                *u = false;
            }
            for i in 0..n {
                if self.item_ok(i) && !item_excluded(i) {
                    a.push(i);
                }
            }
        }
        let pi: Vec<usize> = a.iter().cloned().filter(|&i| item_path(i).is_some()).collect();
        if !pi.is_empty() && self.rng.next_f32() < 0.45 {
            a = pi;
        }
        let i = self.pick_weighted(&a);
        self.used[i] = true;
        i
    }

    // ---------- ловушки ----------

    fn trap_spot(&mut self, ri: usize) -> Option<(i32, i32)> {
        let (rx, ry, rw, rh, cx, cy) = {
            let r = &self.rooms[ri];
            (r.x, r.y, r.w, r.h, r.cx, r.cy)
        };
        for _ in 0..80 {
            let x = rx + 1 + self.rng.below((rw - 2) as usize) as i32;
            let y = ry + 1 + self.rng.below((rh - 2) as usize) as i32;
            if x == cx || y == cy {
                continue;
            }
            let mut ok = true;
            for a in -1..=1 {
                for b in -1..=1 {
                    if self.tile(x + a, y + b) != 0 {
                        ok = false;
                    }
                }
            }
            if ok {
                return Some((x, y));
            }
        }
        None
    }

    fn trap_gen(&mut self, f: i32) {
        for ri in 0..self.rooms.len() {
            let (skip, cx, cy) = {
                let r = &self.rooms[ri];
                (r.start || r.gold || r.shop || r.boss, r.cx, r.cy)
            };
            if skip {
                continue;
            }
            if f >= 2 {
                let n = self.rng.below(3);
                for _ in 0..n {
                    let s = match self.trap_spot(ri) {
                        Some(s) => s,
                        None => break,
                    };
                    self.map[s.1 as usize][s.0 as usize] = 1;
                    self.bar.insert(s.1 * MAP_COLS + s.0, Barrel { x: s.0, y: s.1, hp: 3.0 });
                }
            }
            let n = 1 + self.rng.below(2) + if f > 2 { 1 } else { 0 };
            for _ in 0..n {
                let s = match self.trap_spot(ri) {
                    Some(s) => s,
                    None => break,
                };
                let o = self.rng.next_f32() * 3.2;
                let shape: [(i32, i32); 5] = [(0, 0), (1, 0), (0, 1), (1, 1), (2, 0)];
                let cnt = 1 + self.rng.below(4);
                for &(dx, dy) in shape.iter().take(cnt) {
                    let x = s.0 + dx;
                    let y = s.1 + dy;
                    if x == cx || y == cy || self.tile(x, y) != 0 {
                        continue;
                    }
                    if self.spk.iter().any(|q| q.x == x && q.y == y) {
                        continue;
                    }
                    self.spk.push(Spike { x, y, o, mh: false });
                }
            }
        }
    }

    // ---------- генерация этажа ----------

    pub fn gen_floor(&mut self) {
        let f = self.floor;
        let layout = dungeon::gen_layout(f, &mut self.rng);
        self.map = layout.map;
        self.brk = layout.rocks.iter().cloned().collect();
        self.boss_door = layout.boss_door;
        self.rooms = layout.rooms;
        self.bar.clear();
        self.spk.clear();
        self.rings.clear();
        self.trap_gen(f);
        self.rs = vec![RoomState::default(); self.rooms.len()];
        self.rs[0].vis = true;
        self.cur = 0;
        self.mons.clear();
        self.pick.clear();
        self.bul.clear();
        self.gas.clear();
        self.bombs.clear();
        self.intro = 0.0;
        self.boss_on = false;
        self.flash = 0.0;
        self.freeze = 0.0;
        let (scx, scy) = (self.rooms[0].cx, self.rooms[0].cy);
        self.p.x = scx as f32 + 0.5;
        self.p.y = scy as f32 + 0.5;
        self.p.vx = 0.0;
        self.p.vy = 0.0;
        if self.p.dead {
            self.p.dead = false;
            self.p.st.hp = 1.0;
        }
        if let Some(q) = self.p2.as_mut() {
            q.x = scx as f32 - 0.2;
            q.y = scy as f32 + 0.5;
            q.vx = 0.0;
            q.vy = 0.0;
            if q.dead {
                q.dead = false;
                q.st.hp = 1.0;
            }
        }
        self.epoch = self.epoch.wrapping_add(1);
        self.new_parts.clear();
        let li = self.rooms.iter().position(|r| r.boss).unwrap_or(0);
        let gi = self.rooms.iter().position(|r| r.gold).unwrap_or(0);
        let si = self.rooms.iter().position(|r| r.shop).unwrap_or(0);
        let (lcx, lcy) = (self.rooms[li].cx, self.rooms[li].cy);
        let (gcx, gcy) = (self.rooms[gi].cx as f32, self.rooms[gi].cy as f32);
        let (scx2, scy2) = (self.rooms[si].cx as f32, self.rooms[si].cy as f32);
        let pool: [usize; 5] = [self.take_item(), self.take_item(), self.take_item(), self.take_item(), self.take_item()];
        self.stairs = (lcx, lcy + 2);

        // стартовый ключ
        self.pick.push(Pick::new(PickKind::Key, scx as f32 + 1.5, scy as f32 + 0.5));
        // сокровищница: берёшь один из двух
        let grp = 1000 + f;
        let mut a = Pick::item(gcx - 1.5, gcy + 0.5, pool[0] as i32);
        a.cg = grp;
        let mut b = Pick::item(gcx + 2.5, gcy + 0.5, pool[3] as i32);
        b.cg = grp;
        self.pick.push(a);
        self.pick.push(b);
        // магазин
        let r1 = ITEMS[pool[1]].rarity as i32;
        let pr1 = 5 + r1 * 2 + self.rng.below(5) as i32 + f * 2;
        let r2 = ITEMS[pool[2]].rarity as i32;
        let pr2 = 5 + r2 * 2 + self.rng.below(5) as i32 + f * 2;
        let mut s1 = Pick::item(scx2 - 1.5, scy2 + 0.5, pool[1] as i32);
        s1.pr = pr1;
        let mut s2 = Pick::item(scx2 + 2.5, scy2 + 0.5, pool[2] as i32);
        s2.pr = pr2;
        let mut s3 = Pick::item(scx2 - 1.5, scy2 - 1.8, pool[4] as i32);
        s3.pk = if ITEMS[pool[4]].rarity >= 4 { 2 } else { 1 };
        let mut s4 = Pick::new(PickKind::Bomb, scx2 + 2.5, scy2 - 1.8);
        s4.pk = 1;
        let mut s5 = Pick::item(scx2 + 0.5, scy2 + 0.5, -1);
        s5.pr = 4;
        self.pick.push(s1);
        self.pick.push(s2);
        self.pick.push(s3);
        self.pick.push(s4);
        self.pick.push(s5);

        // монстры и мелочи в обычных комнатах
        for ri in 0..self.rooms.len() {
            let (skip, area) = {
                let r = &self.rooms[ri];
                (r.start || r.gold || r.boss || r.shop, r.area)
            };
            if skip {
                continue;
            }
            let base = 2 + self.rng.below(3) as i32 + if f > 2 { 1 } else { 0 } + if f > 4 { 1 } else { 0 };
            let scale = (area as f32 / 190.0).min(1.1).max(0.45);
            let cnt = ((base as f32) * 1.8 * scale).round().max(2.0) as usize;
            self.spawn_mobs(ri, cnt);
            if self.rng.next_f32() < 0.08 {
                let (x, y) = self.rand_floor_pos(ri);
                self.pick.push(Pick::coin(x, y, 1));
            }
            if self.rng.next_f32() < 0.4 {
                let (x, y) = self.rand_floor_pos(ri);
                let mut c = Pick::new(PickKind::Chest, x, y);
                c.gold = self.rng.next_f32() < 0.4;
                self.pick.push(c);
            }
        }

        // босс
        let path = self.path;
        let bk = if f == 6 {
            3
        } else {
            match path {
                Some(pa) if f > 6 => path_bosses(pa)[std::cmp::min(2, f - 7) as usize],
                _ => {
                    let b = self.bag[self.bi % self.bag.len()];
                    self.bi += 1;
                    b
                }
            }
        };
        let bd = &BOSSES[bk];
        let hp = (((70 + f * 45) as f32) * 1.3 * DIFFS[self.diff].hp).round();
        let mut bb = self.mob(MonKind::Slime, lcx as f32 + 0.5, lcy as f32 + 0.5);
        bb.dm = 1.0;
        bb.cr = 0.45;
        bb.kind = MonKind::Boss;
        bb.beh = Beh::Boss;
        bb.bk = bk;
        bb.q = bd.pattern;
        bb.r = 0.8;
        bb.hp = hp;
        bb.mhp = hp;
        bb.sp = 1.95;
        bb.color = bd.color;
        bb.si = 0;
        bb.bs = 'c';
        bb.stt = 2.4;
        bb.boss = true;
        bb.name = bd.name;
        self.mons.push(bb);
        self.spawn_mobs(li, 3);
        for i in 0..self.mons.len() {
            let (is_gun, boss, kind) = (self.mons[i].beh == Beh::Gun, self.mons[i].boss, self.mons[i].kind);
            if boss || !is_gun {
                continue;
            }
            let always = kind == MonKind::Imp || kind == MonKind::Angel || kind == MonKind::Shroom || kind == MonKind::Turret;
            let roll = f >= 4 && self.rng.next_f32() < 0.5;
            if roll || always {
                self.mons[i].fan = true;
            }
        }
    }

    /// Форма комнаты для миникарты: прямоугольники в координатах клетки и признак кольца.
    pub fn room_shape(&self, ri: usize) -> (Vec<(i32, i32, i32, i32)>, bool) {
        let def = &ROOMS[self.rooms[ri].kind];
        let mut v = Vec::new();
        for &(w, h) in def.rects.iter() {
            let (w, h) = (w as i32, h as i32);
            v.push(((CW >> 1) - (w >> 1), (CH >> 1) - (h >> 1), w, h));
        }
        (v, def.ring)
    }
}
