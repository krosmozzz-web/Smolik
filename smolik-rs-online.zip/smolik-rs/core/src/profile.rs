//! Мета-прогресс: монеты, открытые герои, кузница. Хранится в простом текстовом файле `ключ=значение`.
use crate::data::CHARACTERS;

pub const UPGRADE_NAMES: [&str; 3] = ["Сердце +1 HP", "Урон +0.5", "Скорострельность +10%"];
pub const UPGRADE_MAX: i32 = 2;

#[derive(Clone, Debug, PartialEq)]
pub struct Profile {
    pub coins: i32,
    pub best: i32,
    pub wins: i32,
    pub kills: i32,
    pub runs: i32,
    /// Всего собрано монет за все забеги (для героя Рыцарь).
    pub total_gold: i32,
    pub sel: usize,
    pub up: [i32; 3],
    pub pal: bool,
    pub guard: bool,
    /// Пройденные опросы по номеру героя.
    pub quiz: [bool; 12],
    pub diff: usize,
    /// Последний адрес хоста для онлайн-игры («ip:порт»).
    pub addr: String,
}

impl Default for Profile {
    fn default() -> Self {
        Profile {
            coins: 0,
            best: 0,
            wins: 0,
            kills: 0,
            runs: 0,
            total_gold: 0,
            sel: 0,
            up: [0; 3],
            pal: false,
            guard: false,
            quiz: [false; 12],
            diff: 1,
            addr: String::new(),
        }
    }
}

/// Итог забега, который переносится в профиль.
#[derive(Clone, Copy, Debug)]
pub struct RunResult {
    pub win: bool,
    pub floor: i32,
    pub gold: i32,
    pub kills: i32,
    /// Победа над Владыкой на 6 этаже уже засчитана по ходу забега.
    pub mid_win: bool,
    pub pal_unlock: bool,
    pub guard_unlock: bool,
}

impl Profile {
    /// Открыт ли герой с номером `i`.
    pub fn unlocked(&self, i: usize) -> bool {
        match i {
            0 | 11 => true,
            1 => self.kills >= 40,
            2 => self.best >= 4,
            3 => self.total_gold >= 150,
            4 => self.wins >= 1,
            5 => self.wins >= 2,
            6 | 7 | 9 => self.quiz[i],
            8 => self.pal,
            10 => self.guard,
            _ => false,
        }
    }

    /// Прогресс задания героя, например «12/40». Пустая строка, если не нужен.
    pub fn progress(&self, i: usize) -> String {
        match i {
            1 => format!("{}/40", self.kills),
            2 => format!("{}/4", self.best),
            3 => format!("{}/150", self.total_gold),
            4 => format!("{}/1", self.wins),
            5 => format!("{}/2", self.wins),
            _ => String::new(),
        }
    }

    /// Герой нуждается в опросе для открытия.
    pub fn needs_quiz(&self, i: usize) -> bool {
        i < CHARACTERS.len() && CHARACTERS[i].quiz >= 0 && !self.unlocked(i)
    }

    pub fn upgrade_cost(&self, k: usize) -> i32 {
        20 * (self.up[k] + 1)
    }

    pub fn can_upgrade(&self, k: usize) -> bool {
        self.up[k] < UPGRADE_MAX && self.coins >= self.upgrade_cost(k)
    }

    pub fn buy_upgrade(&mut self, k: usize) -> bool {
        if !self.can_upgrade(k) {
            return false;
        }
        self.coins -= self.upgrade_cost(k);
        self.up[k] += 1;
        true
    }

    /// Если выбранный герой закрыт, откатываемся на Смолика.
    pub fn fix_selection(&mut self) {
        if self.sel >= CHARACTERS.len() || !self.unlocked(self.sel) {
            self.sel = 0;
        }
    }

    pub fn start_run(&mut self) {
        self.runs += 1;
    }

    /// Применяет итог забега (то же, что `finish()` в JS).
    pub fn apply_run(&mut self, r: &RunResult) {
        let g = r.gold + if r.win { 60 } else { 0 };
        if r.gold >= 100 || r.pal_unlock {
            self.pal = true;
        }
        if r.guard_unlock {
            self.guard = true;
        }
        if r.mid_win {
            self.wins += 1;
        }
        if r.floor > self.best {
            self.best = r.floor;
        }
        self.kills += r.kills;
        self.coins += g;
        self.total_gold += g;
        if r.win {
            self.wins += 1;
        }
        self.fix_selection();
    }

    pub fn to_text(&self) -> String {
        let mut s = String::new();
        s.push_str(&format!("coins={}\n", self.coins));
        s.push_str(&format!("best={}\n", self.best));
        s.push_str(&format!("wins={}\n", self.wins));
        s.push_str(&format!("kills={}\n", self.kills));
        s.push_str(&format!("runs={}\n", self.runs));
        s.push_str(&format!("tg={}\n", self.total_gold));
        s.push_str(&format!("sel={}\n", self.sel));
        s.push_str(&format!("up={},{},{}\n", self.up[0], self.up[1], self.up[2]));
        s.push_str(&format!("pal={}\n", self.pal as i32));
        s.push_str(&format!("guard={}\n", self.guard as i32));
        s.push_str(&format!("diff={}\n", self.diff));
        if !self.addr.is_empty() {
            s.push_str(&format!("addr={}\n", self.addr));
        }
        for (i, q) in self.quiz.iter().enumerate() {
            if *q {
                s.push_str(&format!("qz{}=1\n", i));
            }
        }
        s
    }

    pub fn from_text(text: &str) -> Profile {
        let mut p = Profile::default();
        for line in text.lines() {
            let mut it = line.splitn(2, '=');
            let key = it.next().unwrap_or("").trim();
            let val = it.next().unwrap_or("").trim();
            let n: i32 = val.parse().unwrap_or(0);
            match key {
                "coins" => p.coins = n.max(0),
                "best" => p.best = n.max(0),
                "wins" => p.wins = n.max(0),
                "kills" => p.kills = n.max(0),
                "runs" => p.runs = n.max(0),
                "tg" => p.total_gold = n.max(0),
                "sel" => p.sel = n.max(0) as usize,
                "pal" => p.pal = n != 0,
                "guard" => p.guard = n != 0,
                "diff" => p.diff = (n.max(0) as usize).min(2),
                "addr" => p.addr = val.chars().filter(|c| !c.is_control()).take(80).collect(),
                "up" => {
                    for (k, part) in val.split(',').enumerate() {
                        if k < 3 {
                            let v: i32 = part.trim().parse().unwrap_or(0);
                            p.up[k] = v.max(0).min(UPGRADE_MAX);
                        }
                    }
                }
                _ => {
                    if let Some(rest) = key.strip_prefix("qz") {
                        if let Ok(i) = rest.parse::<usize>() {
                            if i < p.quiz.len() {
                                p.quiz[i] = n != 0;
                            }
                        }
                    }
                }
            }
        }
        p.fix_selection();
        p
    }
}

/// Вопросы опроса для героев, которых открывает викторина. Правильный ответ всегда «Да».
pub fn quiz_for(hero: usize) -> Option<(&'static str, [&'static str; 5])> {
    match hero {
        6 => Some((
            "NgrOK — крутой!",
            ["NgrOK крутой?", "NgrOK стреляет буквами N?", "NgrOK — лучший герой?", "Фиолетовый цвет — это круто?", "Хочешь играть за NgrOK?"],
        )),
        9 => Some((
            "Опрос про Oromss",
            ["Oromss жирный?", "Oromss правильный?", "Oromss — настоящий царь батюшка?", "Царь батюшка стреляет астрал-шарами?", "Oromss всегда прав?"],
        )),
        7 => Some((
            "Опрос про Windy",
            ["Windy продаст дрова?", "Windy верный?", "Дрова от Windy — самые лучшие?", "Windy стреляет кассетами?", "Windy быстрая?"],
        )),
        _ => None,
    }
}
