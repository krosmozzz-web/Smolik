//! Раскладка этажа: дерево комнат, их формы, двери и камни.
//! Портировано из JS `gen()` до расстановки ловушек, предметов и монстров.
//! Порядок обращений к генератору случайных чисел совпадает с JS, поэтому один сид даёт тот же этаж.
use crate::data::ROOMS;
use crate::rng::Rng;

pub const GN: i32 = 7; // сетка комнат GN x GN
pub const CW: i32 = 20; // размер клетки сетки в тайлах
pub const CH: i32 = 15;
pub const MAP_COLS: i32 = GN * CW;
pub const MAP_ROWS: i32 = GN * CH;

const DIRS: [(i32, i32); 4] = [(1, 0), (-1, 0), (0, 1), (0, -1)];

#[derive(Clone, Debug)]
pub struct Door {
    pub x: i32,
    pub y: i32,
    pub dx: i32,
    pub dy: i32,
}

#[derive(Clone, Debug)]
pub struct Room {
    pub gx: i32,
    pub gy: i32,
    pub parent: Option<usize>,
    pub depth: i32,
    pub start: bool,
    pub boss: bool,
    pub gold: bool,
    pub shop: bool,
    /// Индекс в `data::ROOMS`.
    pub kind: usize,
    pub x: i32,
    pub y: i32,
    pub w: i32,
    pub h: i32,
    /// Число свободных тайлов внутри габаритов комнаты.
    pub area: i32,
    pub cx: i32,
    pub cy: i32,
    pub doors: Vec<Door>,
}

pub struct Layout {
    pub rooms: Vec<Room>,
    /// Тайлы: 0 пол, 1 стена или камень, 5 запертая золотая дверь, 8 открытая дверь.
    pub map: Vec<Vec<u8>>,
    /// Позиции камней (y * MAP_COLS + x) в порядке появления.
    pub rocks: Vec<i32>,
    pub boss_door: (i32, i32),
}

fn new_room(gx: i32, gy: i32, parent: Option<usize>, depth: i32, start: bool) -> Room {
    Room {
        gx,
        gy,
        parent,
        depth,
        start,
        boss: false,
        gold: false,
        shop: false,
        kind: 0,
        x: 0,
        y: 0,
        w: 0,
        h: 0,
        area: 0,
        cx: 0,
        cy: 0,
        doors: Vec::new(),
    }
}

fn occupied(grid: &Vec<Vec<Option<usize>>>, x: i32, y: i32) -> bool {
    if x < 0 || y < 0 || x >= GN || y >= GN {
        return false;
    }
    grid[x as usize][y as usize].is_some()
}

fn door_pos(r: &Room, dx: i32, dy: i32) -> (i32, i32) {
    if dx > 0 {
        (r.x + r.w, r.cy)
    } else if dx < 0 {
        (r.x - 1, r.cy)
    } else if dy > 0 {
        (r.cx, r.y + r.h)
    } else {
        (r.cx, r.y - 1)
    }
}

pub fn gen_layout(floor: i32, rng: &mut Rng) -> Layout {
    // 1) Дерево комнат: растёт от центра, пока не наберётся достаточно листьев
    let (mut rooms, mut leaves) = loop {
        let mut grid = vec![vec![None::<usize>; GN as usize]; GN as usize];
        let mut rooms = vec![new_room(3, 3, None, 0, true)];
        grid[3][3] = Some(0);
        let target = std::cmp::min(13, 8 + floor * 2) as usize;
        for _ in 0..300 {
            if rooms.len() >= target {
                break;
            }
            let bi = rng.below(rooms.len());
            let (dx, dy) = DIRS[rng.below(4)];
            let (bgx, bgy, bdepth) = {
                let b = &rooms[bi];
                (b.gx, b.gy, b.depth)
            };
            let (x, y) = (bgx + dx, bgy + dy);
            if x < 0 || y < 0 || x >= GN || y >= GN || grid[x as usize][y as usize].is_some() {
                continue;
            }
            let near = DIRS.iter().filter(|d| occupied(&grid, x + d.0, y + d.1)).count();
            if near > 1 {
                continue;
            }
            grid[x as usize][y as usize] = Some(rooms.len());
            rooms.push(new_room(x, y, Some(bi), bdepth + 1, false));
        }
        let mut has_child = vec![false; rooms.len()];
        for r in rooms.iter() {
            if let Some(p) = r.parent {
                has_child[p] = true;
            }
        }
        let leaves: Vec<usize> = (0..rooms.len()).filter(|&i| !rooms[i].start && !has_child[i]).collect();
        if leaves.len() >= 4 && rooms.len() >= 7 {
            break (rooms, leaves);
        }
    };
    // 2) Самые глубокие листья: босс, золотая комната, магазин
    leaves.sort_by(|&a, &b| rooms[b].depth.cmp(&rooms[a].depth));
    rooms[leaves[0]].boss = true;
    rooms[leaves[1]].gold = true;
    rooms[leaves[2]].shop = true;

    // 3) Форма каждой комнаты и вырезание пола
    let mut map = vec![vec![1u8; MAP_COLS as usize]; MAP_ROWS as usize];
    for r in rooms.iter_mut() {
        let ox = r.gx * CW;
        let oy = r.gy * CH;
        r.kind = if r.start || r.gold || r.shop {
            0
        } else if r.boss {
            1
        } else {
            [0usize, 2, 3, 4, 5, 6, 7][rng.below(7)]
        };
        let def = &ROOMS[r.kind];
        let (mut x0, mut y0, mut x1, mut y1) = (1_000_000_000i32, 1_000_000_000i32, -1i32, -1i32);
        for &(rw, rh) in def.rects.iter() {
            let (w, h) = (rw as i32, rh as i32);
            let a = (CW >> 1) - (w >> 1);
            let b = (CH >> 1) - (h >> 1);
            x0 = x0.min(a);
            y0 = y0.min(b);
            x1 = x1.max(a + w);
            y1 = y1.max(b + h);
            for j in 0..h {
                for i in 0..w {
                    map[(oy + b + j) as usize][(ox + a + i) as usize] = 0;
                }
            }
        }
        if def.ring {
            let hx = (CW >> 1) - 4;
            let hy = (CH >> 1) - 2;
            for j in 0..5 {
                for i in 0..8 {
                    map[(oy + hy + j) as usize][(ox + hx + i) as usize] = 1;
                }
            }
        }
        r.x = ox + x0;
        r.y = oy + y0;
        r.w = x1 - x0;
        r.h = y1 - y0;
        let mut area = 0;
        for j in 0..r.h {
            for i in 0..r.w {
                if map[(r.y + j) as usize][(r.x + i) as usize] == 0 {
                    area += 1;
                }
            }
        }
        r.area = area;
        r.cx = ox + (CW >> 1);
        r.cy = oy + (CH >> 1);
    }

    // 4) Двери между родителем и потомком
    let mut boss_door = (0, 0);
    for ci in 0..rooms.len() {
        let bi = match rooms[ci].parent {
            Some(b) => b,
            None => continue,
        };
        let dx = rooms[ci].gx - rooms[bi].gx;
        let dy = rooms[ci].gy - rooms[bi].gy;
        let a = door_pos(&rooms[bi], dx, dy);
        let e = door_pos(&rooms[ci], -dx, -dy);
        // дверь босса открыта с начала, золотая запирается со 2 этажа
        let tile: u8 = if rooms[ci].boss {
            8
        } else if rooms[ci].gold && floor > 1 {
            5
        } else {
            8
        };
        map[a.1 as usize][a.0 as usize] = tile;
        map[e.1 as usize][e.0 as usize] = 8;
        rooms[bi].doors.push(Door { x: a.0, y: a.1, dx, dy });
        rooms[ci].doors.push(Door { x: e.0, y: e.1, dx: -dx, dy: -dy });
        if rooms[ci].boss {
            boss_door = a;
        }
    }

    // 5) Камни в обычных комнатах и в комнате босса
    let mut rocks: Vec<i32> = Vec::new();
    for r in rooms.iter() {
        if r.start || r.gold || r.shop {
            continue;
        }
        let want = 7 + rng.below(7) as i32;
        let mut placed = 0;
        for _ in 0..160 {
            if placed >= want {
                break;
            }
            let x = r.x + 1 + rng.below((r.w - 2) as usize) as i32;
            let y = r.y + 1 + rng.below((r.h - 2) as usize) as i32;
            if x == r.cx || y == r.cy {
                continue;
            }
            let mut free = true;
            for a in -1..=1 {
                for b in -1..=1 {
                    if map[(y + b) as usize][(x + a) as usize] != 0 {
                        free = false;
                    }
                }
            }
            if free {
                map[y as usize][x as usize] = 1;
                rocks.push(y * MAP_COLS + x);
                placed += 1;
            }
        }
    }
    Layout { rooms, map, rocks, boss_door }
}

fn fnv1a(bytes: &[u8]) -> u64 {
    let mut h: u64 = 0xcbf29ce484222325;
    for &b in bytes {
        h ^= b as u64;
        h = h.wrapping_mul(0x100000001b3);
    }
    h
}

/// Хеш раскладки для сравнения с эталоном из JS-версии.
pub fn digest(l: &Layout) -> u64 {
    let mut s = String::new();
    for row in l.map.iter() {
        for &t in row.iter() {
            s.push((b'0' + t) as char);
        }
        s.push('\n');
    }
    s.push('|');
    for r in l.rooms.iter() {
        s.push_str(&format!(
            "{},{},{},{},{},{},{},{},{},{},{},{},{},{},{};",
            r.gx, r.gy, r.kind, r.x, r.y, r.w, r.h, r.area, r.cx, r.cy, r.depth,
            r.boss as i32, r.gold as i32, r.shop as i32, r.start as i32
        ));
    }
    s.push('|');
    for k in l.rocks.iter() {
        s.push_str(&format!("{};", k));
    }
    s.push('|');
    s.push_str(&format!("{},{}", l.boss_door.0, l.boss_door.1));
    fnv1a(s.as_bytes())
}
