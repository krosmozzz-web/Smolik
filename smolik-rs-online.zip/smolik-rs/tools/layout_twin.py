import json
M=0xFFFFFFFF
class Rng:
    def __init__(s,seed): s.s=seed&M
    def f(s):
        s.s=(s.s+0x6D2B79F5)&M;t=s.s
        t=((t^(t>>15))*(t|1))&M
        t^=(t+(((t^(t>>7))*(t|61))&M))&M
        return ((t^(t>>14))&M)/4294967296
    def below(s,n): return int(s.f()*n)
GN,CW,CH,MC,MR=7,20,15,140,105
ROOMS=[{'R':[[10,9]]},{'R':[[18,13]]},{'R':[[18,6]]},{'R':[[7,13]]},{'R':[[18,3]]},{'R':[[3,13]]},{'R':[[18,5],[6,13]]},{'R':[[18,13]],'ring':1}]
DIRS=[(1,0),(-1,0),(0,1),(0,-1)]
def gen_layout(floor,rng):
    while True:
        grid={(3,3):0};rooms=[dict(gx=3,gy=3,par=None,dep=0,st=1,boss=0,gold=0,shop=0)]
        tg=min(13,8+floor*2)
        for _ in range(300):
            if len(rooms)>=tg:break
            bi=rng.below(len(rooms));d=DIRS[rng.below(4)];b=rooms[bi];x=b['gx']+d[0];y=b['gy']+d[1]
            if x<0 or y<0 or x>=GN or y>=GN or (x,y) in grid:continue
            if sum(1 for e in DIRS if (x+e[0],y+e[1]) in grid)>1:continue
            grid[(x,y)]=len(rooms);rooms.append(dict(gx=x,gy=y,par=bi,dep=b['dep']+1,st=0,boss=0,gold=0,shop=0))
        hc={r['par'] for r in rooms if r['par'] is not None}
        leaves=[i for i,r in enumerate(rooms) if not r['st'] and i not in hc]
        if len(leaves)>=4 and len(rooms)>=7:break
    leaves.sort(key=lambda i:-rooms[i]['dep'])
    rooms[leaves[0]]['boss']=1;rooms[leaves[1]]['gold']=1;rooms[leaves[2]]['shop']=1
    mp=[[1]*MC for _ in range(MR)]
    for r in rooms:
        ox=r['gx']*CW;oy=r['gy']*CH
        r['k']=0 if r['st'] or r['gold'] or r['shop'] else 1 if r['boss'] else [0,2,3,4,5,6,7][rng.below(7)]
        kd=ROOMS[r['k']];x0=y0=10**9;x1=y1=-1
        for w,h in kd['R']:
            a=(CW>>1)-(w>>1);b=(CH>>1)-(h>>1);x0=min(x0,a);y0=min(y0,b);x1=max(x1,a+w);y1=max(y1,b+h)
            for j in range(h):
                for i in range(w):mp[oy+b+j][ox+a+i]=0
        if kd.get('ring'):
            hx=(CW>>1)-4;hy=(CH>>1)-2
            for j in range(5):
                for i in range(8):mp[oy+hy+j][ox+hx+i]=1
        r['x']=ox+x0;r['y']=oy+y0;r['w']=x1-x0;r['h']=y1-y0
        r['ar']=sum(1 for j in range(r['h']) for i in range(r['w']) if mp[r['y']+j][r['x']+i]==0)
        r['cx']=ox+(CW>>1);r['cy']=oy+(CH>>1)
    def dp(r,dx,dy):
        return (r['x']+r['w'],r['cy']) if dx>0 else (r['x']-1,r['cy']) if dx<0 else (r['cx'],r['y']+r['h']) if dy>0 else (r['cx'],r['y']-1)
    bd=(0,0)
    for c in rooms:
        if c['par'] is None:continue
        b=rooms[c['par']];dx=c['gx']-b['gx'];dy=c['gy']-b['gy'];a=dp(b,dx,dy);e=dp(c,-dx,-dy)
        mp[a[1]][a[0]]=8 if c['boss'] else 5 if c['gold'] and floor>1 else 8;mp[e[1]][e[0]]=8
        if c['boss']:bd=a
    rocks=[]
    for r in rooms:
        if r['st'] or r['gold'] or r['shop']:continue
        kt=7+rng.below(7);k=0
        for _ in range(160):
            if k>=kt:break
            x=r['x']+1+rng.below(r['w']-2);y=r['y']+1+rng.below(r['h']-2)
            if x==r['cx'] or y==r['cy']:continue
            if all(mp[y+b][x+a]==0 for a in(-1,0,1) for b in(-1,0,1)):
                mp[y][x]=1;rocks.append(y*MC+x);k+=1
    return rooms,mp,rocks,bd
def fnv(s):
    h=0xcbf29ce484222325
    for b in s.encode():h=((h^b)*0x100000001b3)&0xFFFFFFFFFFFFFFFF
    return h
def digest(mapRows,roomTuples,rocks,bd):
    s=''.join(r+'\n' for r in mapRows)+'|'+''.join(','.join(map(str,t))+';' for t in roomTuples)+'|'+''.join(f'{k};' for k in rocks)+'|'+f'{bd[0]},{bd[1]}'
    return fnv(s)
if __name__=='__main__':
    g=json.load(open('/tmp/ref/golden.json'));bad=0;gold=[]
    for c in g['cases']:
        rooms,mp,rocks,bd=gen_layout(c['floor'],Rng(c['seed']))
        rows=[''.join(map(str,r)) for r in mp]
        tup=[[r['gx'],r['gy'],r['k'],r['x'],r['y'],r['w'],r['h'],r['ar'],r['cx'],r['cy'],r['dep'],r['boss'],r['gold'],r['shop'],r['st']] for r in rooms]
        ok=rows==c['map'] and tup==c['rooms'] and rocks==c['brk'] and list(bd)==list(c['bd'])
        dj=digest(c['map'],c['rooms'],c['brk'],c['bd']);dt=digest(rows,tup,rocks,bd)
        if not ok or dj!=dt:bad+=1;print('MISMATCH',c['seed'],c['floor'])
        gold.append((c['seed'],c['floor'],dj,len(c['rooms'])))
    print('cases',len(g['cases']),'mismatches',bad)
    json.dump(gold,open('/tmp/ref/gold_digest.json','w'))
